--!nonstrict
--[[
	ShopPanel.lua
	=============
	Exclusive shop modeled on the PS99 reference: vibrant rounded panels,
	green Robux buttons, and -- the improvement -- a REAL pity bar on every
	exclusive egg ("23 / 150 to guaranteed Titanic").

	Pity data comes from the server (ShopState) and reflects the same counters
	the hatch roll uses, so the bar cannot lie.

	If a product's config id is still 0 (not yet created in the Creator
	Dashboard) the button says so instead of silently failing: ship-blocking
	config is surfaced, never hidden.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(Shared.Config.GameConfig)
local Remotes = require(Shared.Net.Remotes)
local NumberFormatter = require(Shared.Modules.NumberFormatter)

local ShopPanel = {}
ShopPanel.__index = ShopPanel

local player = Players.LocalPlayer

function ShopPanel.new(parent: Instance, theme: any, callbacks: any)
	local self = setmetatable({}, ShopPanel)
	self.theme = theme
	self.callbacks = callbacks
	self.snapshot = nil
	self.cards = {}

	self:build(parent)
	return self
end

function ShopPanel:build(parent: Instance)
	local theme = self.theme

	local root = theme.panel(parent, {
		name = "Shop",
		size = UDim2.fromOffset(760, 540),
		position = UDim2.new(0.5, 0, 0.5, 0),
		anchor = Vector2.new(0.5, 0.5),
		color = theme.Colors.background,
		transparency = 0.02,
		visible = false,
	})
	self.frame = root

	theme.label(root, {
		text = "EXCLUSIVE SHOP",
		size = UDim2.new(0, 320, 0, 30),
		position = UDim2.fromOffset(22, 16),
		font = theme.Fonts.display,
		textSize = 22,
	})

	theme.label(root, {
		text = "Pity is guaranteed. Bars show live server progress.",
		size = UDim2.new(0, 420, 0, 18),
		position = UDim2.fromOffset(22, 46),
		color = theme.Colors.muted,
		textSize = 12,
	})

	self.closeButton = theme.button(root, {
		text = "X",
		size = UDim2.fromOffset(40, 40),
		position = UDim2.new(1, -54, 0, 16),
		variant = "ghost",
	})
	self.closeButton.Activated = function()
		self:hide()
	end

	local scroll, grid = theme.scrollingGrid(root, {
		name = "ShopGrid",
		size = UDim2.new(1, -44, 1, -100),
		position = UDim2.fromOffset(22, 84),
		cellSize = UDim2.fromOffset(340, 196),
		cellPadding = UDim2.fromOffset(14, 14),
	})
	self.scroll = scroll
	self.grid = grid

	self.emptyLabel = theme.label(root, {
		text = "Connecting to shop...",
		size = UDim2.new(1, -44, 0, 40),
		position = UDim2.fromOffset(22, 120),
		color = theme.Colors.muted,
		textSize = 13,
		xAlign = Enum.TextXAlignment.Center,
	})
end

-- ===========================================================================
-- Rendering
-- ===========================================================================

function ShopPanel:render()
	local theme = self.theme
	for _, child in ipairs(self.scroll:GetChildren()) do
		if child:IsA("Frame") or child:IsA("TextButton") then
			child:Destroy()
		end
	end

	if not self.snapshot then
		self.emptyLabel.Visible = true
		return
	end
	self.emptyLabel.Visible = false

	local order = Config.Products.shopOrder()
	local layoutOrder = 0
	local pityData = self.snapshot.pity or {}

	for _, section in ipairs(order) do
		for _, product in ipairs(section.items) do
			if product then
				layoutOrder += 1
				if product.eggId and pityData[product.eggId] then
					self:renderExclusiveEgg(product, pityData[product.eggId], layoutOrder)
				else
					self:renderProduct(product, layoutOrder)
				end
			end
		end
	end
end

--- Exclusive egg card with the Pity Timer bar (the requested improvement).
function ShopPanel:renderExclusiveEgg(product: any, pity: any, layoutOrder: number)
	local theme = self.theme

	local card = theme.panel(self.scroll, {
		name = product.name,
		layoutOrder = layoutOrder,
		size = UDim2.fromOffset(340, 196),
		color = theme.Colors.panel,
		transparency = 0.05,
		strokeColor = theme.Colors.strokeSoft,
		padding = 12,
	})
	card.LayoutOrder = layoutOrder

	local eggDef = Config.ExclusiveEggs[product.eggId]
	theme.label(card, {
		text = eggDef and eggDef.displayName or product.name,
		size = UDim2.new(1, -140, 0, 22),
		position = UDim2.fromOffset(0, 0),
		font = theme.Fonts.display,
		textSize = 17,
	})

	theme.label(card, {
		text = string.format("%d hatches", product.amount or 1),
		size = UDim2.new(0, 120, 0, 16),
		position = UDim2.fromOffset(0, 24),
		color = theme.Colors.muted,
		textSize = 11,
	})

	-- Top tier odds summary
	local oddsText = {}
	for _, row in ipairs(pity.odds or {}) do
		if row.class ~= "Standard" then
			table.insert(oddsText, string.format("%s %s", row.class, NumberFormatter.odds(row.chance)))
		end
	end
	theme.label(card, {
		text = table.concat(oddsText, "  |  "),
		size = UDim2.new(1, 0, 0, 16),
		position = UDim2.fromOffset(0, 42),
		color = theme.Colors.cyan,
		textSize = 10,
	})

	-- Pity bars, one per tracked class.
	local y = 66
	for _, bar in ipairs(pity.bars or {}) do
		local classDef = Config.Classes[bar.class] or Config.Classes.Standard
		local row = theme.panel(card, {
			size = UDim2.new(1, 0, 0, 32),
			position = UDim2.fromOffset(0, y),
			corner = true,
			radius = UDim.new(0, 8),
			color = theme.Colors.panelAlt,
			transparency = 0.3,
			stroke = false,
		})

		theme.label(row, {
			text = string.format("%s PITY", string.upper(classDef.displayName)),
			size = UDim2.new(0.5, -8, 0, 12),
			position = UDim2.fromOffset(8, 3),
			color = theme.fromHex(classDef.color),
			textSize = 9,
			font = theme.Fonts.bold,
		})

		theme.label(row, {
			text = if bar.guaranteedNext
				then "GUARANTEED NEXT HATCH"
				else string.format("%d / %d", bar.counter, bar.hardPity),
			size = UDim2.new(0.5, -8, 0, 12),
			position = UDim2.new(0.5, 0, 0, 3),
			color = if bar.guaranteedNext then theme.Colors.gold else theme.Colors.muted,
			textSize = 9,
			xAlign = Enum.TextXAlignment.Right,
			font = theme.Fonts.bold,
		})

		theme.progressBar(row, {
			size = UDim2.new(1, -16, 0, 7),
			position = UDim2.fromOffset(8, 19),
			color = if bar.guaranteedNext then theme.Colors.gold else theme.fromHex(classDef.color),
			progress = bar.progress,
		})

		y += 38
	end

	local buyButton = theme.button(card, {
		text = string.format("R$ %d", product.robux),
		variant = "robux",
		size = UDim2.fromOffset(110, 40),
		position = UDim2.new(1, 0, 1, 0),
		anchor = Vector2.new(1, 1),
		textSize = 15,
	})
	buyButton.Activated = function()
		self:purchase(product)
	end

	theme.label(card, {
		text = string.format("%d hatches", product.amount or 1),
		size = UDim2.fromOffset(80, 16),
		position = UDim2.new(1, -120, 1, -44),
		color = theme.Colors.muted,
		textSize = 10,
		xAlign = Enum.TextXAlignment.Right,
	})
end

function ShopPanel:renderProduct(product: any, layoutOrder: number)
	local theme = self.theme

	local card = theme.panel(self.scroll, {
		name = product.name,
		size = UDim2.fromOffset(340, 196),
		color = theme.Colors.panel,
		transparency = 0.05,
		strokeColor = theme.Colors.strokeSoft,
		padding = 12,
	})
	card.LayoutOrder = layoutOrder

	theme.label(card, {
		text = product.name,
		size = UDim2.new(1, -20, 0, 22),
		font = theme.Fonts.display,
		textSize = 17,
	})

	local y = 32
	for _, perk in ipairs(product.perks or {}) do
		theme.label(card, {
			text = "• " .. perk,
			size = UDim2.new(1, -10, 0, 18),
			position = UDim2.fromOffset(0, y),
			color = theme.Colors.muted,
			textSize = 11,
		})
		y += 20
	end

	local owned = self.snapshot and self.snapshot.entitlements and self.snapshot.entitlements[
		(product.name == "VIP" and "vip")
			or (product.name == "Auto-Tap" and "autoTap")
			or (product.name == "+10 Team Slots" and "teamSlots10")
			or (product.name == "+25 Team Slots" and "teamSlots25")
			or (product.name == "Lucky Pass" and "lucky")
			or (product.name == "Shiny Hunter" and "shinyHunter")
			or ""
	]

	local button = theme.button(card, {
		text = if owned then "OWNED" else string.format("R$ %d", product.robux or 0),
		variant = if owned then "ghost" else "robux",
		size = UDim2.fromOffset(120, 40),
		position = UDim2.new(1, 0, 1, 0),
		anchor = Vector2.new(1, 1),
		textSize = 14,
	})
	button.Activated = function()
		if not owned then
			self:purchase(product)
		end
	end
end

-- ===========================================================================
-- Purchases
-- ===========================================================================

function ShopPanel:purchase(product: any)
	local id = product.productId or 0
	if id == 0 then
		if self.callbacks and self.callbacks.onToast then
			self.callbacks.onToast(string.format("%s is not configured yet (add its productId in Config/Products.lua).", product.name))
		end
		return
	end

	if product.perks then
		MarketplaceService:PromptGamePassPurchase(player, id)
	else
		MarketplaceService:PromptProductPurchase(player, id)
	end
end

function ShopPanel:setSnapshot(snapshot: any)
	self.snapshot = snapshot
	if self.frame.Visible then
		self:render()
	end
end

function ShopPanel:show()
	self.frame.Visible = true
	if self.snapshot then
		self:render()
	else
		self.emptyLabel.Visible = true
		-- Ask the server for the latest (ShopState is pushed on join and hatch,
		-- this covers a client that opened the shop before the first push).
		task.delay(0.5, function()
			if self.snapshot == nil and self.frame.Visible then
				self.emptyLabel.Text = "Shop data is still loading. Try again in a moment."
			end
		end)
	end
end

function ShopPanel:hide()
	self.frame.Visible = false
end

function ShopPanel:toggle()
	if self.frame.Visible then
		self:hide()
	else
		self:show()
	end
end

return ShopPanel
