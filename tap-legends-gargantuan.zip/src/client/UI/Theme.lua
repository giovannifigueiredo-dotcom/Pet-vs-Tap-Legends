--!nonstrict
--[[
	Theme.lua
	=========
	The visual language: dark navy glass panels, 14px rounding, soft strokes,
	vibrant accents, and ONE green reserved for Robux actions (the "Robux green"
	button language from the reference shop).

	All builders return the created instance so screens can compose quickly.
	Mobile first: nothing smaller than 44px tap target, all text uses Gotham,
	and the whole GUI is wrapped in a UIScale driven by viewport size.
]]

local Theme = {}

Theme.Colors = {
	background = Color3.fromRGB(12, 14, 26),
	panel = Color3.fromRGB(22, 25, 43),
	panelAlt = Color3.fromRGB(30, 34, 57),
	panelHi = Color3.fromRGB(40, 46, 76),
	stroke = Color3.fromRGB(58, 66, 102),
	strokeSoft = Color3.fromRGB(40, 46, 74),

	text = Color3.fromRGB(238, 242, 255),
	muted = Color3.fromRGB(146, 156, 186),
	dim = Color3.fromRGB(96, 104, 132),

	green = Color3.fromRGB(84, 227, 138), -- Robux / purchase ONLY
	greenDark = Color3.fromRGB(38, 156, 88),
	blue = Color3.fromRGB(74, 168, 255),
	purple = Color3.fromRGB(196, 107, 255),
	pink = Color3.fromRGB(255, 122, 217),
	gold = Color3.fromRGB(255, 197, 61),
	orange = Color3.fromRGB(255, 107, 74),
	red = Color3.fromRGB(255, 91, 118),
	cyan = Color3.fromRGB(125, 232, 255),
}

Theme.Fonts = {
	display = Enum.Font.GothamBlack,
	bold = Enum.Font.GothamBold,
	medium = Enum.Font.GothamMedium,
	regular = Enum.Font.Gotham,
}

Theme.Corner = {
	card = UDim.new(0, 12),
	panel = UDim.new(0, 16),
	pill = UDim.new(1, 0),
}

Theme.Spacing = {
	xs = 4,
	sm = 8,
	md = 12,
	lg = 18,
	xl = 28,
}

-- ===========================================================================
-- Builders
-- ===========================================================================

function Theme.corner(parent: Instance, radius: UDim?): UICorner
	local corner = Instance.new("UICorner")
	corner.CornerRadius = radius or Theme.Corner.card
	corner.Parent = parent
	return corner
end

function Theme.stroke(parent: Instance, color: Color3?, thickness: number?): UIStroke
	local stroke = Instance.new("UIStroke")
	stroke.Color = color or Theme.Colors.stroke
	stroke.Thickness = thickness or 1
	stroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	stroke.Parent = parent
	return stroke
end

function Theme.gradient(parent: Instance, top: Color3?, bottom: Color3?, rotation: number?): UIGradient
	local gradient = Instance.new("UIGradient")
	gradient.Color = ColorSequence.new(top or Theme.Colors.panelHi, bottom or Theme.Colors.panel)
	gradient.Rotation = rotation or 90
	gradient.Parent = parent
	return gradient
end

--- Base panel: rounded, stroked, gradient. Use for every surface.
function Theme.panel(parent: Instance, props: { [string]: any }?): Frame
	local options = props or {}
	local frame = Instance.new("Frame")
	frame.Name = options.name or "Panel"
	frame.BackgroundColor3 = options.color or Theme.Colors.panel
	frame.BackgroundTransparency = options.transparency or 0.08
	frame.BorderSizePixel = 0
	frame.Size = options.size or UDim2.fromOffset(320, 240)
	frame.Position = options.position or UDim2.fromOffset(0, 0)
	frame.AnchorPoint = options.anchor or Vector2.zero
	frame.Visible = options.visible ~= false
	frame.LayoutOrder = options.layoutOrder or 0
	frame.Parent = parent

	if options.corner ~= false then
		Theme.corner(frame, options.radius or Theme.Corner.panel)
	end
	if options.stroke ~= false then
		Theme.stroke(frame, options.strokeColor, options.strokeThickness)
	end
	if options.gradient then
		Theme.gradient(frame, options.gradient[1], options.gradient[2])
	end

	if options.padding then
		local padding = Instance.new("UIPadding")
		padding.PaddingTop = UDim.new(0, options.padding)
		padding.PaddingBottom = UDim.new(0, options.padding)
		padding.PaddingLeft = UDim.new(0, options.padding)
		padding.PaddingRight = UDim.new(0, options.padding)
		padding.Parent = frame
	end

	return frame
end

function Theme.label(parent: Instance, props: { [string]: any }): TextLabel
	local options = props or {}
	local label = Instance.new("TextLabel")
	label.Name = options.name or "Label"
	label.BackgroundTransparency = 1
	label.Size = options.size or UDim2.new(1, 0, 0, 20)
	label.Position = options.position or UDim2.fromOffset(0, 0)
	label.Font = options.font or Theme.Fonts.medium
	label.Text = options.text or ""
	label.TextColor3 = options.color or Theme.Colors.text
	label.TextSize = options.textSize or 14
	label.TextXAlignment = options.xAlign or Enum.TextXAlignment.Left
	label.TextYAlignment = options.yAlign or Enum.TextYAlignment.Center
	label.TextTruncate = Enum.TextTruncate.AtEnd
	label.RichText = options.rich or false
	label.Parent = parent
	return label
end

--- Standard action button. `variant = "robux"` gets the reserved green.
function Theme.button(parent: Instance, props: { [string]: any }?): TextButton
	local options = props or {}
	local variant = options.variant or "default"
	local fill = options.color
	if not fill then
		if variant == "robux" then
			fill = Theme.Colors.green
		elseif variant == "primary" then
			fill = Theme.Colors.blue
		elseif variant == "danger" then
			fill = Theme.Colors.red
		elseif variant == "ghost" then
			fill = Theme.Colors.panelAlt
		else
			fill = Theme.Colors.panelHi
		end
	end

	local button = Instance.new("TextButton")
	button.Name = options.name or "Button"
	button.BackgroundColor3 = fill
	button.BackgroundTransparency = options.transparency or 0
	button.BorderSizePixel = 0
	button.AutoButtonColor = true
	button.Size = options.size or UDim2.fromOffset(120, 44)
	button.Position = options.position or UDim2.fromOffset(0, 0)
	button.AnchorPoint = options.anchor or Vector2.zero
	button.Font = options.font or Theme.Fonts.bold
	button.Text = options.text or ""
	button.TextColor3 = options.textColor or (if variant == "robux" then Color3.fromRGB(10, 40, 22) else Theme.Colors.text)
	button.TextSize = options.textSize or 15
	button.Visible = options.visible ~= false
	button.LayoutOrder = options.layoutOrder or 0
	button.Parent = parent

	Theme.corner(button, options.radius or Theme.Corner.card)
	if variant ~= "ghost" then
		Theme.stroke(button, options.strokeColor or fill:Lerp(Color3.new(1, 1, 1), 0.35), 1)
	end

	if options.icon then
		local icon = Instance.new("ImageLabel")
		icon.BackgroundTransparency = 1
		icon.Image = options.icon
		icon.Size = UDim2.fromOffset(options.iconSize or 18, options.iconSize or 18)
		icon.Position = UDim2.new(0, 10, 0.5, 0)
		icon.AnchorPoint = Vector2.new(0, 0.5)
		icon.Parent = button
	end

	return button
end

--- Small rounded chip (badges, filters, counts).
function Theme.pill(parent: Instance, props: { [string]: any }?): TextLabel
	local options = props or {}
	local pill = Instance.new("TextLabel")
	pill.Name = options.name or "Pill"
	pill.BackgroundColor3 = options.color or Theme.Colors.panelHi
	pill.BackgroundTransparency = options.transparency or 0
	pill.BorderSizePixel = 0
	pill.Size = options.size or UDim2.fromOffset(64, 22)
	pill.Position = options.position or UDim2.fromOffset(0, 0)
	pill.Font = options.font or Theme.Fonts.bold
	pill.Text = options.text or ""
	pill.TextColor3 = options.textColor or Theme.Colors.text
	pill.TextSize = options.textSize or 12
	pill.Parent = parent
	Theme.corner(pill, UDim.new(1, 0))
	return pill
end

--- Horizontal progress bar with a fill child returned for tweening.
function Theme.progressBar(parent: Instance, props: { [string]: any }?): (Frame, Frame)
	local options = props or {}
	local track = Instance.new("Frame")
	track.Name = options.name or "ProgressTrack"
	track.BackgroundColor3 = Theme.Colors.panelAlt
	track.BorderSizePixel = 0
	track.Size = options.size or UDim2.new(1, 0, 0, 10)
	track.Position = options.position or UDim2.fromOffset(0, 0)
	track.Parent = parent
	Theme.corner(track, UDim.new(1, 0))

	local fill = Instance.new("Frame")
	fill.Name = "Fill"
	fill.BackgroundColor3 = options.color or Theme.Colors.green
	fill.BorderSizePixel = 0
	fill.Size = UDim2.fromScale(math.clamp(options.progress or 0, 0, 1), 1)
	fill.Parent = track
	Theme.corner(fill, UDim.new(1, 0))

	return track, fill
end

function Theme.scrollingGrid(parent: Instance, props: { [string]: any }?): (ScrollingFrame, UIGridLayout)
	local options = props or {}
	local scroll = Instance.new("ScrollingFrame")
	scroll.Name = options.name or "Scroll"
	scroll.BackgroundTransparency = 1
	scroll.BorderSizePixel = 0
	scroll.ScrollBarThickness = 5
	scroll.ScrollBarImageColor3 = Theme.Colors.stroke
	scroll.CanvasSize = UDim2.new(0, 0, 0, 0)
	scroll.AutomaticCanvasSize = Enum.AutomaticSize.Y
	scroll.ScrollingDirection = Enum.ScrollingDirection.Y
	scroll.Size = options.size or UDim2.new(1, 0, 1, 0)
	scroll.Position = options.position or UDim2.fromOffset(0, 0)
	scroll.Parent = parent

	local padding = Instance.new("UIPadding")
	padding.PaddingRight = UDim.new(0, 6)
	padding.Parent = scroll

	local grid = Instance.new("UIGridLayout")
	grid.CellSize = options.cellSize or UDim2.fromOffset(112, 128)
	grid.CellPadding = options.cellPadding or UDim2.fromOffset(10, 10)
	grid.SortOrder = Enum.SortOrder.LayoutOrder
	grid.HorizontalAlignment = Enum.HorizontalAlignment.Left
	grid.Parent = scroll

	return scroll, grid
end

-- ===========================================================================
-- Responsive scaling
-- ===========================================================================

--[[
	Reference resolution 1280x720. Phones get a slightly larger scale so tap
	targets stay above 44px, desktop caps at 1.15 so panels do not become
	comically large on 4K.
]]
function Theme.applyResponsiveScale(screenGui: ScreenGui)
	local scale = Instance.new("UIScale")
	scale.Parent = screenGui

	local function refresh()
		local camera = workspace.CurrentCamera
		local size = if camera then camera.ViewportSize else Vector2.new(1280, 720)
		local factor = math.clamp(math.min(size.X / 1280, size.Y / 720), 0.72, 1.15)
		if size.Y > size.X then
			-- portrait phone: prioritize tap targets
			factor = math.clamp(size.X / 900, 0.75, 1.0)
		end
		scale.Scale = factor
	end

	refresh()
	local camera = workspace.CurrentCamera
	if camera then
		camera:GetPropertyChangedSignal("ViewportSize"):Connect(refresh)
	end
	return scale
end

function Theme.fromHex(hex: string): Color3
	local cleaned = hex:gsub("#", "")
	local value = tonumber(cleaned, 16) or 0xFFFFFF
	return Color3.fromRGB(
		bit32.band(bit32.rshift(value, 16), 255),
		bit32.band(bit32.rshift(value, 8), 255),
		bit32.band(value, 255)
	)
end

return Theme
