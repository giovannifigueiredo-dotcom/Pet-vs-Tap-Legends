--!nonstrict
--[[
	InventoryScreen.lua
	===================
	The "massive inventory" screen: grid of pet cards, side-scrolling category
	nav, custom folders, and advanced filters/sorts (Power, Synergy, Element,
	Tap Multiplier, Rarity, Level, Newest, Name).

	Data path:
	  - InventorySync pushes the full collection for the vertical slice
	  - GetInventoryPage is also wired for large accounts: it pages/sorts on the
	    SERVER with the same InventoryQuery module the client would use, so the
	    two can never disagree about ordering.

	Selection model:
	  - click a card: select for the detail panel
	  - click "Select" mode: multi-select up to maxSlots, then EQUIP SELECTED
	  - Quick Compare: hovering a card calls onCompare(cardPet)
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(Shared.Config.GameConfig)
local Remotes = require(Shared.Net.Remotes)
local MultiplierEngine = require(Shared.Modules.MultiplierEngine)
local NumberFormatter = require(Shared.Modules.NumberFormatter)
local InventoryQuery = require(Shared.Modules.InventoryQuery)

local InventoryScreen = {}
InventoryScreen.__index = InventoryScreen

local CATEGORIES = { "Pets", "Eggs", "Enchants", "Potions", "Relics" }

local SORT_ORDER = { "power", "synergy", "element", "tapMultiplier", "class", "level", "newest", "name" }
local SORT_LABEL = {
	power = "Power",
	synergy = "Synergy",
	element = "Element",
	tapMultiplier = "Tap Multiplier",
	["class"] = "Rarity",
	level = "Level",
	newest = "Newest",
	name = "Name",
}

function InventoryScreen.new(parent: Instance, theme: any, callbacks: any)
	local self = setmetatable({}, InventoryScreen)
	self.theme = theme
	self.callbacks = callbacks
	self.pets = {}
	self.equippedUids = {}
	self.selectedUid = nil
	self.multiSelect = {}
	self.multiSelectMode = false
	self.sort = "power"
	self.filters = { element = "All", family = "All", ["class"] = "All", search = "" }
	self.folderFilter = nil
	self.folders = {}
	self.category = "Pets"
	self.page = 1
	self.pageSize = 60
	self.total = 0

	self:build(parent)
	return self
end

-- ===========================================================================
-- Layout
-- ===========================================================================

function InventoryScreen:build(parent: Instance)
	local theme = self.theme

	local root = theme.panel(parent, {
		name = "Inventory",
		size = UDim2.new(1, -80, 1, -140),
		position = UDim2.new(0.5, 0, 0.5, -10),
		anchor = Vector2.new(0.5, 0.5),
		color = theme.Colors.background,
		transparency = 0.04,
		visible = false,
	})
	self.frame = root

	theme.label(root, {
		text = "INVENTORY",
		size = UDim2.new(0, 200, 0, 26),
		position = UDim2.fromOffset(20, 14),
		font = theme.Fonts.display,
		textSize = 20,
	})

	self.countLabel = theme.label(root, {
		text = "0 pets",
		size = UDim2.new(0, 220, 0, 20),
		position = UDim2.fromOffset(20, 40),
		color = theme.Colors.muted,
		textSize = 12,
	})

	self.closeButton = theme.button(root, {
		text = "X",
		size = UDim2.fromOffset(40, 40),
		position = UDim2.new(1, -52, 0, 14),
		variant = "ghost",
	})
	self.closeButton.Activated = function()
		self:hide()
	end

	self:buildCategoryNav(root)

	-- Search + sort + filters toolbar
	local toolbar = theme.panel(root, {
		name = "Toolbar",
		size = UDim2.new(1, -220, 0, 52),
		position = UDim2.fromOffset(140, 78),
		corner = true,
		color = theme.Colors.panel,
		transparency = 0.1,
		padding = 8,
	})

	self.searchBox = Instance.new("TextBox")
	self.searchBox.Size = UDim2.fromOffset(180, 34)
	self.searchBox.BackgroundColor3 = theme.Colors.panelAlt
	self.searchBox.BorderSizePixel = 0
	self.searchBox.PlaceholderText = "Search pets, elements..."
	self.searchBox.Text = ""
	self.searchBox.TextColor3 = theme.Colors.text
	self.searchBox.PlaceholderColor3 = theme.Colors.dim
	self.searchBox.Font = theme.Fonts.medium
	self.searchBox.TextSize = 13
	self.searchBox.ClearTextOnFocus = false
	self.searchBox.Parent = toolbar
	theme.corner(self.searchBox, UDim.new(0, 8))
	self.searchBox:GetPropertyChangedSignal("Text"):Connect(function()
		self.filters.search = self.searchBox.Text
		self.page = 1
		self:refresh()
	end)

	self.sortButton = theme.button(toolbar, {
		text = "Sort: Power",
		size = UDim2.fromOffset(150, 34),
		position = UDim2.fromOffset(190, 0),
		variant = "ghost",
		textSize = 12,
	})
	self.sortButton.Activated = function()
		self:cycleSort()
	end

	self.elementButton = theme.button(toolbar, {
		text = "Element: All",
		size = UDim2.fromOffset(130, 34),
		position = UDim2.fromOffset(348, 0),
		variant = "ghost",
		textSize = 12,
	})
	self.elementButton.Activated = function()
		self:cycleElement()
	end

	self.classButton = theme.button(toolbar, {
		text = "Rarity: All",
		size = UDim2.fromOffset(120, 34),
		position = UDim2.fromOffset(486, 0),
		variant = "ghost",
		textSize = 12,
	})
	self.classButton.Activated = function()
		self:cycleClass()
	end

	self.selectButton = theme.button(toolbar, {
		text = "Select",
		size = UDim2.fromOffset(92, 34),
		position = UDim2.new(1, -240, 0, 0),
		variant = "ghost",
		textSize = 12,
	})
	self.selectButton.Activated = function()
		self.multiSelectMode = not self.multiSelectMode
		self.multiSelect = {}
		self.selectButton.BackgroundColor3 = if self.multiSelectMode then theme.Colors.blue else theme.Colors.panelHi
		self:refresh()
	end

	self.equipSelected = theme.button(toolbar, {
		text = "EQUIP SELECTED",
		size = UDim2.fromOffset(140, 34),
		position = UDim2.new(1, -142, 0, 0),
		variant = "primary",
		textSize = 12,
	})
	self.equipSelected.Activated = function()
		self:equipSelection()
	end

	self:buildFolders(root)

	local scroll, grid = theme.scrollingGrid(root, {
		name = "PetGrid",
		size = UDim2.new(1, -220, 1, -160),
		position = UDim2.fromOffset(140, 140),
		cellSize = UDim2.fromOffset(108, 126),
		cellPadding = UDim2.fromOffset(8, 8),
	})
	self.scroll = scroll
	self.grid = grid

	self:buildPager(root)
end

function InventoryScreen:buildCategoryNav(root: Instance)
	local theme = self.theme
	local nav = theme.panel(root, {
		name = "Categories",
		size = UDim2.fromOffset(104, 0),
		position = UDim2.fromOffset(16, 78),
		sizeConstraint = nil,
		corner = true,
		color = theme.Colors.panelAlt,
		transparency = 0.15,
	})
	nav.Size = UDim2.new(0, 104, 1, -160)

	local layout = Instance.new("UIListLayout")
	layout.Padding = UDim.new(0, 6)
	layout.SortOrder = Enum.SortOrder.LayoutOrder
	layout.Parent = nav

	local padding = Instance.new("UIPadding")
	padding.PaddingTop = UDim.new(0, 8)
	padding.PaddingLeft = UDim.new(0, 8)
	padding.PaddingRight = UDim.new(0, 8)
	padding.Parent = nav

	self.categoryButtons = {}
	for index, category in ipairs(CATEGORIES) do
		local button = theme.button(nav, {
			text = category,
			size = UDim2.new(1, 0, 0, 40),
			variant = if category == "Pets" then "primary" else "ghost",
			layoutOrder = index,
			textSize = 13,
		})
		button.Activated = function()
			self:setCategory(category)
		end
		self.categoryButtons[category] = button
	end
end

function InventoryScreen:buildFolders(root: Instance)
	local theme = self.theme
	local bar = theme.panel(root, {
		name = "Folders",
		size = UDim2.new(1, -220, 0, 38),
		position = UDim2.fromOffset(140, 264),
		corner = true,
		color = theme.Colors.panel,
		transparency = 0.2,
		stroke = false,
	})

	local scroll = Instance.new("ScrollingFrame")
	scroll.Name = "FolderScroll"
	scroll.BackgroundTransparency = 1
	scroll.Size = UDim2.fromScale(1, 1)
	scroll.ScrollBarThickness = 0
	scroll.ScrollingDirection = Enum.ScrollingDirection.X
	scroll.AutomaticCanvasSize = Enum.AutomaticSize.X
	scroll.CanvasSize = UDim2.new(0, 0, 0, 0)
	scroll.Parent = bar

	local layout = Instance.new("UIListLayout")
	layout.FillDirection = Enum.FillDirection.Horizontal
	layout.Padding = UDim.new(0, 6)
	layout.VerticalAlignment = Enum.VerticalAlignment.Center
	layout.Parent = scroll

	local padding = Instance.new("UIPadding")
	padding.PaddingLeft = UDim.new(0, 8)
	padding.Parent = scroll
	self.folderScroll = scroll

end

function InventoryScreen:buildPager(root: Instance)
	local theme = self.theme
	self.pageLabel = theme.label(root, {
		text = "Page 1 / 1",
		size = UDim2.fromOffset(140, 24),
		position = UDim2.new(1, -300, 1, -44),
		color = theme.Colors.muted,
		xAlign = Enum.TextXAlignment.Center,
		textSize = 12,
	})

	local prev = theme.button(root, {
		text = "<",
		size = UDim2.fromOffset(34, 30),
		position = UDim2.new(1, -344, 1, -47),
		variant = "ghost",
	})
	prev.Activated = function()
		self.page = math.max(1, self.page - 1)
		self:refresh()
	end

	local next = theme.button(root, {
		text = ">",
		size = UDim2.fromOffset(34, 30),
		position = UDim2.new(1, -150, 1, -47),
		variant = "ghost",
	})
	next.Activated = function()
		self.page += 1
		self:refresh()
	end
end

-- ===========================================================================
-- Data
-- ===========================================================================

function InventoryScreen:setData(payload: any)
	self.pets = payload.pets or {}
	self.equippedUids = payload.equipped or {}
	self.folders = payload.folders or {}
	self.maxSlots = payload.maxSlots or Config.Balance.Team.baseSlots
	self.eggPity = payload.eggPity or {}
	self:renderFolders()
	self:refresh()
end

--- Current page, sorted/filtered CLIENT side (server paging is available for
--- collections over the page size; the shared module guarantees identical order).
function InventoryScreen:visiblePets(): { any }
	local team = {}
	for _, uid in ipairs(self.equippedUids) do
		for _, pet in ipairs(self.pets) do
			if pet.uid == uid then
				table.insert(team, pet)
				break
			end
		end
	end
	self.team = team

	local membership = InventoryQuery.folderMembership(self.folders)
	local filters = table.clone(self.filters)
	if self.folderFilter then
		filters.folderId = self.folderFilter
		filters.folderMembership = membership
	end

	local result = InventoryQuery.query(self.pets, Config.Pets, {
		filters = filters,
		sort = self.sort,
		page = self.page,
		pageSize = self.pageSize,
		team = team,
		engine = MultiplierEngine,
		config = Config,
	})
	self.total = result.total
	self.pageCount = result.pageCount
	return result.rows
end

function InventoryScreen:refresh()
	if self.category ~= "Pets" then
		self:renderComingSoon()
		return
	end

	local rows = self:visiblePets()
	for _, child in ipairs(self.scroll:GetChildren()) do
		if child:IsA("TextButton") then
			child:Destroy()
		end
	end

	for index, row in ipairs(rows) do
		self:renderCard(row, index)
	end

	self.countLabel.Text = string.format("%d pets  |  %d equipped / %d slots", self.total, #self.equippedUids, self.maxSlots or 0)
	self.pageLabel.Text = string.format("Page %d / %d", self.page, self.pageCount or 1)
end

function InventoryScreen:renderComingSoon()
	for _, child in ipairs(self.scroll:GetChildren()) do
		if child:IsA("TextButton") then
			child:Destroy()
		end
	end
	self.countLabel.Text = self.category .. " - coming in this slice's next milestone"
	self.pageLabel.Text = "Page 1 / 1"
end

function InventoryScreen:renderCard(row: any, index: number)
	local theme = self.theme
	local pet = row.pet or row
	local def = row.def or Config.Pets[pet.id]

	local card = Instance.new("TextButton")
	card.Name = pet.uid
	card.BackgroundColor3 = theme.Colors.panelAlt
	card.BackgroundTransparency = 0.08
	card.BorderSizePixel = 0
	card.AutoButtonColor = false
	card.Text = ""
	card.LayoutOrder = index
	card.Size = UDim2.fromOffset(108, 126)
	card.Parent = self.scroll
	theme.corner(card, UDim.new(0, 10))

	local elementColor = theme.fromHex(if def then Config.Elements.Definitions[def.element].color else "#B9C4D4")
	local stroke = theme.stroke(card, elementColor, 1.5)

	local classDef = Config.Classes[pet["class"] or "Standard"] or Config.Classes.Standard
	local isEquipped = false
	for _, uid in ipairs(self.equippedUids) do
		if uid == pet.uid then
			isEquipped = true
			break
		end
	end

	-- top rarity bar
	local bar = Instance.new("Frame")
	bar.BackgroundColor3 = theme.fromHex(classDef.color)
	bar.BorderSizePixel = 0
	bar.Size = UDim2.new(1, -16, 0, 4)
	bar.Position = UDim2.fromOffset(8, 8)
	bar.Parent = card
	theme.corner(bar, UDim.new(1, 0))

	theme.label(card, {
		text = def and def.name or pet.id,
		size = UDim2.new(1, -12, 0, 16),
		position = UDim2.fromOffset(6, 16),
		font = theme.Fonts.bold,
		textSize = 11,
		xAlign = Enum.TextXAlignment.Center,
	})

	theme.label(card, {
		text = string.format("Lv %d", pet.level or 1),
		size = UDim2.new(1, -12, 0, 14),
		position = UDim2.fromOffset(6, 32),
		color = theme.Colors.muted,
		textSize = 10,
		xAlign = Enum.TextXAlignment.Center,
	})

	local power = if row.power then row.power else MultiplierEngine.petPower(pet, Config)
	theme.label(card, {
		text = NumberFormatter.short(power),
		size = UDim2.new(1, -12, 0, 18),
		position = UDim2.fromOffset(6, 76),
		color = theme.Colors.gold,
		font = theme.Fonts.bold,
		textSize = 13,
		xAlign = Enum.TextXAlignment.Center,
	})

	if isEquipped then
		local badge = theme.pill(card, {
			text = "EQ",
			size = UDim2.fromOffset(26, 16),
			position = UDim2.fromOffset(6, 6),
			color = theme.Colors.blue,
			textSize = 9,
		})
		badge.ZIndex = 2
	end

	if self.multiSelect[pet.uid] then
		stroke.Color = theme.Colors.green
		stroke.Thickness = 2.5
	end

	card.MouseEnter:Connect(function()
		if self.callbacks and self.callbacks.onCompare then
			self.callbacks.onCompare(pet, self.team, self.equippedUids)
		end
	end)

	card.Activated = function()
		if self.multiSelectMode then
			if self.multiSelect[pet.uid] then
				self.multiSelect[pet.uid] = nil
			elseif self:selectionCount() < (self.maxSlots or 0) then
				self.multiSelect[pet.uid] = true
			end
			self:refresh()
		else
			self.selectedUid = pet.uid
			if self.callbacks and self.callbacks.onSelect then
				self.callbacks.onSelect(pet)
			end
		end
	end
end

function InventoryScreen:selectionCount(): number
	local count = 0
	for _ in pairs(self.multiSelect) do
		count += 1
	end
	return count
end

function InventoryScreen:equipSelection()
	local uids = {}
	for _, uid in ipairs(self.equippedUids) do
		table.insert(uids, uid)
	end
	for uid in pairs(self.multiSelect) do
		local present = false
		for _, existing in ipairs(uids) do
			if existing == uid then
				present = true
				break
			end
		end
		if not present then
			table.insert(uids, uid)
		end
	end

	local ok, result = pcall(function()
		return Remotes.fn("EquipPets"):InvokeServer(uids)
	end)
	if ok and result and result.ok then
		self.multiSelect = {}
		self.multiSelectMode = false
		self.selectButton.BackgroundColor3 = self.theme.Colors.panelHi
	elseif self.callbacks and self.callbacks.onError then
		self.callbacks.onError(result and result.reason or "equipFailed")
	end
end

-- ===========================================================================
-- Folders
-- ===========================================================================

function InventoryScreen:renderFolders()
	local theme = self.theme
	for _, child in ipairs(self.folderScroll:GetChildren()) do
		if child:IsA("TextButton") then
			child:Destroy()
		end
	end

	local allButton = theme.button(self.folderScroll, {
		name = "Folder_All",
		text = "All",
		size = UDim2.fromOffset(56, 28),
		variant = if self.folderFilter == nil then "primary" else "ghost",
		textSize = 11,
	})
	allButton.Activated = function()
		self.folderFilter = nil
		self.page = 1
		self:renderFolders()
		self:refresh()
	end

	for folderId, folder in pairs(self.folders) do
		local button = theme.button(self.folderScroll, {
			name = "Folder_" .. folderId,
			text = string.format("%s (%d)", folder.name, #folder.petUids),
			size = UDim2.fromOffset(112, 28),
			variant = if self.folderFilter == folderId then "primary" else "ghost",
			textSize = 11,
		})
		button.Activated = function()
			self.folderFilter = if self.folderFilter == folderId then nil else folderId
			self.page = 1
			self:renderFolders()
			self:refresh()
		end
	end

	local newFolder = theme.button(self.folderScroll, {
		name = "Folder_New",
		text = "+ Folder",
		size = UDim2.fromOffset(84, 28),
		variant = "ghost",
		textSize = 11,
	})
	newFolder.Activated = function()
		self:createFolder()
	end
end

function InventoryScreen:createFolder()
	local ok, result = pcall(function()
		return Remotes.fn("SetFolder"):InvokeServer("create", { name = "Folder" })
	end)
	if ok and result and result.ok then
		if self.callbacks and self.callbacks.onToast then
			self.callbacks.onToast("Folder created")
		end
	elseif self.callbacks and self.callbacks.onError then
		self.callbacks.onError(result and result.reason or "createFailed")
	end
end

function InventoryScreen:cycleSort()
	for index, id in ipairs(SORT_ORDER) do
		if id == self.sort then
			self.sort = SORT_ORDER[(index % #SORT_ORDER) + 1]
			break
		end
	end
	self.sortButton.Text = "Sort: " .. (SORT_LABEL[self.sort] or self.sort)
	self.page = 1
	self:refresh()
end

function InventoryScreen:cycleElement()
	local options = { "All" }
	for _, element in ipairs(Config.Elements.Order) do
		table.insert(options, element)
	end
	for index, value in ipairs(options) do
		if value == self.filters.element then
			self.filters.element = options[(index % #options) + 1]
			break
		end
	end
	self.elementButton.Text = "Element: " .. self.filters.element
	self.page = 1
	self:refresh()
end

function InventoryScreen:cycleClass()
	local options = { "All", "Standard", "Huge", "Titanic", "Gargantuan" }
	for index, value in ipairs(options) do
		if value == self.filters["class"] then
			self.filters["class"] = options[(index % #options) + 1]
			break
		end
	end
	self.classButton.Text = "Rarity: " .. (if self.filters["class"] == "All" then "All" else Config.Classes[self.filters["class"]].displayName)
	self.page = 1
	self:refresh()
end

function InventoryScreen:setCategory(category: string)
	self.category = category
	for name, button in pairs(self.categoryButtons) do
		button.BackgroundColor3 = if name == category then self.theme.Colors.blue else self.theme.Colors.panelHi
	end
	self:refresh()
end

function InventoryScreen:show()
	self.frame.Visible = true
	self:refresh()
end

function InventoryScreen:hide()
	self.frame.Visible = false
end

function InventoryScreen:toggle()
	if self.frame.Visible then
		self:hide()
	else
		self:show()
	end
end

return InventoryScreen
