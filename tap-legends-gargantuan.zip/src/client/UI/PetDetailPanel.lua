--!nonstrict
--[[
	PetDetailPanel.lua
	==================
	Right-side pet detail panel inspired by the PS99 reference:

	  - top: LIVE 3D pet render (ViewportFrame + WorldModel + orbiting camera)
	    instead of a static image
	  - middle: the clear stat stack the reference does well
	      POWER  |  GEMS BONUS  |  WEIGHT  |  LEVEL progress
	  - bottom: enchants, variants, class aura, and the Equip action
	  - Quick Compare: hovering any inventory card shows this pet's power delta
	    against the weakest equipped pet, plus synergy fit with the current team

	The 3D pet is built procedurally (no art dependency) from the pet's element
	colour so every pet in the dex renders uniquely today.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(Shared.Config.GameConfig)
local MultiplierEngine = require(Shared.Modules.MultiplierEngine)
local NumberFormatter = require(Shared.Modules.NumberFormatter)

local PetDetailPanel = {}
PetDetailPanel.__index = PetDetailPanel

local PANEL_WIDTH = 300

function PetDetailPanel.new(parent: Instance, theme: any, onEquip: ((any) -> ())?)
	local self = setmetatable({}, PetDetailPanel)
	self.theme = theme
	self.visible = false
	self.currentPet = nil
	self.build = nil
	self.onEquip = onEquip

	local panel = theme.panel(parent, {
		name = "PetDetail",
		size = UDim2.fromOffset(PANEL_WIDTH, 560),
		position = UDim2.new(1, -18, 0.5, 0),
		anchor = Vector2.new(1, 0.5),
		color = theme.Colors.panel,
		gradient = { Color3.fromRGB(34, 38, 63), Color3.fromRGB(18, 21, 36) },
		padding = 0,
		visible = false,
	})
	self.frame = panel

	self:buildHeader()
	self:buildViewport()
	self:buildStats()
	self:buildActions()
	return self
end

-- ===========================================================================
-- Header
-- ===========================================================================

function PetDetailPanel:buildHeader()
	local theme = self.theme
	self.nameLabel = theme.label(self.frame, {
		name = "PetName",
		text = "No pet selected",
		size = UDim2.new(1, -32, 0, 24),
		position = UDim2.fromOffset(16, 12),
		font = theme.Fonts.display,
		textSize = 18,
	})
	self.classPill = theme.pill(self.frame, {
		name = "ClassPill",
		text = "NORMAL",
		size = UDim2.fromOffset(82, 20),
		position = UDim2.fromOffset(16, 38),
		color = theme.Colors.panelHi,
		textSize = 11,
	})
	self.variantPill = theme.pill(self.frame, {
		name = "VariantPill",
		text = "",
		size = UDim2.fromOffset(90, 20),
		position = UDim2.fromOffset(104, 38),
		color = theme.Colors.panelHi,
		textSize = 11,
	})
end

-- ===========================================================================
-- 3D viewport
-- ===========================================================================

function PetDetailPanel:buildViewport()
	local theme = self.theme
	local frame = theme.panel(self.frame, {
		name = "PetViewport",
		size = UDim2.new(1, -32, 0, 150),
		position = UDim2.fromOffset(16, 66),
		corner = true,
		radius = UDim.new(0, 14),
		strokeColor = theme.Colors.strokeSoft,
		gradient = { Color3.fromRGB(46, 52, 86), Color3.fromRGB(20, 24, 42) },
	})
	self.viewportFrame = frame

	local viewport = Instance.new("ViewportFrame")
	viewport.Name = "Viewport"
	viewport.BackgroundTransparency = 1
	viewport.Size = UDim2.fromScale(1, 1)
	viewport.Ambient = Color3.fromRGB(180, 190, 220)
	viewport.LightColor = Color3.fromRGB(255, 255, 255)
	viewport.LightDirection = Vector3.new(-0.4, -1, -0.6)
	viewport.Parent = frame

	local world = Instance.new("WorldModel")
	world.Name = "PetWorld"
	world.Parent = viewport

	local model = Instance.new("Model")
	model.Name = "Pet"
	model.Parent = world
	self.petModel = model
	self.world = world

	local camera = Instance.new("Camera")
	camera.FieldOfView = 40
	camera.CFrame = CFrame.new(Vector3.new(0, 1.4, 4.2), Vector3.new(0, 0.6, 0))
	camera.Parent = viewport
	viewport.CurrentCamera = camera
	self.camera = camera

	self.orbit = 0
	-- Orbit the camera for a "living" preview. Cheap: one CFrame set per frame.
	local runService = game:GetService("RunService")
	self.orbitConnection = runService.RenderStepped:Connect(function(dt)
		if not self.frame.Visible or not self.petModel then
			return
		end
		self.orbit += dt * 0.5
		local radius = 4.2
		local x = math.sin(self.orbit) * radius
		local z = math.cos(self.orbit) * radius
		self.camera.CFrame = CFrame.new(Vector3.new(x, 1.5, z), Vector3.new(0, 0.65, 0))
	end)
end

--- Rebuild the procedural pet model from the element colour + class scale.
function PetDetailPanel:renderPet(petInfo: any?)
	if self.petModel then
		self.petModel:ClearAllChildren()
	end
	if not petInfo then
		return
	end

	local theme = self.theme
	local elementDef = Config.Elements and Config.Elements.Definitions and Config.Elements.Definitions[petInfo.element]
	local baseColor = if elementDef then theme.fromHex(elementDef.color) else theme.Colors.cyan

	local classScale = ({
		Standard = 1,
		Huge = 1.35,
		Titanic = 1.7,
		Gargantuan = 2.1,
	})[petInfo["class"] or "Standard"] or 1

	local function part(shape: Enum.PartType, size: Vector3, cframe: CFrame, color: Color3)
		local piece = Instance.new("Part")
		piece.Shape = shape
		piece.Size = size
		piece.CFrame = cframe
		piece.Color = color
		piece.Material = Enum.Material.Neon
		piece.Anchored = true
		piece.CanCollide = false
		piece.Parent = self.petModel
		return piece
	end

	-- body, head, ears, feet: readable silhouette at small viewport sizes
	part(Enum.PartType.Ball, Vector3.new(1.15, 1.0, 1.05), CFrame.new(0, 0.45, 0), baseColor:Lerp(Color3.new(0, 0, 0), 0.15))
	part(Enum.PartType.Ball, Vector3.new(0.9, 0.85, 0.85), CFrame.new(0, 1.15, 0), baseColor)
	part(Enum.PartType.Block, Vector3.new(0.26, 0.34, 0.2), CFrame.new(-0.3, 1.62, 0) * CFrame.Angles(0, 0, math.rad(18)), baseColor:Lerp(Color3.new(1, 1, 1), 0.15))
	part(Enum.PartType.Block, Vector3.new(0.26, 0.34, 0.2), CFrame.new(0.3, 1.62, 0) * CFrame.Angles(0, 0, math.rad(-18)), baseColor:Lerp(Color3.new(1, 1, 1), 0.15))
	part(Enum.PartType.Ball, Vector3.new(0.18, 0.2, 0.12), CFrame.new(0, 1.05, -0.42), Color3.fromRGB(20, 20, 28))
	part(Enum.PartType.Ball, Vector3.new(0.16, 0.1, 0.1), CFrame.new(-0.28, 1.24, -0.34), Color3.fromRGB(20, 20, 28))
	part(Enum.PartType.Ball, Vector3.new(0.16, 0.1, 0.1), CFrame.new(0.28, 1.24, -0.34), Color3.fromRGB(20, 20, 28))
	part(Enum.PartType.Cylinder, Vector3.new(0.2, 0.22, 0.22), CFrame.new(-0.34, 0.08, 0) * CFrame.Angles(0, 0, math.rad(90)), baseColor:Lerp(Color3.new(0, 0, 0), 0.3))
	part(Enum.PartType.Cylinder, Vector3.new(0.2, 0.22, 0.22), CFrame.new(0.34, 0.08, 0) * CFrame.Angles(0, 0, math.rad(90)), baseColor:Lerp(Color3.new(0, 0, 0), 0.3))

	self.petModel:ScaleTo(classScale)

	local glow = Instance.new("PointLight")
	glow.Color = baseColor
	glow.Brightness = 1.2
	glow.Range = 6
	glow.Parent = self.petModel:FindFirstChildWhichIsA("BasePart")
end

-- ===========================================================================
-- Stats (the reference's clear right-side stack)
-- ===========================================================================

function PetDetailPanel:statRow(name: string, y: number, icon: string, color: Color3): (TextLabel, TextLabel)
	local theme = self.theme
	local row = theme.panel(self.frame, {
		name = name,
		size = UDim2.new(1, -32, 0, 38),
		position = UDim2.fromOffset(16, y),
		corner = true,
		radius = UDim.new(0, 10),
		color = theme.Colors.panelAlt,
		transparency = 0.25,
		stroke = false,
	})
	theme.label(row, {
		text = icon .. "  " .. name,
		size = UDim2.new(0.55, -8, 1, 0),
		position = UDim2.fromOffset(10, 0),
		color = theme.Colors.muted,
		textSize = 12,
		font = theme.Fonts.bold,
	})
	local value = theme.label(row, {
		text = "-",
		size = UDim2.new(0.45, -10, 1, 0),
		position = UDim2.new(0.55, 0, 0, 0),
		xAlign = Enum.TextXAlignment.Right,
		color = color,
		font = theme.Fonts.bold,
		textSize = 15,
	})
	return row, value
end

function PetDetailPanel:buildStats()
	local theme = self.theme
	local y = 226

	_, self.powerValue = self:statRow("POWER", y, "*", theme.Colors.gold)
	_, self.gemValue = self:statRow("GEMS BONUS", y + 44, "<>", theme.Colors.cyan)
	_, self.weightValue = self:statRow("WEIGHT", y + 88, "[]", theme.Colors.pink)

	-- Level progress
	local levelRow = theme.panel(self.frame, {
		name = "LevelRow",
		size = UDim2.new(1, -32, 0, 46),
		position = UDim2.fromOffset(16, y + 132),
		corner = true,
		radius = UDim.new(0, 10),
		color = theme.Colors.panelAlt,
		transparency = 0.25,
		stroke = false,
	})
	theme.label(levelRow, {
		name = "LevelText",
		text = "LEVEL 1",
		size = UDim2.new(0.5, -10, 0, 16),
		position = UDim2.fromOffset(10, 6),
		color = theme.Colors.muted,
		textSize = 11,
		font = theme.Fonts.bold,
	})
	self.levelText = levelRow:FindFirstChild("LevelText")
	local track, fill = theme.progressBar(levelRow, {
		size = UDim2.new(1, -20, 0, 8),
		position = UDim2.fromOffset(10, 28),
		color = theme.Colors.purple,
		progress = 0,
	})
	self.levelBar = fill
	self.levelTrack = track

	self.enchantLabel = theme.label(self.frame, {
		name = "Enchants",
		text = "No enchants",
		size = UDim2.new(1, -32, 0, 18),
		position = UDim2.fromOffset(18, y + 184),
		color = theme.Colors.dim,
		textSize = 11,
		font = theme.Fonts.medium,
	})

	-- Quick Compare box: populated on hover from the inventory grid.
	self.compareBox = theme.panel(self.frame, {
		name = "QuickCompare",
		size = UDim2.new(1, -32, 0, 54),
		position = UDim2.fromOffset(16, y + 206),
		corner = true,
		radius = UDim.new(0, 10),
		color = theme.Colors.panelAlt,
		transparency = 0.1,
		strokeColor = theme.Colors.strokeSoft,
		visible = false,
	})
	theme.label(self.compareBox, {
		text = "QUICK COMPARE",
		size = UDim2.new(1, -16, 0, 14),
		position = UDim2.fromOffset(8, 4),
		color = theme.Colors.dim,
		textSize = 9,
		font = theme.Fonts.bold,
	})
	self.compareValue = theme.label(self.compareBox, {
		text = "",
		size = UDim2.new(1, -16, 0, 18),
		position = UDim2.fromOffset(8, 16),
		color = theme.Colors.green,
		textSize = 12,
		font = theme.Fonts.bold,
	})
	self.compareSynergy = theme.label(self.compareBox, {
		text = "",
		size = UDim2.new(1, -16, 0, 16),
		position = UDim2.fromOffset(8, 34),
		color = theme.Colors.muted,
		textSize = 10,
	})
end

function PetDetailPanel:buildActions()
	local theme = self.theme
	self.equipButton = theme.button(self.frame, {
		name = "EquipButton",
		text = "EQUIP",
		variant = "primary",
		size = UDim2.new(1, -32, 0, 42),
		position = UDim2.new(0, 16, 1, -58),
		textSize = 14,
	})
	self.equipButton.Activated = function()
		if self.currentPet and self.onEquip then
			self.onEquip(self.currentPet)
		end
	end
end

-- ===========================================================================
-- Public API
-- ===========================================================================

function PetDetailPanel:show(petInfo: any?, build: any?)
	if petInfo then
		self.currentPet = petInfo
		self.build = build

		self.frame.Visible = true
		self.nameLabel.Text = petInfo.name or petInfo.id
		local classDef = Config.Classes[petInfo["class"] or "Standard"] or Config.Classes.Standard
		self.classPill.Text = string.upper(classDef.displayName)
		self.classPill.TextColor3 = self.theme.fromHex(classDef.color)

		local variantText = ""
		local variantColor = self.theme.Colors.text
		if petInfo.variants and #petInfo.variants > 0 then
			variantText = string.upper(table.concat(petInfo.variants, " "))
			local def = Config.Variants[petInfo.variants[#petInfo.variants]]
			if def then
				variantColor = self.theme.fromHex(def.color)
			end
		end
		self.variantPill.Text = variantText
		self.variantPill.TextColor3 = variantColor
		self.variantPill.Visible = variantText ~= ""

		self:renderPet(petInfo)

		-- POWER / GEMS / WEIGHT use the real engine values, never display-only
		local petPower = MultiplierEngine.petPower(petInfo, Config)
		self.powerValue.Text = NumberFormatter.short(petPower)
		-- Gems bonus = what a duplicate of this pet converts into (the exact
		-- number the server will pay), not a cosmetic percentage.
		self.gemValue.Text = "+" .. NumberFormatter.short(math.floor(petPower * Config.Economy.gemFromDuplicatePerPower))
		self.weightValue.Text = string.format("%.1f", math.max(0.5, petPower ^ 0.42))
		self.levelText.Text = string.format("LEVEL %d", petInfo.level or 1)
		self.levelBar.Size = UDim2.fromScale(math.clamp(((petInfo.level or 1) - 1) / (Config.Balance.Team.maxPetLevel - 1), 0, 1), 1)

		local enchants = petInfo.enchants or {}
		if #enchants == 0 then
			self.enchantLabel.Text = "No enchants - visit the Shadow Realm"
			self.enchantLabel.TextColor3 = self.theme.Colors.dim
		else
			local pieces = {}
			for _, enchant in ipairs(enchants) do
				local def = Config.Enchants.Definitions[enchant.id]
				if def then
					table.insert(pieces, string.format("%s %s", def.displayName, Config.Enchants.TierNames[enchant.tier] or "?"))
				end
			end
			self.enchantLabel.Text = table.concat(pieces, "  |  ")
			self.enchantLabel.TextColor3 = self.theme.Colors.muted
		end

		self.equipButton.Visible = true
	else
		self.currentPet = nil
		self.frame.Visible = false
		self:renderPet(nil)
	end
end

function PetDetailPanel:hide()
	self.frame.Visible = false
	self.currentPet = nil
end

--- Render the Quick Compare box (or hide it when nothing is hovered).
function PetDetailPanel:setCompare(result: any?)
	if not self.compareBox then
		return
	end
	if not result then
		self.compareBox.Visible = false
		return
	end

	self.compareBox.Visible = true
	local theme = self.theme
	local sign = if result.delta >= 0 then "+" else ""
	self.compareValue.Text = string.format(
		"%s%s power (%s%.0f%%) vs %s",
		sign,
		NumberFormatter.short(result.delta),
		sign,
		result.percent * 100,
		result.weakestName
	)
	self.compareValue.TextColor3 = if result.upgrade then theme.Colors.green else theme.Colors.red
	self.compareSynergy.Text = string.format("Synergy %+.2fx with this team", result.synergyDelta)
end

--- Quick Compare: delta against the weakest equipped pet + synergy fit.
function PetDetailPanel:compare(candidate: any, team: { any }, equippedUids: { string })
	if not candidate or not team then
		return nil
	end

	local candidatePower = MultiplierEngine.petPower(candidate, Config)

	local weakest = nil
	local weakestPower = math.huge
	for _, pet in ipairs(team) do
		local power = MultiplierEngine.petPower(pet, Config)
		if power < weakestPower then
			weakest = pet
			weakestPower = power
		end
	end

	local delta = candidatePower - (if weakest then weakestPower else 0)
	local synergyDelta = MultiplierEngine.marginalSynergy(candidate, team, Config)

	return {
		power = candidatePower,
		delta = delta,
		percent = if weakestPower > 0 then delta / weakestPower else 1,
		synergyDelta = synergyDelta,
		weakestName = if weakest and Config.Pets[weakest.id] then Config.Pets[weakest.id].name else "empty slot",
		upgrade = delta > 0,
	}
end

return PetDetailPanel
