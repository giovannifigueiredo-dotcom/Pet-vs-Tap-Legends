--!nonstrict
--[[
	TapController.client.lua
	========================
	The client shell: HUD, tap input, panels, feedback.

	Authority model:
	- The client NEVER sends a damage number. It sends "I tapped".
	- Numbers shown are the server's TapResult values.
	- StateSync carries a build snapshot so projections/UI are consistent, and a
	  future predicted-tap pass can reuse MultiplierEngine locally.

	Feedback budget: pooled damage numbers (90), one toast queue, one event
	banner, one raid bar. No per-frame string formatting in RenderStepped.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(Shared.Config.GameConfig)
local Remotes = require(Shared.Net.Remotes)
local NumberFormatter = require(Shared.Modules.NumberFormatter)

local UI = script.Parent:WaitForChild("UI")
local Theme = require(UI.Theme)
local PetDetailPanel = require(UI.PetDetailPanel)
local InventoryScreen = require(UI.InventoryScreen)
local ShopPanel = require(UI.ShopPanel)

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

-- ===========================================================================
-- State
-- ===========================================================================

local state = {
	currencies = { coins = 0, gems = 0, tokens = 0, eventTokens = 0 },
	rebirths = 0,
	build = nil,
	equipped = {},
	pets = {},
	shop = nil,
}

local lastTapAt = 0
local MIN_TAP_INTERVAL = 1 / (Config.Balance.Tap.server.maxTapsPerSecond + 2)

-- ===========================================================================
-- Root GUI
-- ===========================================================================

local screenGui = Instance.new("ScreenGui")
screenGui.Name = "TapPetUI"
screenGui.ResetOnSpawn = false
screenGui.IgnoreGuiInset = true
screenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
screenGui.DisplayOrder = 10
screenGui.Parent = playerGui
Theme.applyResponsiveScale(screenGui)

local function panel(props)
	return Theme.panel(screenGui, props)
end

-- ===========================================================================
-- HUD: currencies
-- ===========================================================================

local currencyPanel = panel({
	name = "Currencies",
	size = UDim2.fromOffset(272, 108),
	position = UDim2.fromOffset(16, 16),
	gradient = { Color3.fromRGB(38, 43, 72), Color3.fromRGB(18, 21, 36) },
	padding = 10,
})

local currencyRows = {}
local currencyDefs = {
	{ key = "coins", label = "Coins", color = Theme.Colors.gold, icon = "$" },
	{ key = "gems", label = "Gems", color = Theme.Colors.cyan, icon = "<>" },
	{ key = "tokens", label = "Tokens", color = Theme.Colors.purple, icon = "%" },
	{ key = "eventTokens", label = "Event", color = Theme.Colors.pink, icon = "*" },
}

for index, def in ipairs(currencyDefs) do
	local row = Theme.panel(currencyPanel, {
		name = def.key,
		size = UDim2.new(1, 0, 0, 22),
		position = UDim2.fromOffset(0, (index - 1) * 23),
		stroke = false,
		transparency = 1,
	})
	Theme.label(row, {
		text = def.icon .. "  " .. def.label,
		size = UDim2.new(0.5, 0, 1, 0),
		color = Theme.Colors.muted,
		textSize = 12,
		font = Theme.Fonts.bold,
	})
	currencyRows[def.key] = Theme.label(row, {
		text = "0",
		size = UDim2.new(0.5, 0, 1, 0),
		position = UDim2.new(0.5, 0, 0, 0),
		color = def.color,
		font = Theme.Fonts.bold,
		textSize = 14,
		xAlign = Enum.TextXAlignment.Right,
	})
end

-- ===========================================================================
-- HUD: power + rebirth
-- ===========================================================================

local powerPanel = panel({
	name = "PowerPanel",
	size = UDim2.fromOffset(300, 78),
	position = UDim2.new(0.5, 0, 0, 16),
	anchor = Vector2.new(0.5, 0),
	gradient = { Color3.fromRGB(44, 40, 76), Color3.fromRGB(20, 20, 40) },
	padding = 10,
})

Theme.label(powerPanel, {
	text = "TAP POWER",
	size = UDim2.new(0, 120, 0, 14),
	color = Theme.Colors.muted,
	textSize = 10,
	font = Theme.Fonts.bold,
})

local powerLabel = Theme.label(powerPanel, {
	text = "1",
	size = UDim2.new(1, 0, 0, 30),
	position = UDim2.fromOffset(0, 14),
	font = Theme.Fonts.display,
	textSize = 24,
	color = Theme.Colors.gold,
})

local multiplierLabel = Theme.label(powerPanel, {
	text = "Pets x1.00  |  Synergy x1.00  |  Rebirth x1.00",
	size = UDim2.new(1, 0, 0, 18),
	position = UDim2.fromOffset(0, 44),
	color = Theme.Colors.muted,
	textSize = 10,
})

-- ===========================================================================
-- HUD: tap button
-- ===========================================================================

local tapButton = Theme.button(screenGui, {
	name = "TapButton",
	text = "TAP",
	size = UDim2.fromOffset(190, 190),
	position = UDim2.new(0.5, 0, 1, -130),
	anchor = Vector2.new(0.5, 1),
	variant = "primary",
	radius = UDim.new(1, 0),
	textSize = 26,
	font = Theme.Fonts.display,
})
tapButton.BackgroundColor3 = Theme.Colors.blue
tapButton.BackgroundTransparency = 0.05
Theme.gradient(tapButton, Color3.fromRGB(96, 186, 255), Color3.fromRGB(38, 96, 190))
Theme.stroke(tapButton, Color3.fromRGB(160, 220, 255), 2)

local tapSubLabel = Theme.label(tapButton, {
	text = "TAP TO EARN",
	size = UDim2.new(1, 0, 0, 16),
	position = UDim2.new(0, 0, 1, -40),
	color = Color3.fromRGB(220, 240, 255),
	textSize = 11,
	xAlign = Enum.TextXAlignment.Center,
	font = Theme.Fonts.bold,
})

local autoLabel = Theme.label(screenGui, {
	text = "",
	size = UDim2.fromOffset(220, 18),
	position = UDim2.new(0.5, 0, 1, -150),
	anchor = Vector2.new(0.5, 1),
	color = Theme.Colors.cyan,
	textSize = 11,
	xAlign = Enum.TextXAlignment.Center,
})

-- ===========================================================================
-- HUD: side buttons
-- ===========================================================================

local buttonColumn = Instance.new("Frame")
buttonColumn.BackgroundTransparency = 1
buttonColumn.Size = UDim2.fromOffset(150, 240)
buttonColumn.Position = UDim2.fromOffset(16, 140)
buttonColumn.Parent = screenGui

local columnLayout = Instance.new("UIListLayout")
columnLayout.Padding = UDim.new(0, 8)
columnLayout.Parent = buttonColumn

local function sideButton(text: string, variant: string, onClick: () -> ())
	local button = Theme.button(buttonColumn, {
		text = text,
		variant = variant,
		size = UDim2.new(1, 0, 0, 46),
		textSize = 13,
	})
	button.Activated = onClick
	return button
end

-- ===========================================================================
-- Damage numbers (pooled)
-- ===========================================================================

local damageLayer = Instance.new("Frame")
damageLayer.BackgroundTransparency = 1
damageLayer.Size = UDim2.fromScale(1, 1)
damageLayer.ClipsDescendants = true
damageLayer.Parent = screenGui

local pool = {}
local activeNumbers = {}

local function spawnDamage(amount: number, isCrit: boolean, overcharged: boolean)
	local label = table.remove(pool)
	if not label then
		if #activeNumbers >= Config.Balance.UI.damageNumberPoolSize then
			local oldest = table.remove(activeNumbers, 1)
			table.insert(pool, oldest)
			oldest.Visible = false
			label = table.remove(pool)
		else
			local created = Instance.new("TextLabel")
			created.BackgroundTransparency = 1
			created.Font = Theme.Fonts.display
			created.TextSize = 20
			created.Size = UDim2.fromOffset(220, 30)
			created.AnchorPoint = Vector2.new(0.5, 0.5)
			created.Parent = damageLayer
			label = created
		end
	end

	label.Visible = true
	label.Text = NumberFormatter.short(amount)
	label.TextColor3 = if overcharged then Theme.Colors.orange elseif isCrit then Theme.Colors.gold else Theme.Colors.text
	label.TextSize = if isCrit or overcharged then 26 else 20
	label.TextTransparency = 0

	local offsetX = math.random(-80, 80)
	label.Position = UDim2.new(0.5, offsetX, 0.62, 0)

	table.insert(activeNumbers, label)

	local goal = UDim2.new(0.5, offsetX + math.random(-20, 20), 0.42, 0)
	local tween = TweenService:Create(label, TweenInfo.new(0.7, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		Position = goal,
		TextTransparency = 1,
		TextSize = label.TextSize + 6,
	})
	tween:Play()

	task.delay(0.75, function()
		label.Visible = false
		for index, active in ipairs(activeNumbers) do
			if active == label then
				table.remove(activeNumbers, index)
				break
			end
		end
		if #pool < Config.Balance.UI.damageNumberPoolSize then
			table.insert(pool, label)
		else
			label:Destroy()
		end
	end)
end

-- ===========================================================================
-- Toasts
-- ===========================================================================

local toastLayer = Instance.new("Frame")
toastLayer.BackgroundTransparency = 1
toastLayer.Size = UDim2.fromOffset(360, 300)
toastLayer.Position = UDim2.new(0.5, 0, 0, 108)
toastLayer.AnchorPoint = Vector2.new(0.5, 0)
toastLayer.Parent = screenGui

local toastLayout = Instance.new("UIListLayout")
toastLayout.Padding = UDim.new(0, 6)
toastLayout.Parent = toastLayer

local function toast(title: string, body: string, kind: string?)
	local color = Theme.Colors.blue
	if kind == "success" then
		color = Theme.Colors.green
	elseif kind == "warning" then
		color = Theme.Colors.orange
	elseif kind == "event" then
		color = Theme.Colors.pink
	elseif kind == "raid" then
		color = Theme.Colors.red
	elseif kind == "rebirth" then
		color = Theme.Colors.gold
	end

	local frame = Theme.panel(toastLayer, {
		size = UDim2.new(1, 0, 0, 54),
		color = Theme.Colors.panel,
		transparency = 0.05,
		strokeColor = color,
		padding = 8,
	})

	Theme.label(frame, {
		text = title,
		size = UDim2.new(1, 0, 0, 18),
		color = color,
		font = Theme.Fonts.display,
		textSize = 13,
	})
	Theme.label(frame, {
		text = body,
		size = UDim2.new(1, 0, 0, 22),
		position = UDim2.fromOffset(0, 18),
		color = Theme.Colors.text,
		textSize = 11,
	})

	task.delay(Config.Balance.UI.toastLifetimeSeconds, function()
		TweenService:Create(frame, TweenInfo.new(0.3), { BackgroundTransparency = 1 }):Play()
		for _, child in ipairs(frame:GetDescendants()) do
			if child:IsA("TextLabel") then
				TweenService:Create(child, TweenInfo.new(0.3), { TextTransparency = 1 }):Play()
			end
		end
		task.delay(0.35, function()
			frame:Destroy()
		end)
	end)
end

-- ===========================================================================
-- Banners: raid + event
-- ===========================================================================

local bannerLayer = Instance.new("Frame")
bannerLayer.BackgroundTransparency = 1
bannerLayer.Size = UDim2.new(0.5, 0, 0, 190)
bannerLayer.Position = UDim2.new(0.5, 0, 0, 104)
bannerLayer.AnchorPoint = Vector2.new(0.5, 0)
bannerLayer.Parent = screenGui

local bannerLayout = Instance.new("UIListLayout")
bannerLayout.Padding = UDim.new(0, 6)
bannerLayout.Parent = bannerLayer

local eventBanner = Theme.panel(bannerLayer, {
	name = "EventBanner",
	size = UDim2.new(1, 0, 0, 52),
	color = Theme.Colors.panel,
	transparency = 0.05,
	strokeColor = Theme.Colors.pink,
	padding = 8,
	visible = false,
})
local eventTitle = Theme.label(eventBanner, { text = "", size = UDim2.new(1, 0, 0, 16), color = Theme.Colors.pink, font = Theme.Fonts.bold, textSize = 12 })
local eventBody = Theme.label(eventBanner, { text = "", size = UDim2.new(1, 0, 0, 16), position = UDim2.fromOffset(0, 16), color = Theme.Colors.text, textSize = 10 })
local eventTrack, eventFill = Theme.progressBar(eventBanner, { size = UDim2.new(1, 0, 0, 5), position = UDim2.fromOffset(0, 36), color = Theme.Colors.pink })

local raidBanner = Theme.panel(bannerLayer, {
	name = "RaidBanner",
	size = UDim2.new(1, 0, 0, 52),
	color = Theme.Colors.panel,
	transparency = 0.05,
	strokeColor = Theme.Colors.red,
	padding = 8,
	visible = false,
})
local raidTitle = Theme.label(raidBanner, { text = "", size = UDim2.new(1, 0, 0, 16), color = Theme.Colors.red, font = Theme.Fonts.bold, textSize = 12 })
local raidBody = Theme.label(raidBanner, { text = "", size = UDim2.new(1, 0, 0, 16), position = UDim2.fromOffset(0, 16), color = Theme.Colors.text, textSize = 10 })
local raidTrack, raidFill = Theme.progressBar(raidBanner, { size = UDim2.new(1, 0, 0, 5), position = UDim2.fromOffset(0, 36), color = Theme.Colors.red })

-- ===========================================================================
-- Panels
-- ===========================================================================

-- Forward declaration: the inventory callbacks below reference the detail
-- panel, which is constructed after them.
local detail

local inventory = InventoryScreen.new(screenGui, Theme, {
	onSelect = function(pet)
		detail:show(pet, state.build)
		detail:setCompare(nil)
	end,
	onCompare = function(candidate, team, equippedUids)
		if not detail.frame.Visible then
			detail:show(detail.currentPet or candidate, state.build)
		end
		detail:setCompare(detail:compare(candidate, team, equippedUids))
	end,
	onToast = function(message)
		toast("Inventory", message, "info")
	end,
	onError = function(reason)
		toast("Inventory", tostring(reason), "warning")
	end,
})

local function equipPet(pet)
	local uids = {}
	for _, uid in ipairs(state.equipped) do
		table.insert(uids, uid)
	end
	table.insert(uids, pet.uid)
	local ok, result = pcall(function()
		return Remotes.fn("EquipPets"):InvokeServer(uids)
	end)
	if not ok or not result or not result.ok then
		toast("Equip failed", tostring(result and result.reason or "unknown"), "warning")
	else
		toast("Equipped", pet.name or pet.id, "success")
		detail:show(pet, state.build)
	end
end

detail = PetDetailPanel.new(screenGui, Theme, equipPet)

local shop = ShopPanel.new(screenGui, Theme, {
	onToast = function(message)
		toast("Shop", message, "warning")
	end,
})

sideButton("INVENTORY", "ghost", function()
	inventory:toggle()
end)
sideButton("SHOP", "ghost", function()
	shop:toggle()
end)
sideButton("REBIRTH", "ghost", function()
	local ok, result = pcall(function()
		return Remotes.fn("Rebirth"):InvokeServer()
	end)
	if ok and result and not result.ok then
		local reason = result.reason
		local messages = {
			insufficientCoins = string.format("Need %s coins.", NumberFormatter.short(result.requirement or 0)),
			maxRebirths = "Max rebirths reached.",
		}
		toast("Rebirth", messages[reason] or tostring(reason), "warning")
	end
end)

-- ===========================================================================
-- Input
-- ===========================================================================

local function tap()
	local now = os.clock()
	if now - lastTapAt < MIN_TAP_INTERVAL then
		return
	end
	lastTapAt = now
	Remotes.event("Tap"):FireServer()

	-- Press feedback only; the NUMBER comes from the server (TapResult).
	local tween = TweenService:Create(tapButton, TweenInfo.new(0.06), { Size = UDim2.fromOffset(180, 180) })
	tween:Play()
	tween.Completed:Connect(function()
		TweenService:Create(tapButton, TweenInfo.new(0.09), { Size = UDim2.fromOffset(190, 190) }):Play()
	end)
end

tapButton.Activated = tap

UserInputService.InputBegan:Connect(function(input, gameProcessed)
	if gameProcessed then
		return
	end
	if input.KeyCode == Enum.KeyCode.Space or input.KeyCode == Enum.KeyCode.ButtonA then
		tap()
	end
end)

-- ===========================================================================
-- Server events
-- ===========================================================================

local function updateHud()
	for key, label in pairs(currencyRows) do
		label.Text = NumberFormatter.short(state.currencies[key] or 0)
	end
	local build = state.build
	if build then
		powerLabel.Text = NumberFormatter.short(build.damagePerTap)
		multiplierLabel.Text = string.format(
			"Pets x%.1f  |  Synergy x%.2f  |  Rebirth x%.1f",
			build.multipliers.pets or 1,
			build.multipliers.synergy or 1,
			build.multipliers.rebirth or 1
		)
		autoLabel.Text = if build.autoTapRate > 0 then string.format("AUTO-TAP %d/s ACTIVE", build.autoTapRate) else ""
	end
end

Remotes.event("StateSync").OnClientEvent:Connect(function(payload)
	state.currencies = payload.currencies or state.currencies
	state.rebirths = payload.rebirths or 0
	state.build = payload.build or state.build
	state.equipped = payload.equipped or state.equipped
	updateHud()
	if detail.currentPet then
		detail:show(detail.currentPet, state.build)
	end
end)

Remotes.event("InventorySync").OnClientEvent:Connect(function(payload)
	state.pets = payload.pets or {}
	state.equipped = payload.equipped or {}
	inventory:setData(payload)
end)

Remotes.event("TapResult").OnClientEvent:Connect(function(result)
	state.currencies.coins = result.coinsTotal or state.currencies.coins
	spawnDamage(result.totalDamage or result.damage, result.isCrit, result.overcharged)
	updateHud()
end)

Remotes.event("ShopState").OnClientEvent:Connect(function(snapshot)
	state.shop = snapshot
	shop:setSnapshot(snapshot)
end)

Remotes.event("Toast").OnClientEvent:Connect(function(payload)
	if payload then
		toast(payload.title or "Notice", payload.body or "", payload.kind)
	end
end)

Remotes.event("RaidState").OnClientEvent:Connect(function(payload)
	if not payload or payload.phase == "idle" then
		raidBanner.Visible = false
		return
	end
	raidBanner.Visible = true
	if payload.phase == "windup" then
		raidTitle.Text = "RAID INCOMING: " .. tostring(payload.name or "")
		raidBody.Text = string.format("%s HP - fight starts shortly", NumberFormatter.short(payload.maxHp or 0))
		raidFill.Size = UDim2.fromScale(0, 1)
	else
		raidTitle.Text = string.format("RAID: %s (%s HP)", payload.name or "", NumberFormatter.short(payload.hp or 0))
		raidBody.Text = string.format("%d contributors  |  %s damage dealt", payload.contributors or 0, NumberFormatter.percent(payload.progress or 0))
		raidFill.Size = UDim2.fromScale(math.clamp(payload.progress or 0, 0, 1), 1)
	end
end)

Remotes.event("EventState").OnClientEvent:Connect(function(payload)
	if not payload or payload.phase == "idle" then
		eventBanner.Visible = false
		return
	end
	eventBanner.Visible = true
	eventTitle.Text = string.format("%s  (%s left)", string.upper(tostring(payload.name or "")), NumberFormatter.duration(payload.remaining or 0))
	eventBody.Text = string.format("%d participants  |  %s event damage", payload.participants or 0, NumberFormatter.short(payload.totalDamage or 0))
	local total = Config.Balance.Events.durationSeconds
	eventFill.Size = UDim2.fromScale(math.clamp(1 - (payload.remaining or 0) / total, 0, 1), 1)
end)

Remotes.event("TradeState").OnClientEvent:Connect(function(payload)
	if payload and payload.phase == "invite" then
		toast("TRADE REQUEST", string.format("%s wants to trade. (Trade UI milestone 2)", payload.fromName or ""), "info")
	elseif payload and payload.phase == "completed" then
		toast("Trade complete", "Items swapped.", "success")
	end
end)

-- Initial HUD paint
updateHud()
toast("Welcome", "Tap the big button to start earning. Space works too.", "info")
