--!strict
--[[
	Zones.lua
	Island progression. Each zone gates: egg pool, tap upgrade tier, boss,
	background, and the rebirth requirement. Coins cost roughly x12 per zone
	while pet power grows ~x3.2 per zone: the gap is closed with rebirth
	multipliers, which is exactly the pressure loop we want.
]]

local Zones = {}

Zones.Definitions = {
	{
		id = "meadow",
		displayName = "Sunny Meadow",
		order = 1,
		unlockCoins = 0,
		unlockRebirths = 0,
		egg = "meadow",
		boss = "Meadow Mole",
		color = "#7BD389",
		skybox = "#BFE9FF",
		blurb = "Where every tap starts.",
	},
	{
		id = "coral",
		displayName = "Coral Bay",
		order = 2,
		unlockCoins = 25000,
		unlockRebirths = 0,
		egg = "coral",
		boss = "Tidebreaker",
		color = "#4AA8FF",
		skybox = "#C9F0FF",
		blurb = "Salt water, faster taps.",
	},
	{
		id = "ember",
		displayName = "Emberpeak",
		order = 3,
		unlockCoins = 250000,
		unlockRebirths = 0,
		egg = "ember",
		boss = "Caldera King",
		color = "#FF6B4A",
		skybox = "#FFD9C2",
		blurb = "Home of the dragon line.",
	},
	{
		id = "neon",
		displayName = "Neon City",
		order = 4,
		unlockCoins = 2500000,
		unlockRebirths = 1,
		egg = "neon",
		boss = "Mainframe Prime",
		color = "#7DE8FF",
		skybox = "#2A2F5A",
		blurb = "Tech pets overclock here.",
	},
	{
		id = "frost",
		displayName = "Frost Hollow",
		order = 5,
		unlockCoins = 25000000,
		unlockRebirths = 2,
		egg = "frost",
		boss = "Aurora Wyrm",
		color = "#BFE9FF",
		skybox = "#E8F7FF",
		blurb = "Cold hands, big numbers.",
	},
	{
		id = "void",
		displayName = "Void Garden",
		order = 6,
		unlockCoins = 250000000,
		unlockRebirths = 4,
		egg = "void",
		boss = "Null Bloom",
		color = "#8B5CF6",
		skybox = "#1A1030",
		blurb = "Flowers made of missing things.",
	},
	{
		id = "shadow",
		displayName = "Shadow Realm",
		order = 7,
		unlockCoins = 0,
		unlockRebirths = 3,
		egg = "umbral",
		boss = "The Curator",
		color = "#C46BFF",
		skybox = "#120A22",
		blurb = "ENCHANTING HUB - reroll gear and pet modifiers here.",
		isHub = true,
	},
	{
		id = "cosmic",
		displayName = "Cosmic Spire",
		order = 8,
		unlockCoins = 1000000000,
		unlockRebirths = 10,
		egg = "cosmic",
		boss = "Stellar Devourer",
		color = "#FFC53D",
		skybox = "#0B0A1F",
		blurb = "Tap the sky. It taps back.",
	},
	{
		id = "titan",
		displayName = "Gargantuan's Rest",
		order = 9,
		unlockCoins = 50000000000,
		unlockRebirths = 25,
		egg = "titan",
		boss = "Gargantuan",
		color = "#FF6B8A",
		skybox = "#1B0A16",
		blurb = "Endgame. The boss is your pet's ancestor.",
	},
}

Zones.Order = { "meadow", "coral", "ember", "neon", "frost", "void", "shadow", "cosmic", "titan" }

function Zones.get(id: string)
	for _, zone in ipairs(Zones.Definitions) do
		if zone.id == id then
			return zone
		end
	end
	return nil
end

return Zones
