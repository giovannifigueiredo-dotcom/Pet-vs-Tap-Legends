--!strict
--[[
	Relics.lua

	Relics are the "player gear" layer: they change HOW taps behave rather than
	just how big they are. A player can equip up to 4 relics (1 free, +3 at
	rebirth milestones 5/12/25).

	Effect keys understood by MultiplierEngine.relicMods():
	  tapMultiplier        additive percent on final tap damage
	  flatTap              flat damage added before multipliers
	  coinMultiplier       additive percent on coins per tap
	  gemMultiplier        additive percent on gems
	  critChance           additive crit chance
	  critMultiplier       additive crit damage (relative to crit.damageMultiplier)
	  extraHits            taps hit this many extra targets (raid boss shield)
	  overchargeEvery      every Nth tap triggers an overcharge
	  overchargeMultiplier multiplier applied on the overcharge tap
	  autoTapRate          free server-side taps per second while equipped
	  synergyBonus         additive percent on the synergy multiplier
	  petSlotBonus         extra team slots
	  petPowerMultiplier   additive percent on the whole team's power

	curse = optional downside. Risk/reward relics are the best kind of chase.
]]

local Relics = {}

Relics.Tiers = {
	Common = { order = 1, color = "#B9C4D4", weight = 420 },
	Uncommon = { order = 2, color = "#54E38A", weight = 260 },
	Rare = { order = 3, color = "#4AA8FF", weight = 180 },
	Epic = { order = 4, color = "#C46BFF", weight = 90 },
	Legendary = { order = 5, color = "#FFC53D", weight = 40 },
	Mythic = { order = 6, color = "#FF6B8A", weight = 10 },
}

Relics.Definitions = {
	ember_gauntlet = {
		displayName = "Ember Gauntlet",
		tier = "Rare",
		icon = "rbxassetid://0",
		blurb = "Every 10th tap erupts for triple damage.",
		effects = { tapMultiplier = 0.35, overchargeEvery = 10, overchargeMultiplier = 3 },
		source = "Raid drop / Shadow Realm forge",
	},
	ring_of_greed = {
		displayName = "Ring of Greed",
		tier = "Uncommon",
		icon = "rbxassetid://0",
		blurb = "+25% coins from every tap. It whispers.",
		effects = { coinMultiplier = 0.25 },
		source = "Zone drop",
	},
	tidal_aegis = {
		displayName = "Tidal Aegis",
		tier = "Rare",
		icon = "rbxassetid://0",
		blurb = "+2 team slots even before the gamepass.",
		effects = { petSlotBonus = 2 },
		source = "Shadow Realm forge",
	},
	chrono_fang = {
		displayName = "Chrono Fang",
		tier = "Epic",
		icon = "rbxassetid://0",
		blurb = "Auto-taps 3x per second for you.",
		effects = { autoTapRate = 3 },
		source = "Raid drop",
	},
	prism_heart = {
		displayName = "Prism Heart",
		tier = "Epic",
		icon = "rbxassetid://0",
		blurb = "+8% crit chance, +50% crit damage.",
		effects = { critChance = 0.08, critMultiplier = 0.5 },
		source = "Event reward",
	},
	void_sigil = {
		displayName = "Void Sigil",
		tier = "Legendary",
		icon = "rbxassetid://0",
		blurb = "Taps strike two extra raid targets.",
		effects = { extraHits = 2 },
		source = "Raid drop (rank 3+)",
	},
	worldroot_totem = {
		displayName = "Worldroot Totem",
		tier = "Legendary",
		icon = "rbxassetid://0",
		blurb = "+10% synergy power, +5% team power.",
		effects = { synergyBonus = 0.10, petPowerMultiplier = 0.05 },
		source = "Shadow Realm forge",
	},
	echo_loop = {
		displayName = "Echo Loop",
		tier = "Rare",
		icon = "rbxassetid://0",
		blurb = "Each tap echoes once, plus 1 auto-tap/s.",
		effects = { extraHits = 1, autoTapRate = 1 },
		source = "Zone drop",
	},
	cursed_band = {
		displayName = "Cursed Band",
		tier = "Mythic",
		icon = "rbxassetid://0",
		blurb = "x2.5 tap damage, but pets lose 25% power.",
		effects = { tapMultiplier = 1.5 },
		curse = { petPowerMultiplier = -0.25 },
		source = "Shadow Realm forge (Mythic)",
	},
	gargantuan_heart = {
		displayName = "Gargantuan Heart",
		tier = "Mythic",
		icon = "rbxassetid://0",
		blurb = "+75% tap damage and +50 flat damage.",
		effects = { tapMultiplier = 0.75, flatTap = 50 },
		source = "Gargantuan raid boss (top damage)",
	},
}

Relics.Order = {
	"ember_gauntlet", "ring_of_greed", "tidal_aegis", "chrono_fang", "prism_heart",
	"void_sigil", "worldroot_totem", "echo_loop", "cursed_band", "gargantuan_heart",
}

-- Forging (Shadow Realm). Pity guarantees an Epic+ relic.
Relics.Forging = {
	baseTokenCost = 3,
	costGrowth = 1.2,
	baseGemCost = 150,
	gemCostGrowth = 1.1,
	pity = { hard = 60, epicPlus = 25 },
}

function Relics.get(id: string)
	return Relics.Definitions[id]
end

return Relics
