--!strict
--[[
	Pets.lua
	The pet dex. `basePower` is the ONLY balance lever per pet; class
	(Standard/Huge/Titanic/Gargantuan) is a ROLLED property on the instance, so
	one dex entry can produce a Normal Sproutling and a Rainbow Shiny Huge
	Sproutling.

	Power curve per zone is ~x3.2 (matching Rebirth.requirementGrowth) so a new
	zone feels like a step change without invalidating the previous collection.
]]

local Pets = {}

type PetDef = {
	name: string,
	element: string,
	family: string,
	zone: number,
	egg: string,
	basePower: number,
	blurb: string,
}

Pets.Definitions = {
	-- Zone 1: Meadow
	sproutling = { name = "Sproutling", element = "Nature", family = "Beast", zone = 1, egg = "meadow", basePower = 5, blurb = "Smells like fresh cut grass." } :: PetDef,
	meadowmoth = { name = "Meadow Moth", element = "Nature", family = "Beast", zone = 1, egg = "meadow", basePower = 6, blurb = "Drawn to your taps." } :: PetDef,
	bumblepup = { name = "Bumblepup", element = "Nature", family = "Dog", zone = 1, egg = "meadow", basePower = 7, blurb = "Buzzes when happy." } :: PetDef,
	honeyhog = { name = "Honey Hog", element = "Nature", family = "Beast", zone = 1, egg = "meadow", basePower = 9, blurb = "Sticky, but loyal." } :: PetDef,

	-- Zone 2: Coral Bay
	bubblefin = { name = "Bubblefin", element = "Water", family = "Beast", zone = 2, egg = "coral", basePower = 14, blurb = "Blows bubbles in perfect rhythm." } :: PetDef,
	reefcat = { name = "Reef Cat", element = "Water", family = "Cat", zone = 2, egg = "coral", basePower = 18, blurb = "Hates water. Lives in it." } :: PetDef,
	tidepup = { name = "Tide Pup", element = "Water", family = "Dog", zone = 2, egg = "coral", basePower = 22, blurb = "Chases waves, never catches them." } :: PetDef,
	coralgolem = { name = "Coral Golem", element = "Water", family = "Golem", zone = 2, egg = "coral", basePower = 30, blurb = "A walking reef." } :: PetDef,

	-- Zone 3: Emberpeak
	cinderdrake = { name = "Cinder Drake", element = "Fire", family = "Dragon", zone = 3, egg = "ember", basePower = 45, blurb = "First of the dragon line." } :: PetDef,
	magmacub = { name = "Magma Cub", element = "Fire", family = "Dragon", zone = 3, egg = "ember", basePower = 55, blurb = "Warm to the touch. Very warm." } :: PetDef,
	ashenwyrm = { name = "Ashen Wyrm", element = "Fire", family = "Dragon", zone = 3, egg = "ember", basePower = 80, blurb = "Sleeps in the caldera." } :: PetDef,
	embertechhound = { name = "Embertech Hound", element = "Fire", family = "Tech", zone = 3, egg = "ember", basePower = 95, blurb = "Forge-built, fire-fed." } :: PetDef,

	-- Zone 4: Neon City
	circuitcat = { name = "Circuit Cat", element = "Tech", family = "Cat", zone = 4, egg = "neon", basePower = 130, blurb = "Purrs at 60Hz." } :: PetDef,
	bytebat = { name = "Byte Bat", element = "Tech", family = "Beast", zone = 4, egg = "neon", basePower = 170, blurb = "Echolocates in binary." } :: PetDef,
	neonnyan = { name = "Neon Nyan", element = "Tech", family = "Cat", zone = 4, egg = "neon", basePower = 220, blurb = "Leaves a rainbow trail." } :: PetDef,
	hologolem = { name = "Holo Golem", element = "Tech", family = "Golem", zone = 4, egg = "neon", basePower = 300, blurb = "92% solid. Don't ask about the rest." } :: PetDef,

	-- Zone 5: Frost Hollow
	frostbite = { name = "Frostbite", element = "Water", family = "Beast", zone = 5, egg = "frost", basePower = 400, blurb = "Bites. Freezes. Apologises." } :: PetDef,
	glaciergolem = { name = "Glacier Golem", element = "Water", family = "Golem", zone = 5, egg = "frost", basePower = 520, blurb = "Moves one inch per year." } :: PetDef,
	auroraangel = { name = "Aurora Angel", element = "Light", family = "Angel", zone = 5, egg = "frost", basePower = 700, blurb = "Light bent into a friend." } :: PetDef,

	-- Zone 6: Void Garden
	voidling = { name = "Voidling", element = "Shadow", family = "Spirit", zone = 6, egg = "void", basePower = 950, blurb = "A hole shaped like a pet." } :: PetDef,
	nullcat = { name = "Null Cat", element = "Shadow", family = "Cat", zone = 6, egg = "void", basePower = 1200, blurb = "Returns nil when petted." } :: PetDef,
	eclipsewarden = { name = "Eclipse Warden", element = "Shadow", family = "Angel", zone = 6, egg = "void", basePower = 1600, blurb = "Guards the light it swallowed." } :: PetDef,

	-- Zone 7: Shadow Realm (enchanting hub)
	umbraldrake = { name = "Umbral Drake", element = "Shadow", family = "Dragon", zone = 7, egg = "umbral", basePower = 2200, blurb = "Dragons that learned to hide." } :: PetDef,
	shadegolem = { name = "Shade Golem", element = "Shadow", family = "Golem", zone = 7, egg = "umbral", basePower = 2800, blurb = "You are standing in its shadow." } :: PetDef,

	-- Zone 8: Cosmic Spire
	starpup = { name = "Star Pup", element = "Cosmic", family = "Dog", zone = 8, egg = "cosmic", basePower = 4000, blurb = "Barks in constellations." } :: PetDef,
	nebulanyan = { name = "Nebula Nyan", element = "Cosmic", family = "Cat", zone = 8, egg = "cosmic", basePower = 5200, blurb = "A cat made of weather." } :: PetDef,
	quasarwarden = { name = "Quasar Warden", element = "Cosmic", family = "Angel", zone = 8, egg = "cosmic", basePower = 7000, blurb = "Bright enough to cast shadows." } :: PetDef,

	-- Zone 9: Gargantuan's Rest
	titanhatchling = { name = "Titan Hatchling", element = "Cosmic", family = "Dragon", zone = 9, egg = "titan", basePower = 12000, blurb = "It is not a baby." } :: PetDef,
	worldbreaker = { name = "Worldbreaker", element = "Cosmic", family = "Golem", zone = 9, egg = "titan", basePower = 20000, blurb = "Named for what it does." } :: PetDef,
}

Pets.Order = {
	"sproutling", "meadowmoth", "bumblepup", "honeyhog",
	"bubblefin", "reefcat", "tidepup", "coralgolem",
	"cinderdrake", "magmacub", "ashenwyrm", "embertechhound",
	"circuitcat", "bytebat", "neonnyan", "hologolem",
	"frostbite", "glaciergolem", "auroraangel",
	"voidling", "nullcat", "eclipsewarden",
	"umbraldrake", "shadegolem",
	"starpup", "nebulanyan", "quasarwarden",
	"titanhatchling", "worldbreaker",
}

function Pets.get(id: string): PetDef?
	return Pets.Definitions[id]
end

function Pets.powerOf(id: string): number
	local def = Pets.Definitions[id]
	return if def then def.basePower else 0
end

return Pets
