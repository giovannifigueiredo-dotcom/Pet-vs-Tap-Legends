--!strict
--[[
	Elements.lua
	Elements drive one half of the Synergy system. Families (Dragon, Cat, Tech,
	...) drive the other half and are declared per pet in Pets.lua.

	Colors are hex strings (not Color3) so this file stays pure data and can be
	unit tested outside Roblox. UI converts with Color3.fromHex().
]]

local Elements = {}

Elements.Order = {
	"Fire",
	"Water",
	"Nature",
	"Tech",
	"Shadow",
	"Light",
	"Cosmic",
	"Spirit",
}

Elements.Definitions = {
	Fire = { color = "#FF6B4A", icon = "rbxassetid://0", blurb = "Burn: taps deal +5% to bosses." },
	Water = { color = "#4AA8FF", icon = "rbxassetid://0", blurb = "Flow: +5% coin gain." },
	Nature = { color = "#54E38A", icon = "rbxassetid://0", blurb = "Growth: pets gain +10% fusion XP." },
	Tech = { color = "#7DE8FF", icon = "rbxassetid://0", blurb = "Overclock: +3% auto-tap rate." },
	Shadow = { color = "#8B5CF6", icon = "rbxassetid://0", blurb = "Drain: 2% of boss damage returns as gems." },
	Light = { color = "#FFE28A", icon = "rbxassetid://0", blurb = "Radiance: +5% event token gain." },
	Cosmic = { color = "#C46BFF", icon = "rbxassetid://0", blurb = "Gravity: +5% pet power." },
	Spirit = { color = "#B9C4D4", icon = "rbxassetid://0", blurb = "Echo: 8% chance a tap repeats." },
}

Elements.Families = {
	Dragon = { color = "#FF6B4A" },
	Beast = { color = "#C99B6B" },
	Cat = { color = "#FFB86B" },
	Dog = { color = "#9BE86B" },
	Golem = { color = "#8C93A8" },
	Tech = { color = "#7DE8FF" },
	Angel = { color = "#FFE28A" },
	Spirit = { color = "#B9C4D4" },
}

function Elements.isValidElement(name: string): boolean
	return Elements.Definitions[name] ~= nil
end

function Elements.colorOf(element: string): string
	local def = Elements.Definitions[element]
	return if def then def.color else "#B9C4D4"
end

return Elements
