--!strict
--[[
	Enchants.lua

	The Shadow Realm reroll loop. Gear and pets have enchant slots
	(Standard pet 1, Huge 2, Titanic 3, Gargantuan 4; relics 2).

	Stats are additive percentages so "Might IV" (+35% pet power) is easy to
	explain in the UI. Tiers I..V with exponentially better values and
	exponentially worse odds is what makes rerolling feel like a slot machine
	with a real jackpot.

	`stats` maps to MultiplierEngine.enchantTotals():
	  power   -> per-item power multiplier
	  tap     -> team tap multiplier
	  coin    -> coin multiplier
	  gem     -> gem multiplier
	  luck    -> pity / drop-rate bonus
	  synergy -> synergy multiplier bonus
	  crit    -> crit chance bonus (smaller numbers by design)
]]

local Enchants = {}

Enchants.TierNames = { "I", "II", "III", "IV", "V" }

Enchants.Definitions = {
	power = {
		displayName = "Might",
		stat = "power",
		color = "#FF6B4A",
		values = { 0.05, 0.10, 0.20, 0.35, 0.60 },
		weight = 100,
		blurb = "Increases this pet's power.",
	},
	tap = {
		displayName = "Force",
		stat = "tap",
		color = "#FFC53D",
		values = { 0.04, 0.08, 0.15, 0.25, 0.45 },
		weight = 100,
		blurb = "Increases team tap damage.",
	},
	coin = {
		displayName = "Fortune",
		stat = "coin",
		color = "#54E38A",
		values = { 0.05, 0.10, 0.18, 0.30, 0.50 },
		weight = 90,
		blurb = "More coins per tap.",
	},
	gem = {
		displayName = "Crystal",
		stat = "gem",
		color = "#7DE8FF",
		values = { 0.04, 0.08, 0.15, 0.25, 0.40 },
		weight = 80,
		blurb = "More gems from duplicates and events.",
	},
	luck = {
		displayName = "Luck",
		stat = "luck",
		color = "#C46BFF",
		values = { 0.03, 0.06, 0.12, 0.20, 0.35 },
		weight = 70,
		blurb = "Improves egg and reroll odds.",
	},
	synergy = {
		displayName = "Harmony",
		stat = "synergy",
		color = "#FF7AD9",
		values = { 0.02, 0.05, 0.09, 0.15, 0.25 },
		weight = 60,
		blurb = "Boosts your Synergy multiplier.",
	},
	crit = {
		displayName = "Edge",
		stat = "crit",
		color = "#FF6B8A",
		values = { 0.01, 0.02, 0.04, 0.07, 0.11 },
		weight = 50,
		blurb = "Increases crit chance.",
	},
}

Enchants.Order = { "power", "tap", "coin", "gem", "luck", "synergy", "crit" }

-- Tier weights: rolling a V is the dream.
Enchants.TierWeights = { 55, 28, 12, 4.4, 0.6 }

Enchants.Forging = {
	baseGemCost = 250,
	costGrowth = 1.18,
	lockCostMultiplier = 3, -- per locked modifier
	rerollPity = { hard = 40, epicPlusTier = 4 }, -- tier IV+ guaranteed at 40
}

function Enchants.getValue(stat: string, tier: number): number
	local def = Enchants.Definitions[stat]
	if not def then
		return 0
	end
	return def.values[tier] or 0
end

function Enchants.tierLabel(tier: number): string
	return Enchants.TierNames[tier] or "?"
end

return Enchants
