--!strict
--[[
	Eggs.lua

	Each egg defines:
	  cost / currency   - coin or gem price
	  pool              - pet ids, each with a WEIGHT inside the egg
	  classWeights      - chance of rolling Huge / Titanic / Gargantuan
	  pity              - guaranteed-drop counters PER CLASS. This is what the
	                      "Pity Timer" bar in the shop draws. 0 = disabled.

	Pity is per-egg and per-class, persisted in the profile, and survives
	rebirths deliberately (the guarantee is a purchase contract).
]]

local Eggs = {}

Eggs.Definitions = {
	meadow = {
		displayName = "Meadow Egg",
		zone = 1,
		cost = 100,
		currency = "coins",
		classWeights = { Standard = 997, Huge = 2.8, Titanic = 0.2, Gargantuan = 0 },
		variants = { gold = 0.10, rainbow = 0.02, shiny = 0.004 },
		pity = { Huge = 200, Titanic = 0, Gargantuan = 0 },
		pool = {
			{ id = "sproutling", weight = 40 },
			{ id = "meadowmoth", weight = 30 },
			{ id = "bumblepup", weight = 20 },
			{ id = "honeyhog", weight = 10 },
		},
	},
	coral = {
		displayName = "Coral Egg",
		zone = 2,
		cost = 5000,
		currency = "coins",
		classWeights = { Standard = 995, Huge = 4.5, Titanic = 0.5, Gargantuan = 0 },
		variants = { gold = 0.11, rainbow = 0.024, shiny = 0.005 },
		pity = { Huge = 300, Titanic = 0, Gargantuan = 0 },
		pool = {
			{ id = "bubblefin", weight = 40 },
			{ id = "reefcat", weight = 30 },
			{ id = "tidepup", weight = 20 },
			{ id = "coralgolem", weight = 10 },
		},
	},
	ember = {
		displayName = "Ember Egg",
		zone = 3,
		cost = 60000,
		currency = "coins",
		classWeights = { Standard = 992, Huge = 7, Titanic = 0.9, Gargantuan = 0 },
		variants = { gold = 0.12, rainbow = 0.028, shiny = 0.006 },
		pity = { Huge = 400, Titanic = 4000, Gargantuan = 0 },
		pool = {
			{ id = "cinderdrake", weight = 40 },
			{ id = "magmacub", weight = 30 },
			{ id = "ashenwyrm", weight = 20 },
			{ id = "embertechhound", weight = 10 },
		},
	},
	neon = {
		displayName = "Neon Egg",
		zone = 4,
		cost = 750000,
		currency = "coins",
		-- Neon is the tech zone: no Gargantuan here (that chase belongs to
		-- Frost and beyond). Weight 0, not a tiny weight, so it cannot leak.
		classWeights = { Standard = 988, Huge = 10, Titanic = 1.8, Gargantuan = 0 },
		variants = { gold = 0.13, rainbow = 0.03, shiny = 0.007 },
		pity = { Huge = 500, Titanic = 5000, Gargantuan = 0 },
		pool = {
			{ id = "circuitcat", weight = 40 },
			{ id = "bytebat", weight = 30 },
			{ id = "neonnyan", weight = 20 },
			{ id = "hologolem", weight = 10 },
		},
	},
	frost = {
		displayName = "Frost Egg",
		zone = 5,
		cost = 9000000,
		currency = "coins",
		classWeights = { Standard = 983, Huge = 14, Titanic = 2.8, Gargantuan = 0.05 },
		variants = { gold = 0.14, rainbow = 0.033, shiny = 0.008 },
		pity = { Huge = 650, Titanic = 6500, Gargantuan = 25000 },
		pool = {
			{ id = "frostbite", weight = 45 },
			{ id = "glaciergolem", weight = 35 },
			{ id = "auroraangel", weight = 20 },
		},
	},
	void = {
		displayName = "Void Egg",
		zone = 6,
		cost = 120000000,
		currency = "coins",
		classWeights = { Standard = 976, Huge = 20, Titanic = 3.9, Gargantuan = 0.1 },
		variants = { gold = 0.15, rainbow = 0.036, shiny = 0.009 },
		pity = { Huge = 800, Titanic = 8000, Gargantuan = 30000 },
		pool = {
			{ id = "voidling", weight = 45 },
			{ id = "nullcat", weight = 35 },
			{ id = "eclipsewarden", weight = 20 },
		},
	},
	umbral = {
		displayName = "Umbral Egg",
		zone = 7,
		cost = 250,
		currency = "gems",
		classWeights = { Standard = 968, Huge = 26, Titanic = 5.5, Gargantuan = 0.15 },
		variants = { gold = 0.16, rainbow = 0.04, shiny = 0.01 },
		pity = { Huge = 1000, Titanic = 10000, Gargantuan = 15000 },
		pool = {
			{ id = "umbraldrake", weight = 55 },
			{ id = "shadegolem", weight = 45 },
		},
	},
	cosmic = {
		displayName = "Cosmic Egg",
		zone = 8,
		cost = 1500000000,
		currency = "coins",
		classWeights = { Standard = 958, Huge = 33, Titanic = 8.2, Gargantuan = 0.25 },
		variants = { gold = 0.17, rainbow = 0.045, shiny = 0.011 },
		pity = { Huge = 1200, Titanic = 12500, Gargantuan = 8000 },
		pool = {
			{ id = "starpup", weight = 45 },
			{ id = "nebulanyan", weight = 35 },
			{ id = "quasarwarden", weight = 20 },
		},
	},
	titan = {
		displayName = "Titan Egg",
		zone = 9,
		cost = 400,
		currency = "gems",
		classWeights = { Standard = 930, Huge = 55, Titanic = 13.5, Gargantuan = 0.8 },
		variants = { gold = 0.18, rainbow = 0.05, shiny = 0.012 },
		pity = { Huge = 1500, Titanic = 15000, Gargantuan = 3000 },
		pool = {
			{ id = "titanhatchling", weight = 55 },
			{ id = "worldbreaker", weight = 45 },
		},
	},
}

Eggs.Order = { "meadow", "coral", "ember", "neon", "frost", "void", "umbral", "cosmic", "titan" }

-- Exclusive (Robux) eggs. These are the ones that MUST show a pity bar.
Eggs.Exclusive = {
	magic = {
		displayName = "Magic Egg",
		productId = 0, -- filled from the Roblox product catalog
		cost = 99, -- Robux, display only
		classWeights = { Standard = 900, Huge = 80, Titanic = 19, Gargantuan = 1 },
		variants = { gold = 0.35, rainbow = 0.15, shiny = 0.05 },
		pity = { Huge = 25, Titanic = 150, Gargantuan = 2000 },
		pool = {
			{ id = "quasarwarden", weight = 40 },
			{ id = "eclipsewarden", weight = 35 },
			{ id = "worldbreaker", weight = 25 },
		},
	},
	superdrop = {
		displayName = "Super Drop",
		productId = 0,
		cost = 49,
		classWeights = { Standard = 940, Huge = 55, Titanic = 5, Gargantuan = 0.1 },
		variants = { gold = 0.3, rainbow = 0.1, shiny = 0.03 },
		pity = { Huge = 40, Titanic = 400, Gargantuan = 0 },
		pool = {
			{ id = "neonnyan", weight = 40 },
			{ id = "auroraangel", weight = 35 },
			{ id = "umbraldrake", weight = 25 },
		},
	},
}

function Eggs.get(id: string)
	return Eggs.Definitions[id] or Eggs.Exclusive[id]
end

return Eggs
