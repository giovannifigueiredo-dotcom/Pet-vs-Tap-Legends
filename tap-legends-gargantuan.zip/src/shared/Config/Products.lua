--!strict
--[[
	Products.lua
	The monetization catalog. `productId` / `gamepassId` are placeholders (0)
	until the items exist in the Roblox Creator Dashboard; ShopService reads
	these tables for both granting and the client shop UI.

	PRICING PHILOSOPHY (also in the GDD):
	- Cosmetics and convenience (slots, auto-tap, VIP) are gamepasses: one time.
	- Luck and boosts are dev products: repeatable, transparent odds, pity shown.
	- Nothing sells power directly. Pity and caps keep paying players inside the
	  same progression curve as everyone else (maxPaidPowerShare).
]]

local Products = {}

Products.Gamepasses = {
	vip = {
		name = "VIP",
		productId = 0,
		robux = 399,
		color = "#54E38A",
		perks = { "+25% coins", "+1 team slot", "+1 auto-tap/s", "VIP chat tag", "Daily token bonus" },
	},
	autoTap = {
		name = "Auto-Tap",
		productId = 0,
		robux = 299,
		color = "#4AA8FF",
		perks = { "Taps for you while you are active", "Stacks with Chrono Fang" },
	},
	teamSlots10 = {
		name = "+10 Team Slots",
		productId = 0,
		robux = 349,
		color = "#7DE8FF",
		perks = { "+10 permanent pet slots" },
	},
	teamSlots25 = {
		name = "+25 Team Slots",
		productId = 0,
		robux = 699,
		color = "#7DE8FF",
		perks = { "+25 permanent pet slots" },
	},
	lucky = {
		name = "Lucky Pass",
		productId = 0,
		robux = 249,
		color = "#C46BFF",
		perks = { "-15% pity requirement on every egg" },
	},
	shinyHunter = {
		name = "Shiny Hunter",
		productId = 0,
		robux = 499,
		color = "#FF7AD9",
		perks = { "2x Shiny roll chance", "Shiny pets glow in the inventory" },
	},
}

Products.DevProducts = {
	superdrop = {
		name = "Super Drop x10",
		productId = 0,
		robux = 49,
		kind = "hatchBundle",
		eggId = "superdrop",
		amount = 10,
		color = "#54E38A",
	},
	magicEgg1 = {
		name = "Magic Egg",
		productId = 0,
		robux = 99,
		kind = "hatchBundle",
		eggId = "magic",
		amount = 1,
		color = "#FF7AD9",
	},
	magicEgg5 = {
		name = "Magic Egg x5",
		productId = 0,
		robux = 399,
		kind = "hatchBundle",
		eggId = "magic",
		amount = 5,
		color = "#FF7AD9",
	},
	tokenPouch = {
		name = "Event Token Pouch",
		productId = 0,
		robux = 79,
		kind = "eventTokens",
		amount = 250,
		color = "#FFC53D",
	},
	coinBoost = {
		name = "2x Coins (15m)",
		productId = 0,
		robux = 59,
		kind = "boost",
		boost = { kind = "coin", multiplier = 2, duration = 900 },
		color = "#FFC53D",
	},
}

--- Look up either catalog by id.
function Products.get(id: string)
	return Products.Gamepasses[id] or Products.DevProducts[id]
end

--- Reverse lookup for ProcessReceipt.
function Products.fromProductId(productId: number)
	for _, product in pairs(Products.DevProducts) do
		if product.productId == productId and productId ~= 0 then
			return product
		end
	end
	return nil
end

--- Ordered list for the shop UI (exclusive eggs first).
function Products.shopOrder()
	return {
		{ section = "Exclusive Eggs", items = { Products.DevProducts.magicEgg1, Products.DevProducts.magicEgg5, Products.DevProducts.superdrop } },
		{ section = "Boosts", items = { Products.DevProducts.coinBoost, Products.DevProducts.tokenPouch } },
		{ section = "Passes", items = {
			Products.Gamepasses.vip,
			Products.Gamepasses.autoTap,
			Products.Gamepasses.teamSlots10,
			Products.Gamepasses.teamSlots25,
			Products.Gamepasses.lucky,
			Products.Gamepasses.shinyHunter,
		} },
	}
end

return Products
