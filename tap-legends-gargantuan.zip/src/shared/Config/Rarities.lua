--!strict
--[[
	Rarities.lua

	Pet "rarity" in this game is TWO orthogonal axes, which is what gives the
	expansive Normal -> Gargantuan ladder while staying predictable:

	  Class   : Standard / Huge / Titanic / Gargantuan  (rolled, permanent, huge
	            personal power + a non-stacking team aura)
	  Variant : gold / rainbow / shiny                  (stacking cosmetic+power
	            modifiers, exactly like PS99's Gold / Rainbow / Shiny)

	Effective tier multiplier = class.powerMultiplier * (1 + sum(variant bonus)).
	The doc's single ladder is a flattened view of this table.
]]

local Rarities = {}

Rarities.Classes = {
	Standard = {
		displayName = "Normal",
		order = 1,
		color = "#B9C4D4",
		powerMultiplier = 1,
		teamAura = 0, -- non-stacking global tap bonus
		enchantSlots = 1,
		weightHint = "Common -> Rare",
	},
	Huge = {
		displayName = "Huge",
		order = 2,
		color = "#54E38A",
		powerMultiplier = 6,
		teamAura = 0.20,
		enchantSlots = 2,
		weightHint = "1 in 1,000 to 1 in 25,000",
	},
	Titanic = {
		displayName = "Titanic",
		order = 3,
		color = "#FFC53D",
		powerMultiplier = 30,
		teamAura = 0.50,
		enchantSlots = 3,
		weightHint = "1 in 25,000 to 1 in 500,000",
	},
	Gargantuan = {
		displayName = "Gargantuan",
		order = 4,
		color = "#C46BFF",
		powerMultiplier = 150,
		teamAura = 1.25,
		enchantSlots = 4,
		weightHint = "pity-only chase (50,000 hatches)",
	},
}

Rarities.Variants = {
	normal = { displayName = "Normal", order = 0, color = "#E8EEF7", powerBonus = 0 },
	gold = { displayName = "Gold", order = 1, color = "#FFC53D", powerBonus = 0.5 },
	rainbow = { displayName = "Rainbow", order = 2, color = "#FF7AD9", powerBonus = 1.5 },
	shiny = { displayName = "Shiny", order = 3, color = "#7DE8FF", powerBonus = 3.0 },
}

-- Variants are rolled independently and STACK (a "Rainbow Shiny Huge" is the
-- flex). maxVariantStack = how many can be held at once; maxVariantPowerBonus
-- caps the total power bonus so the top end stays tunable.
Rarities.maxVariantStack = 3
Rarities.maxVariantPowerBonus = 9

-- Sort/priority helper for UI ("best first").
function Rarities.classOrder(classId: string): number
	local def = Rarities.Classes[classId]
	return if def then def.order else 0
end

function Rarities.variantPowerBonus(variants: { string }?): number
	if not variants then
		return 0
	end
	local total: number = 0
	for _, id in ipairs(variants) do
		local def = Rarities.Variants[id]
		if def then
			total += (def.powerBonus :: number)
		end
	end
	return math.min(total, Rarities.maxVariantPowerBonus)
end

return Rarities
