--!strict
--[[
	Balance.lua
	Single source of truth for tuning. PURE DATA + NO ROBLOX APIS so it can be
	unit-tested with the standalone Luau CLI and shared by server + client.

	Every number the design doc quotes lives here. Change it here, run
	npm-less test suite `luau tests/run_tests.luau`, ship.
]]

local Balance = {}

Balance.Version = 1

-- ===========================================================================
-- TAPPING (Tap Simulator Reborn lineage)
-- ===========================================================================
Balance.Tap = {
	-- Damage floor before ANY multiplier. Every player starts tapping for this.
	baseTap = 1,

	-- "Tap Power" upgrade bought with coins near the tap area.
	upgrade = {
		baseCost = 40,
		costGrowth = 1.17,
		flatPerLevel = 1,
		maxLevel = 400,
		-- Every N levels the whole tap line gets a step multiplier (big "juice"
		-- moment; keeps mid-game taps feeling like they matter).
		milestoneEvery = 25,
		milestoneMultiplier = 1.5,
	},

	crit = {
		baseChance = 0.05,
		perUpgradeLevel = 0.002,
		maxChance = 0.40,
		damageMultiplier = 5,
	},

	-- Server-authoritative rate limiting. Mobile double-taps are bursty, so we
	-- use a token bucket (burst + refill) instead of a hard per-second clamp.
	server = {
		maxTapsPerSecond = 22,
		burstAllowance = 34,
		suspicionWindowSeconds = 5,
		maxRejectedBeforeKick = 250,
	},
}

-- ===========================================================================
-- TEAM / PET MULTIPLIER (Pet Simulator 99 lineage)
-- ===========================================================================
Balance.Team = {
	baseSlots = 8,
	hardMaxSlots = 250,
	maxPetLevel = 50,
	levelPowerPerLevel = 0.04, -- L50 standard pet = x2.96 personal power

	-- petMultiplier = 1 + effectiveTeamPower / petPowerScale
	petPowerScale = 100,

	-- Soft cap keeps 250-pet teams from trivialising content while still
	-- rewarding collection. Above the cap, gains are sub-linear.
	softCapStart = 20000,
	softCapExponent = 0.88,

	-- Huge/Titanic/Gargantuan auras do NOT stack: only the best one applies.
	-- (Prevents "equip 100 Huges" from becoming the only strategy.)
	auraStacks = false,
}

-- ===========================================================================
-- SYNERGY (new system)
-- ===========================================================================
-- Synergy is SHARE based, not count based, so it scales from an 8-slot early
-- team to a 250-slot endgame team. The dominant element/family counts in full,
-- every other qualifying group counts at secondaryEfficiency.
Balance.Synergy = {
	maxMultiplier = 8,
	secondaryEfficiency = 0.25,
	-- Multiplier is the TOTAL for that group (1.0 = no bonus).
	elementTiers = {
		{ minCount = 2, share = 0.25, multiplier = 1.10 },
		{ minCount = 3, share = 0.50, multiplier = 1.25 },
		{ minCount = 4, share = 0.75, multiplier = 1.55 },
		{ minCount = 6, share = 0.90, multiplier = 2.00 },
		{ minCount = 8, share = 1.00, multiplier = 3.00 },
	},
	familyTiers = {
		{ minCount = 2, share = 0.25, multiplier = 1.08 },
		{ minCount = 3, share = 0.50, multiplier = 1.20 },
		{ minCount = 4, share = 0.75, multiplier = 1.45 },
		{ minCount = 6, share = 0.90, multiplier = 1.80 },
		{ minCount = 8, share = 1.00, multiplier = 2.50 },
	},
}

-- ===========================================================================
-- REBIRTH
-- ===========================================================================
Balance.Rebirth = {
	maxRebirths = 100,
	baseRequirement = 1e6,
	requirementGrowth = 3.2,
	linearPerRebirth = 0.35,
	quadraticPerRebirth = 0.02,

	-- Tokens are the player-to-player trading currency. They are ONLY earned
	-- in game (rebirth + raids + events) which keeps the trade economy legit.
	tokenBase = 5,
	tokenExponent = 1.35,

	-- Milestone unlocks referenced by services and the doc.
	slotsPerRebirthMilestone = { at = 5, slots = 2, upTo = 60 },
	relicSlotRebirths = { 0, 5, 12, 25 }, -- slot 1 free, then R5 / R12 / R25
}

-- ===========================================================================
-- ECONOMY
-- ===========================================================================
Balance.Economy = {
	coinsPerTapZoneScale = 1.0, -- coin income == damage in zone content
	gemFromDuplicateBase = 2,
	gemFromDuplicatePerPower = 0.05,
	sellValueRatio = 0.08, -- sell price vs. egg cost contribution
	tradeTaxPercent = 0.05, -- sink on token trades, burns inflation
	tradeCooldownSeconds = 20,
	maxTradesPerHour = 30,
	tradeValueBand = 0.35, -- anti-scam: warn if sides differ by >35% value
}

-- ===========================================================================
-- RAIDS & EVENTS
-- ===========================================================================
Balance.Raid = {
	intervalSeconds = 4 * 60 * 60,
	windupSeconds = 60,
	durationSeconds = 300,
	minPlayers = 1,
	-- Boss HP = baseHealth + powerHealthRatio * sum(damagePerTap). HP is measured
	-- against a 5 minute window at ~10 taps/s, so the fight lands at 55-70%
	-- of the theoretical maximum output (challenging, not impossible).
	powerHealthRatio = 300,
	baseHealth = 2500,
	contributionRewardTiers = { 0.02, 0.10, 0.25, 0.50 }, -- share of damage
	participationMinimumDamageShare = 0.005,
	exclusiveEggChancePerTier = { 0, 0.15, 0.45, 1.0 },
	tokenRewardPerMillion = 0.25,
}

Balance.Events = {
	-- Hourly, on the hour. 12 minute active window, 3 minute warning.
	intervalSeconds = 60 * 60,
	warningLeadSeconds = 180,
	durationSeconds = 12 * 60,
	rotation = { "LuckyBlock", "CoinArcade", "MeteorShower", "SynergySurge" },
	rewards = {
		LuckyBlock = { coins = 1.0, gems = 4, tokens = 2 },
		CoinArcade = { coins = 2.5, gems = 2, tokens = 1 },
		MeteorShower = { coins = 1.5, gems = 6, tokens = 1 },
		SynergySurge = { coins = 1.0, gems = 3, tokens = 2 },
	},
	synergySurgeMultiplier = 2.0,
}

-- ===========================================================================
-- MONETIZATION / FAIRNESS GUARDRAILS
-- ===========================================================================
Balance.Shop = {
	-- Pity is a real guarantee, not decoration.
	luckyPassPityReduction = 0.15, -- -15% pity requirement
	vipCoinMultiplier = 1.25,
	vipExtraSlots = 1,
	vipAutoTapRate = 1,
	superDropsPerProduct = 10,
	magicEggVariantFloor = "rainbow", -- Magic Eggs roll at least Rainbow
	-- A single purchase may never exceed this share of a player's total power.
	maxPaidPowerShare = 0.35,
}

-- ===========================================================================
-- BOOSTS
-- ===========================================================================
Balance.Boosts = {
	-- Boosts of the same type ADD, then are applied once (never multiplied
	-- together) to stop 2x * 2x * 2x stacking exploits.
	maxSameTypeStacks = 3,
	defaultDurationSeconds = 15 * 60,
}

-- ===========================================================================
-- PITY (used by Eggs + Enchant rerolls + Relic forging)
-- ===========================================================================
Balance.Pity = {
	-- chance(counter) ramps from baseChance to 100% at hardPity.
	-- softStart begins the ramp; before that it is flat baseChance.
	softStart = 0.6, -- fraction of hardPity where the ramp begins
	curve = 2, -- exponent of the ramp (2 = accelerating, feels generous late)
}

-- ===========================================================================
-- CLIENT / UI
-- ===========================================================================
Balance.UI = {
	inventoryPageSize = 60,
	virtualisedRowHeight = 96,
	maxFolders = 30,
	quickCompareHoldSeconds = 0.35,
	toastLifetimeSeconds = 3,
	damageNumberPoolSize = 90,
}

return Balance
