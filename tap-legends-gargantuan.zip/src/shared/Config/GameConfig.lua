--!strict
--[[
	GameConfig.lua
	Roblox-side aggregation of every config module into the single `config`
	table that MultiplierEngine / TapEngine / EggMath expect.

	Pure modules (Balance, Rarities, ...) never require each other via
	`script.Parent`, which keeps them runnable in the standalone Luau test
	suite. ONLY this file uses Roblox instance paths.
]]

local Config = {}

Config.Balance = require(script.Parent.Balance)
Config.Rarities = require(script.Parent.Rarities)
Config.Elements = require(script.Parent.Elements)
Config.PetsModule = require(script.Parent.Pets)
Config.EggsModule = require(script.Parent.Eggs)
Config.RelicsModule = require(script.Parent.Relics)
Config.Enchants = require(script.Parent.Enchants)
Config.ZonesModule = require(script.Parent.Zones)
Config.Products = require(script.Parent.Products)

-- Engines expect plain maps, not modules:
Config.Eggs = Config.EggsModule.Definitions
Config.ExclusiveEggs = Config.EggsModule.Exclusive
Config.Zones = Config.ZonesModule.Definitions

-- Flatten the bits the engines index directly.
Config.Classes = Config.Rarities.Classes
Config.Variants = Config.Rarities.Variants
Config.maxVariantStack = Config.Rarities.maxVariantStack
Config.maxVariantPowerBonus = Config.Rarities.maxVariantPowerBonus
Config.Pets = Config.PetsModule.Definitions
Config.Relics = Config.RelicsModule.Definitions

return Config
