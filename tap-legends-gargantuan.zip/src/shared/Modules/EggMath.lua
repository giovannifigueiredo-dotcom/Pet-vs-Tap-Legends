--!nonstrict
--[[
	EggMath.lua
	===========
	Weighted pet roll + class roll + variant roll + pity, all server-side and
	all pure/deterministic given an RNG function.

	Order matters and is deliberate:
	  1. class roll (with pity)   - decides Standard/Huge/Titanic/Gargantuan
	  2. pet roll                 - weighted pick inside the egg pool
	  3. variant roll             - independent gold/rainbow/shiny rolls (stack)

	Pity is tracked per egg PER CLASS, so a Huge pity counter never eats a
	Titanic one.
]]

local EggMath = {}

type Dict = { [string]: any }

--- Weighted pick. `rng` returns [0,1). Returns nil if the pool is empty.
function EggMath.weightedPick(pool: { Dict }, rng: () -> number): Dict?
	local total = 0
	for _, entry in ipairs(pool) do
		total += math.max(0, entry.weight or 0)
	end
	if total <= 0 then
		return nil
	end

	local target = rng() * total
	local cursor = 0
	for _, entry in ipairs(pool) do
		cursor += math.max(0, entry.weight or 0)
		if target < cursor then
			return entry
		end
	end
	return pool[#pool]
end

--- Class roll with pity counters (mutated in place: pity[classId] = counter).
function EggMath.rollClass(egg: Dict, pity: Dict, rng: () -> number, luckReduction: number?): Dict
	local weights = egg.classWeights or {}
	local classPity = egg.pity or {}

	-- 1. hard pity first: guarantees beat RNG. A class with zero weight can
	-- never be pity-guaranteed (e.g. Gargantuan is disabled in early eggs).
	for classId, hardPity in pairs(classPity) do
		local weight = weights[classId] or 0
		if hardPity and hardPity > 0 and weight > 0 then
			local effective = math.max(1, math.floor(hardPity * (1 - (luckReduction or 0))))
			local counter = tonumber(pity[classId]) or 0
			if counter + 1 >= effective then
				pity[classId] = 0
				return { class = classId, pityTriggered = true, chance = 1 }
			end
		end
	end

	-- 2. weighted roll.
	local options = {}
	for classId, weight in pairs(weights) do
		if weight and weight > 0 then
			table.insert(options, { class = classId, weight = weight })
		end
	end
	local picked = EggMath.weightedPick(options, rng)
	local classId = if picked then picked.class else "Standard"

	-- 3. update pity counters: selected class resets, others increment.
	for otherClass, hardPity in pairs(classPity) do
		if hardPity and hardPity > 0 and otherClass ~= classId then
			pity[otherClass] = (tonumber(pity[otherClass]) or 0) + 1
		end
	end
	if pity[classId] ~= nil then
		pity[classId] = 0
	end

	return {
		class = classId,
		pityTriggered = false,
	}
end

--- Independent variant rolls; variants stack. `shinyMultiplier` is the Shiny
--- Hunter pass (2x Shiny odds) and applies ONLY to the shiny roll.
function EggMath.rollVariants(egg: Dict, rng: () -> number, minVariant: string?, shinyMultiplier: number?): { string }
	local chances = egg.variants or {}
	local order = { "gold", "rainbow", "shiny" }
	local floorIndex = 0
	if minVariant then
		for index, id in ipairs(order) do
			if id == minVariant then
				floorIndex = index
			end
		end
	end

	local rolled = {}
	for index, id in ipairs(order) do
		local chance = chances[id] or 0
		if id == "shiny" then
			chance = math.min(1, chance * (shinyMultiplier or 1))
		end
		local mustRoll = index <= floorIndex
		local hit = mustRoll or (chance > 0 and rng() < chance)
		if hit then
			table.insert(rolled, id)
		end
	end
	return rolled
end

--- Full hatch. `state.pity[eggId][classId]` counters are mutated.
function EggMath.hatch(eggId: string, config: Dict, state: Dict, rng: () -> number, options: Dict?): Dict
	local egg = config.Eggs[eggId]
	if not egg then
		return { ok = false, reason = "unknownEgg" }
	end

	state.pity = state.pity or {}
	state.pity[eggId] = state.pity[eggId] or {}

	local opts = options or {}
	local luckReduction = nil
	if opts.applyLuck then
		-- Luck bonuses accelerate pity instead of silently changing odds.
		luckReduction = math.clamp(opts.luck or 0, 0, 0.5)
	end

	local classRoll = EggMath.rollClass(egg, state.pity[eggId], rng, luckReduction)
	local petEntry = EggMath.weightedPick(egg.pool, rng)
	if not petEntry then
		return { ok = false, reason = "emptyPool" }
	end

	local variants = EggMath.rollVariants(egg, rng, opts.minVariant, opts.shinyMultiplier)
	local petDef = config.Pets[petEntry.id]

	return {
		ok = true,
		eggId = eggId,
		petId = petEntry.id,
		className = classRoll.class,
		pityTriggered = classRoll.pityTriggered,
		variants = variants,
		element = if petDef then petDef.element else "Nature",
		family = if petDef then petDef.family else "Beast",
		basePower = if petDef then petDef.basePower else 0,
		isNew = false, -- PetService sets this against the player's collection
	}
end

--- Odds shown in the egg tooltip: class chance per hatch, pity included.
function EggMath.displayOdds(egg: Dict): { Dict }
	local total = 0
	local rows = {}
	for classId, weight in pairs(egg.classWeights or {}) do
		total += weight
		table.insert(rows, { class = classId, weight = weight })
	end
	for _, row in ipairs(rows) do
		row.chance = if total > 0 then row.weight / total else 0
	end
	table.sort(rows, function(a, b)
		return a.chance > b.chance
	end)
	return rows
end

--- Expected hatches to a class from raw odds (before pity). Used in balance docs.
function EggMath.expectedHatches(egg: Dict, classId: string): number
	local total = 0
	for _, weight in pairs(egg.classWeights or {}) do
		total += weight
	end
	local weight = (egg.classWeights or {})[classId] or 0
	if weight <= 0 or total <= 0 then
		return math.huge
	end
	return total / weight
end

return EggMath
