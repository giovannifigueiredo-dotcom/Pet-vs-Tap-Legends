--!nonstrict
--[[
	InventoryQuery.lua
	==================
	The search/filter/sort engine behind "Massive Inventory Management".
	Pure collection math: the client sorts thousands of pets inside one frame
	budget and the server can run the identical ordering when validating trades.

	Sorts:
	  power         - raw pet power
	  synergy       - marginal synergy gain if added to the current team
	  element       - grouped by element, best power first inside a group
	  tapMultiplier - per-pet contribution to the team tap multiplier
	  class         - Normal -> Gargantuan
	  level / newest / name

	PERFORMANCE NOTE: synergy depends only on (element, family) counts, so the
	marginal synergy of every pet in a group is identical. We compute it once
	per (element,family) pair, never per pet. This is the difference between
	0.4ms and 90ms on a 20,000-pet inventory.
]]

local InventoryQuery = {}

type Dict = { [string]: any }

InventoryQuery.SortModes = {
	{ id = "power", label = "Power" },
	{ id = "synergy", label = "Synergy" },
	{ id = "element", label = "Element" },
	{ id = "tapMultiplier", label = "Tap Multiplier" },
	{ id = "class", label = "Rarity" },
	{ id = "level", label = "Level" },
	{ id = "newest", label = "Newest" },
	{ id = "name", label = "Name" },
}

-- ===========================================================================
-- Filtering
-- ===========================================================================

function InventoryQuery.matches(pet: Dict, petDef: Dict?, filters: Dict?): boolean
	if not filters then
		return true
	end

	if filters.search and filters.search ~= "" then
		local needle = string.lower(filters.search)
		local name = string.lower(if petDef then petDef.name else pet.id)
		local element = string.lower(if petDef then petDef.element else "")
		local family = string.lower(if petDef then petDef.family else "")
		if not (string.find(name, needle, 1, true) or string.find(element, needle, 1, true) or string.find(family, needle, 1, true)) then
			return false
		end
	end

	if filters.element and filters.element ~= "All" then
		if not petDef or petDef.element ~= filters.element then
			return false
		end
	end

	if filters.family and filters.family ~= "All" then
		if not petDef or petDef.family ~= filters.family then
			return false
		end
	end

	if filters.class and filters.class ~= "All" then
		if (pet.class or "Standard") ~= filters.class then
			return false
		end
	end

	if filters.variant and filters.variant ~= "All" then
		local found = false
		for _, id in ipairs(pet.variants or {}) do
			if id == filters.variant then
				found = true
				break
			end
		end
		if not found then
			return false
		end
	end

	if filters.lockedOnly and not pet.locked then
		return false
	end

	if filters.folderId then
		-- folderMembership is a uid -> folderId map (see folderMembership()).
		local membership = filters.folderMembership
		if not membership or membership[pet.uid] ~= filters.folderId then
			return false
		end
	end

	if filters.minPower and filters.minPower > 0 then
		if (tonumber(pet.power) or 0) < filters.minPower then
			return false
		end
	end

	if filters.excludeEquipped and pet.equipped then
		return false
	end

	return true
end

-- ===========================================================================
-- Query (filter -> score -> sort -> paginate)
-- ===========================================================================

--[[
	query(pets, petsConfig, options) -> { rows, total, page, pageCount }

	options = {
	  filters  = { search, element, family, class, variant, lockedOnly,
	               folderId, folderMembership, minPower, excludeEquipped }
	  sort     = "power" | "synergy" | "element" | "tapMultiplier" | ...
	  ascending = false
	  page = 1, pageSize = 60
	  team = { equipped pets }   -- synergy / tap multiplier are marginal vs team
	  engine = MultiplierEngine, config = full config
	}
]]
function InventoryQuery.query(pets: { Dict }, petsConfig: Dict, options: Dict?): Dict
	local opts = options or {}
	local filters = opts.filters
	local sortMode = opts.sort or "power"
	local engine = opts.engine
	local config = opts.config or {}
	local team = opts.team or {}

	local filtered = {}
	for _, pet in ipairs(pets) do
		if InventoryQuery.matches(pet, petsConfig[pet.id], filters) then
			table.insert(filtered, pet)
		end
	end

	local teamPowerScale = if config.Balance then config.Balance.Team.petPowerScale else 100
	local synergyCache: Dict = {}

	local function synergyDeltaFor(pet: Dict, petDef: Dict?): number
		if not engine then
			return 0
		end
		local key = (if petDef then petDef.element else "?") .. "|" .. (if petDef then petDef.family else "?")
		local cached = synergyCache[key]
		if cached == nil then
			cached = engine.marginalSynergy(pet, team, config)
			synergyCache[key] = cached
		end
		return cached
	end

	local rows = {}
	for _, pet in ipairs(filtered) do
		local petDef = petsConfig[pet.id]
		local power = if engine then engine.petPower(pet, config) else (tonumber(pet.power) or 0)
		local synergyDelta = synergyDeltaFor(pet, petDef)
		table.insert(rows, {
			pet = pet,
			def = petDef,
			power = power,
			synergyDelta = synergyDelta,
			tapMultiplierIfAdded = 1 + power / teamPowerScale,
			score = power * (1 + synergyDelta),
		})
	end

	local classOrder = config.Classes or {}

	local function tieBreak(a: Dict, b: Dict): boolean
		if a.power == b.power then
			return tostring(a.pet.uid) < tostring(b.pet.uid)
		end
		return a.power > b.power
	end

	local function compare(a: Dict, b: Dict): boolean
		if sortMode == "power" then
			return tieBreak(a, b)
		elseif sortMode == "synergy" then
			if a.synergyDelta == b.synergyDelta then
				return tieBreak(a, b)
			end
			return a.synergyDelta > b.synergyDelta
		elseif sortMode == "tapMultiplier" then
			if a.tapMultiplierIfAdded == b.tapMultiplierIfAdded then
				return tieBreak(a, b)
			end
			return a.tapMultiplierIfAdded > b.tapMultiplierIfAdded
		elseif sortMode == "element" then
			local ae = if a.def then a.def.element else ""
			local be = if b.def then b.def.element else ""
			if ae == be then
				return a.power > b.power
			end
			return ae < be
		elseif sortMode == "class" then
			local ad = classOrder[a.pet.class or "Standard"]
			local bd = classOrder[b.pet.class or "Standard"]
			local ao = if ad then ad.order else 0
			local bo = if bd then bd.order else 0
			if ao == bo then
				return a.power > b.power
			end
			return ao > bo
		elseif sortMode == "level" then
			local al = tonumber(a.pet.level) or 1
			local bl = tonumber(b.pet.level) or 1
			if al == bl then
				return a.power > b.power
			end
			return al > bl
		elseif sortMode == "newest" then
			local at = tonumber(a.pet.acquiredAt) or 0
			local bt = tonumber(b.pet.acquiredAt) or 0
			if at == bt then
				return tieBreak(a, b)
			end
			return at > bt
		elseif sortMode == "name" then
			local an = if a.def then a.def.name else a.pet.id
			local bn = if b.def then b.def.name else b.pet.id
			if an == bn then
				return a.power > b.power
			end
			return an < bn
		end
		return tieBreak(a, b)
	end

	table.sort(rows, compare)

	if opts.ascending then
		local reversed = {}
		for index = #rows, 1, -1 do
			table.insert(reversed, rows[index])
		end
		rows = reversed
	end

	local pageSize = math.max(1, opts.pageSize or 60)
	local page = math.max(1, tonumber(opts.page) or 1)
	local total = #rows
	local startIndex = (page - 1) * pageSize + 1
	local pageRows = {}
	for index = startIndex, math.min(total, startIndex + pageSize - 1) do
		table.insert(pageRows, rows[index])
	end

	return {
		rows = pageRows,
		total = total,
		page = page,
		pageCount = math.max(1, math.ceil(total / pageSize)),
	}
end

-- ===========================================================================
-- Folders
-- ===========================================================================
-- Folders are player-created (cap Balance.UI.maxFolders), stored in the
-- profile as { [folderId] = { name, icon, petUids = {...} } }. A pet lives in
-- exactly ONE folder, which keeps trade and equip validation unambiguous.
-- ===========================================================================

function InventoryQuery.createFolder(folders: Dict, name: string, maxFolders: number, idFactory: (() -> string)?): (string?, string?)
	local count = 0
	for _ in pairs(folders) do
		count += 1
	end
	if count >= maxFolders then
		return nil, "folderLimit"
	end
	if name == "" or #name > 24 then
		return nil, "badName"
	end

	local id
	if idFactory then
		id = idFactory()
	else
		id = string.format("f_%d_%d", os.time(), math.random(1000, 9999))
	end
	if folders[id] then
		return nil, "idCollision"
	end

	folders[id] = { name = name, icon = "folder", petUids = {} }
	return id, nil
end

function InventoryQuery.assignToFolder(folders: Dict, folderId: string, petUid: string): boolean
	local target = folders[folderId]
	if not target then
		return false
	end
	for _, folder in pairs(folders) do
		local list = folder.petUids
		for index = #list, 1, -1 do
			if list[index] == petUid then
				table.remove(list, index)
			end
		end
	end
	table.insert(target.petUids, petUid)
	return true
end

function InventoryQuery.removeFromFolders(folders: Dict, petUid: string)
	for _, folder in pairs(folders) do
		local list = folder.petUids
		for index = #list, 1, -1 do
			if list[index] == petUid then
				table.remove(list, index)
			end
		end
	end
end

--- uid -> folderId map for filters.folderMembership.
function InventoryQuery.folderMembership(folders: Dict): Dict
	local membership: Dict = {}
	for folderId, folder in pairs(folders) do
		for _, uid in ipairs(folder.petUids) do
			membership[uid] = folderId
		end
	end
	return membership
end

return InventoryQuery
