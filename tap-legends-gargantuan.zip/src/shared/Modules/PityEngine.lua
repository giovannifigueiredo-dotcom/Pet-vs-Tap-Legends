--!strict
--[[
	PityEngine.lua
	==============
	One pity implementation for every gacha surface (eggs, enchant rerolls,
	relic forging). The UI needs an honest bar, so the math is:

	  counter < softStartAt          -> baseChance (flat, unlucky feels normal)
	  softStartAt <= counter < hard  -> baseChance + (1-base) * t^curve
	                                    t = (counter - softStartAt) / (hard - softStartAt)
	  counter >= hard                -> 1.0 (guaranteed)

	`progress()` returns 0..1 for the visual bar. The bar is real: at progress 1
	the drop is guaranteed, which is the whole point of showing it.
]]

local PityEngine = {}

type Dict = { [string]: any }

--- Effective chance at a given miss counter.
function PityEngine.chanceAt(baseChance: number, counter: number, hardPity: number, softStart: number?, curve: number?): number
	if hardPity <= 0 then
		return baseChance
	end
	if counter >= hardPity then
		return 1
	end

	local softFraction = softStart or 0.6
	local exponent = curve or 2
	local softStartAt = math.floor(hardPity * softFraction)

	if counter < softStartAt then
		return baseChance
	end

	local span = math.max(1, hardPity - softStartAt)
	local t = (counter - softStartAt) / span
	return math.min(0.999, baseChance + (1 - baseChance) * (t ^ exponent))
end

--- Bar fill 0..1 (counter / hard pity). Clamped so it never overflows.
function PityEngine.progress(counter: number, hardPity: number): number
	if hardPity <= 0 then
		return 0
	end
	return math.clamp(counter / hardPity, 0, 1)
end

--- Remaining hatches/rerolls until the guarantee.
function PityEngine.remaining(counter: number, hardPity: number): number
	return math.max(0, hardPity - counter)
end

--- Rolls once against current pity state.
--- `rollFn` is injected so tests and the server can share one code path:
---   rollFn() -> number in [0,1)
--- Returns { success, counter (new), chance }
function PityEngine.roll(state: Dict, rollFn: () -> number): Dict
	local counter = tonumber(state.counter) or 0
	local chance = PityEngine.chanceAt(state.baseChance, counter, state.hardPity, state.softStart, state.curve)
	local success = rollFn() < chance
	return {
		success = success,
		counter = if success then 0 else counter + 1,
		chance = chance,
	}
end

--- Convenience: pity config from a config table + luck modifier (enchant/pass).
function PityEngine.effectiveHardPity(hardPity: number, luckReduction: number?): number
	local reduction = math.clamp(tonumber(luckReduction) or 0, 0, 0.75)
	return math.max(1, math.floor(hardPity * (1 - reduction)))
end

--- Build the payload the client needs to draw the pity bar.
function PityEngine.barData(counter: number, hardPity: number, baseChance: number, softStart: number?): Dict
	local chance = PityEngine.chanceAt(baseChance, counter, hardPity, softStart)
	return {
		counter = counter,
		hardPity = hardPity,
		progress = PityEngine.progress(counter, hardPity),
		remaining = PityEngine.remaining(counter, hardPity),
		chance = chance,
		inSoftPity = hardPity > 0 and counter >= math.floor(hardPity * (softStart or 0.6)),
		guaranteed = hardPity > 0 and counter >= hardPity,
	}
end

return PityEngine
