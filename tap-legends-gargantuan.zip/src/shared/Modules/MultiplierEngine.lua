--!nonstrict
--[[
	MultiplierEngine.lua
	====================
	THE PET MULTIPLIER MATH. Pure, deterministic, dependency-injected.

	Damage pipeline (server authoritative, reproduced on client for prediction):

	  damagePerTap = flatTap * (pets * aura * synergy * rebirth
	                            * enchant * relic * boost * event)

	  flatTap      = (baseTap + upgradeFlat + relicFlat) * upgradeMilestones
	  pets         = 1 + effectiveTeamPower / petPowerScale
	  effectiveTeamPower = softCap( sum(petPower) )
	  petPower_i   = basePower * classMult * (1 + variantBonus)
	                 * levelMult * itemPowerEnchants * curseMult
	  aura         = 1 + max(class.teamAura)        (non-stacking by design)
	  synergy      = 1 + elementBonus + familyBonus   (share based, capped)
	  rebirth      = 1 + 0.35n + 0.02n^2
	  enchant      = 1 + teamTapEnchants
	  relic        = product of relic tap multipliers
	  boost/event  = time-limited server buffs

	Nothing in here touches Roblox APIs, wal? no, nothing mutates input. That is
	what lets the test suite load the real config and assert real numbers.
]]

local MultiplierEngine = {}

type Dict = { [string]: any }

-- ===========================================================================
-- Helpers
-- ===========================================================================

local function variantPowerBonus(variants: { string }?, config: Dict): number
	if not variants then
		return 0
	end
	local total = 0
	for _, id in ipairs(variants) do
		local def = config.Variants[id]
		if def then
			total += def.powerBonus
		end
	end
	-- Cap the stack: rainbow + shiny + gold is the ceiling (5.0 bonus).
	return math.min(total, config.maxVariantPowerBonus or 9)
end

local function classDef(config: Dict, classId: string?): Dict
	local classes = config.Classes
	return classes[classId or "Standard"] or classes.Standard
end

-- ===========================================================================
-- 1. Single pet power
-- ===========================================================================

--- Power of ONE pet, before team/synergy/teamwide multipliers.
function MultiplierEngine.petPower(pet: Dict, config: Dict): number
	local def = config.Pets[pet.id]
	if not def then
		return 0
	end

	local teamCfg = config.Balance.Team
	local class = classDef(config, pet.class)

	local level = math.clamp(tonumber(pet.level) or 1, 1, teamCfg.maxPetLevel)
	local levelMult = 1 + teamCfg.levelPowerPerLevel * (level - 1)
	local variantMult = 1 + variantPowerBonus(pet.variants, config)

	-- Per-item enchants (Might) resolve to a fraction, e.g. 0.35 for tier IV.
	local itemEnchantMult = 1 + (tonumber(pet.enchantPowerBonus) or 0)
	local curseMult = 1 + (tonumber(pet.cursePowerMultiplier) or 0)

	return def.basePower
		* class.powerMultiplier
		* variantMult
		* levelMult
		* itemEnchantMult
		* math.max(0, curseMult)
end

-- ===========================================================================
-- 2. Team power (with soft cap)
-- ===========================================================================

--- Sum of all equipped pets, soft-capped so 250-pet teams stay tunable.
function MultiplierEngine.teamPower(pets: { Dict }?, config: Dict): Dict
	local teamCfg = config.Balance.Team
	local raw = 0
	local count = 0

	if pets then
		for _, pet in ipairs(pets) do
			local power = MultiplierEngine.petPower(pet, config)
			if power > 0 then
				raw += power
				count += 1
			end
		end
	end

	local effective = raw
	local softCapped = false
	if raw > teamCfg.softCapStart then
		effective = teamCfg.softCapStart * ((raw / teamCfg.softCapStart) ^ teamCfg.softCapExponent)
		softCapped = true
	end

	return {
		raw = raw,
		effective = effective,
		softCapped = softCapped,
		count = count,
		-- This is the number the HUD shows as "Pets".
		multiplier = 1 + effective / teamCfg.petPowerScale,
	}
end

-- ===========================================================================
-- 3. Class aura (non-stacking)
-- ===========================================================================

--- Best Huge/Titanic/Gargantuan aura on the team. Only one applies.
function MultiplierEngine.teamAura(pets: { Dict }?, config: Dict): Dict
	local bestAura = 0
	local bestClass = "Standard"

	if pets then
		for _, pet in ipairs(pets) do
			local class = classDef(config, pet.class)
			local aura = tonumber(class.teamAura) or 0
			if aura > bestAura then
				bestAura = aura
				for id, def in pairs(config.Classes) do
					if def == class then
						bestClass = id
						break
					end
				end
			end
		end
	end

	return {
		multiplier = 1 + bestAura,
		aura = bestAura,
		classId = bestClass,
	}
end

-- ===========================================================================
-- 4. Synergy (elements + families)
-- ===========================================================================

local function tierFor(count: number, total: number, tiers: { Dict }): (Dict?, number)
	local share = if total > 0 then count / total else 0
	local best: Dict? = nil
	for _, tier in ipairs(tiers) do
		if count >= tier.minCount and share >= tier.share then
			best = tier
		end
	end
	return best, share
end

local function groupBreakdown(counts: Dict, total: number, tiers: { Dict }, efficiency: number): Dict
	local qualified = {}
	for name, count in pairs(counts) do
		local tier = tierFor(count, total, tiers)
		if tier then
			table.insert(qualified, {
				name = name,
				count = count,
				share = count / math.max(1, total),
				multiplier = tier.multiplier,
				bonus = tier.multiplier - 1,
			})
		end
	end

	table.sort(qualified, function(a, b)
		if a.bonus == b.bonus then
			return a.count > b.count
		end
		return a.bonus > b.bonus
	end)

	local bonus = 0
	local dominant = qualified[1]
	if dominant then
		bonus += dominant.bonus
		for index = 2, #qualified do
			bonus += qualified[index].bonus * efficiency
		end
	end

	return {
		multiplier = 1 + bonus,
		bonus = bonus,
		dominant = dominant,
		groups = qualified,
	}
end

--- Share-based element + family synergy. Mono teams win big.
--- example: 8/8 Fire + 8/8 Dragon => element x3.00, family x2.50 => 1+2+1.5 = x4.5
function MultiplierEngine.synergy(pets: { Dict }?, config: Dict): Dict
	local cfg = config.Balance.Synergy
	local elementCounts: Dict = {}
	local familyCounts: Dict = {}
	local total = 0

	if pets then
		for _, pet in ipairs(pets) do
			local def = config.Pets[pet.id]
			if def then
				total += 1
				elementCounts[def.element] = (elementCounts[def.element] or 0) + 1
				familyCounts[def.family] = (familyCounts[def.family] or 0) + 1
			end
		end
	end

	local element = groupBreakdown(elementCounts, total, cfg.elementTiers, cfg.secondaryEfficiency)
	local family = groupBreakdown(familyCounts, total, cfg.familyTiers, cfg.secondaryEfficiency)
	local combined = math.min(1 + element.bonus + family.bonus, cfg.maxMultiplier)

	return {
		multiplier = combined,
		element = element,
		family = family,
		totalPets = total,
		dominantElement = if element.dominant then element.dominant.name else nil,
		dominantFamily = if family.dominant then family.dominant.name else nil,
	}
end

--- What would adding `pet` to `team` do to the synergy multiplier?
--- Used by "Sort by Synergy" and the Quick Compare tooltip.
function MultiplierEngine.marginalSynergy(pet: Dict, team: { Dict }?, config: Dict): number
	local current = MultiplierEngine.synergy(team, config).multiplier
	local extended = {}
	if team then
		for _, member in ipairs(team) do
			table.insert(extended, member)
		end
	end
	table.insert(extended, pet)
	return MultiplierEngine.synergy(extended, config).multiplier - current
end

-- ===========================================================================
-- 5. Rebirth
-- ===========================================================================

--- 1 + 0.35n + 0.02n^2  =>  R10 x6.5, R30 x29.5, R100 x236
function MultiplierEngine.rebirthMultiplier(rebirths: number?, config: Dict): number
	local cfg = config.Balance.Rebirth
	local n = math.clamp(tonumber(rebirths) or 0, 0, cfg.maxRebirths)
	return 1 + cfg.linearPerRebirth * n + cfg.quadraticPerRebirth * n * n
end

--- Coins needed for the NEXT rebirth.
function MultiplierEngine.rebirthRequirement(rebirths: number?, config: Dict): number
	local cfg = config.Balance.Rebirth
	local n = math.max(0, math.floor(tonumber(rebirths) or 0))
	return cfg.baseRequirement * (cfg.requirementGrowth ^ n)
end

--- Tokens earned for a rebirth (trading currency faucet).
function MultiplierEngine.rebirthTokenReward(rebirths: number?, config: Dict): number
	local cfg = config.Balance.Rebirth
	local n = math.max(1, math.floor((tonumber(rebirths) or 0) + 1))
	return math.floor(cfg.tokenBase * (n ^ cfg.tokenExponent))
end

-- ===========================================================================
-- 6. Enchants & relics
-- ===========================================================================

--- Power-stat enchant bonus on ONE item (Might), used as the instance's
--- `enchantPowerBonus` when a build is resolved.
function MultiplierEngine.itemPowerBonus(instance: Dict, config: Dict): number
	local total = 0
	local list = instance.enchants
	if not list then
		return 0
	end
	for _, enchant in ipairs(list) do
		local def = config.Enchants.Definitions[enchant.id]
		if def and def.stat == "power" then
			total += def.values[enchant.tier] or 0
		end
	end
	return total
end

--- Aggregate enchant stats across any list of instances (pets and/or relics).
function MultiplierEngine.enchantTotals(instances: { Dict }?, config: Dict): Dict
	local totals: Dict = { power = 0, tap = 0, coin = 0, gem = 0, luck = 0, synergy = 0, crit = 0 }
	if not instances then
		return totals
	end

	for _, instance in ipairs(instances) do
		local list = instance.enchants
		if list then
			for _, enchant in ipairs(list) do
				local def = config.Enchants.Definitions[enchant.id]
				if def then
					local value = def.values[enchant.tier]
					if value then
									if totals[def.stat] ~= nil then
						totals[def.stat] += value
					end
					end
				end
			end
		end
	end

	return totals
end

--- Combine equipped relics into a single modifier bag.
function MultiplierEngine.relicMods(relicIds: { string }?, config: Dict): Dict
	local mods: Dict = {
		tapMultiplier = 1,
		flatTap = 0,
		coinMultiplier = 1,
		gemMultiplier = 1,
		critChance = 0,
		critMultiplier = 1,
		extraHits = 0,
		overchargeEvery = 0,
		overchargeMultiplier = 1,
		autoTapRate = 0,
		synergyBonus = 0,
		petSlotBonus = 0,
		petPowerMultiplier = 1,
		count = 0,
		ids = {},
	}

	if not relicIds then
		return mods
	end

	for _, id in ipairs(relicIds) do
		local def = config.Relics[id]
		if def then
			mods.count += 1
			table.insert(mods.ids, id)

			local function apply(effects: Dict?)
				if not effects then
					return
				end
				mods.tapMultiplier *= 1 + (effects.tapMultiplier or 0)
				mods.coinMultiplier *= 1 + (effects.coinMultiplier or 0)
				mods.gemMultiplier *= 1 + (effects.gemMultiplier or 0)
				mods.petPowerMultiplier *= 1 + (effects.petPowerMultiplier or 0)
				mods.critMultiplier += effects.critMultiplier or 0
				mods.flatTap += effects.flatTap or 0
				mods.critChance += effects.critChance or 0
				mods.extraHits += effects.extraHits or 0
				mods.autoTapRate += effects.autoTapRate or 0
				mods.synergyBonus += effects.synergyBonus or 0
				mods.petSlotBonus += effects.petSlotBonus or 0
				if effects.overchargeEvery and effects.overchargeEvery > 0 then
					-- Fastest overcharge wins; two gauntlets do not double-dip.
					if mods.overchargeEvery == 0 or effects.overchargeEvery < mods.overchargeEvery then
						mods.overchargeEvery = effects.overchargeEvery
						mods.overchargeMultiplier = effects.overchargeMultiplier or 1
					elseif effects.overchargeEvery == mods.overchargeEvery then
						mods.overchargeMultiplier *= effects.overchargeMultiplier or 1
					end
				end
			end

			apply(def.effects)
			apply(def.curse)
		end
	end

	return mods
end

-- ===========================================================================
-- 7. Boosts (2x weekends, potions)
-- ===========================================================================

--- Same-type boosts ADD (capped), never multiply together.
function MultiplierEngine.boostMultiplier(boosts: { Dict }?, kind: string, config: Dict): number
	if not boosts then
		return 1
	end
	local cfg = config.Balance.Boosts
	local stacks = 0
	local total = 0
	for _, boost in ipairs(boosts) do
		if boost.kind == kind then
			stacks += 1
			total += (boost.multiplier or 1) - 1
		end
	end
	stacks = math.min(stacks, cfg.maxSameTypeStacks)
	if stacks == 0 then
		return 1
	end
	local sum = 0
	local seen = 0
	for _, boost in ipairs(boosts) do
		if boost.kind == kind and seen < stacks then
			seen += 1
			sum += (boost.multiplier or 1) - 1
		end
	end
	return 1 + sum
end

-- ===========================================================================
-- 8. The full context: every multiplier, one call
-- ===========================================================================

--[[
	state = {
	  pets            = { {id, class, variants, level, enchantPowerBonus, enchants}, ... } equipped
	  rebirths        = number,
	  tapUpgradeLevel = number,
	  relics          = { relicId, ... } equipped
	  boosts          = { {kind="tap"|"coin", multiplier=2}, ... }
	  eventMultiplier = number   (Synergy Surge applies to synergy, not here)
	  eventSynergyMultiplier = number
	  entitlements    = { vip = true, lucky = true, ... }
	  enchantTotals   = optional pre-aggregated totals (server cache)
	}
]]
function MultiplierEngine.context(state: Dict, config: Dict): Dict
	local balance = config.Balance
	local tapCfg = balance.Tap

	local pets = state.pets or {}
	local relics = MultiplierEngine.relicMods(state.relics, config)

	-- Team power, with relic pet-power buffs + curses folded in.
	local petPowerMult = relics.petPowerMultiplier
	local buffedPets = pets
	if petPowerMult ~= 1 then
		buffedPets = {}
		for _, pet in ipairs(pets) do
			local copy = table.clone(pet)
			copy.cursePowerMultiplier = (pet.cursePowerMultiplier or 0) + (petPowerMult - 1)
			table.insert(buffedPets, copy)
		end
	end
	local team = MultiplierEngine.teamPower(buffedPets, config)
	local aura = MultiplierEngine.teamAura(pets, config)

	-- Synergy (+ Harmonic enchants and Worldroot Totem).
	local enchantTotals = state.enchantTotals or MultiplierEngine.enchantTotals(pets, config)
	local synergyInfo = MultiplierEngine.synergy(pets, config)
	local synergyMult = synergyInfo.multiplier * (1 + enchantTotals.synergy + relics.synergyBonus)
	synergyMult *= (state.eventSynergyMultiplier or 1)

	-- Flat tap damage: base + upgrade + relic flat, then milestone steps.
	local upgradeLevel = math.clamp(math.floor(tonumber(state.tapUpgradeLevel) or 0), 0, tapCfg.upgrade.maxLevel)
	local upgradeFlat = upgradeLevel * tapCfg.upgrade.flatPerLevel
	local milestones = math.floor(upgradeLevel / tapCfg.upgrade.milestoneEvery)
	local milestoneMult = tapCfg.upgrade.milestoneMultiplier ^ milestones
	local flatTap = (tapCfg.baseTap + upgradeFlat + relics.flatTap) * milestoneMult

	-- Multipliers.
	local entitlements = state.entitlements or {}
	local vipCoins = if entitlements.vip then balance.Shop.vipCoinMultiplier else 1

	local multipliers: Dict = {
		pets = team.multiplier,
		aura = aura.multiplier,
		synergy = synergyMult,
		rebirth = MultiplierEngine.rebirthMultiplier(state.rebirths, config),
		enchant = 1 + enchantTotals.tap,
		relic = relics.tapMultiplier,
		boost = MultiplierEngine.boostMultiplier(state.boosts, "tap", config),
		event = state.eventMultiplier or 1,
	}

	local product = 1
	local breakdown = {}
	for name, value in pairs(multipliers) do
		product *= value
		table.insert(breakdown, { name = name, value = value })
	end
	table.sort(breakdown, function(a, b)
		return a.value > b.value
	end)

	local damagePerTap = flatTap * product

	local critChance = math.min(
		tapCfg.crit.baseChance
			+ (tonumber(state.critUpgradeLevel) or 0) * tapCfg.crit.perUpgradeLevel
			+ enchantTotals.crit
			+ relics.critChance,
		tapCfg.crit.maxChance
	)

	local coinMultiplier = (1 + enchantTotals.coin)
		* relics.coinMultiplier
		* vipCoins
		* MultiplierEngine.boostMultiplier(state.boosts, "coin", config)

	local autoTapRate = relics.autoTapRate + (if entitlements.vip then balance.Shop.vipAutoTapRate else 0)

	return {
		flatTap = flatTap,
		damagePerTap = damagePerTap,
		product = product,
		multipliers = multipliers,
		breakdown = breakdown,

		team = team,
		aura = aura,
		synergy = synergyInfo,
		relics = relics,
		enchants = enchantTotals,
		tapUpgradeLevel = upgradeLevel,
		tapMilestoneMultiplier = milestoneMult,

		critChance = critChance,
		critMultiplier = tapCfg.crit.damageMultiplier * relics.critMultiplier,
		coinsPerTap = damagePerTap * coinMultiplier,
		coinMultiplier = coinMultiplier,
		autoTapRate = autoTapRate,
		autoTapDamagePerSecond = autoTapRate * damagePerTap,
	}
end

-- ===========================================================================
-- 9. Inventory sort helpers
-- ===========================================================================

--- Per-pet contribution data used by "Sort by Tap Multiplier" and Quick Compare.
function MultiplierEngine.petContribution(pet: Dict, state: Dict, config: Dict): Dict
	local power = MultiplierEngine.petPower(pet, config)
	local synergyDelta = MultiplierEngine.marginalSynergy(pet, state.pets, config)
	local teamCfg = config.Balance.Team
	return {
		power = power,
		tapMultiplierIfAdded = 1 + power / teamCfg.petPowerScale,
		synergyDelta = synergyDelta,
		score = power * (1 + synergyDelta),
	}
end

--- Team slot count from rebirths + relics + entitlements + passes.
function MultiplierEngine.maxSlots(state: Dict, config: Dict): number
	local cfg = config.Balance
	local slots = cfg.Team.baseSlots
	local entitlements = state.entitlements or {}

	slots += (tonumber(entitlements.extraSlots) or 0)
	slots += (tonumber(entitlements.relicSlots) or 0)
	if entitlements.vip then
		slots += cfg.Shop.vipExtraSlots
	end

	local relics = MultiplierEngine.relicMods(state.relics, config)
	slots += relics.petSlotBonus

	local milestone = cfg.Rebirth.slotsPerRebirthMilestone
	local rebirths = tonumber(state.rebirths) or 0
	local granted = math.floor(rebirths / milestone.at) * milestone.slots
	slots += math.min(granted, milestone.upTo)

	return math.min(slots, cfg.Team.hardMaxSlots)
end

return MultiplierEngine
