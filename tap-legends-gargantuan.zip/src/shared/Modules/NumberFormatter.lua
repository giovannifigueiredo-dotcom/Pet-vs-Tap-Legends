--!strict
--[[
	NumberFormatter.lua
	Simulator numbers get absurd fast (1e18+). Short suffixes keep the HUD
	readable and are used identically on server (chat/logs) and client (HUD).

	Pure Luau: no Roblox APIs, unit tested.
]]

local NumberFormatter = {}

local SUFFIXES = {
	"", "K", "M", "B", "T", "Qa", "Qi", "Sx", "Sp", "Oc", "No", "Dc",
	"UDc", "DDc", "TDc", "QaDc", "QiDc", "SxDc", "SpDc", "OcDc", "NoDc", "Vg",
}

local function formatFixed(value: number, decimals: number): string
	local text = string.format("%." .. decimals .. "f", value)
	-- trim trailing zeros: 1.50 -> 1.5, 2.00 -> 2
	text = text:gsub("0+$", ""):gsub("%.$", "")
	return text
end

--- Compact number: 1234 -> "1.23K", 1.5e9 -> "1.5B".
function NumberFormatter.short(value: number, maxDecimals: number?): string
	local decimals = maxDecimals or 2
	if value ~= value then
		return "NaN"
	elseif value == math.huge then
		return "inf"
	elseif value == -math.huge then
		return "-inf"
	end

	local negative = value < 0
	local magnitude = math.abs(value)

	if magnitude < 1000 then
		-- small values keep one decimal only when they are not whole
		local text
		if magnitude == math.floor(magnitude) then
			text = string.format("%d", magnitude)
		else
			text = formatFixed(magnitude, 1)
		end
		return (negative and "-" or "") .. text
	end

	local tier = math.floor(math.log(magnitude, 1000))
	tier = math.min(tier, #SUFFIXES - 1)
	local scaled = magnitude / (1000 ^ tier)
	-- 999.999K rounds to 1000K; bump it up a tier instead.
	if scaled >= 999.995 and tier < #SUFFIXES - 1 then
		tier += 1
		scaled = magnitude / (1000 ^ tier)
	end

	local suffix = SUFFIXES[tier + 1] or ""
	return (negative and "-" or "") .. formatFixed(scaled, decimals) .. suffix
end

--- Full precision with thousands separators: 1234567 -> "1,234,567".
function NumberFormatter.full(value: number): string
	local negative = value < 0
	local text = string.format("%d", math.floor(math.abs(value)))
	local formatted = text:reverse():gsub("(%d%d%d)", "%1,"):reverse()
	formatted = formatted:gsub("^,", "")
	return (negative and "-" or "") .. formatted
end

--- Seconds -> "1h 04m", "12m 09s", "8s".
function NumberFormatter.duration(seconds: number): string
	local total = math.max(0, math.floor(seconds))
	local hours = math.floor(total / 3600)
	local minutes = math.floor((total % 3600) / 60)
	local secs = total % 60
	if hours > 0 then
		return string.format("%dh %02dm", hours, minutes)
	elseif minutes > 0 then
		return string.format("%dm %02ds", minutes, secs)
	end
	return string.format("%ds", secs)
end

--- 0.734 -> "73%" (used by pity bars, odds tooltips).
function NumberFormatter.percent(fraction: number, decimals: number?): string
	local d = decimals or 0
	return string.format("%." .. d .. "f%%", math.clamp(fraction, 0, 1) * 100)
end

--- "1 in 12,345" odds formatting for egg tooltips.
function NumberFormatter.odds(chance: number): string
	if chance <= 0 then
		return "never"
	elseif chance >= 1 then
		return "guaranteed"
	end
	return "1 in " .. NumberFormatter.full(math.floor(1 / chance + 0.5))
end

return NumberFormatter
