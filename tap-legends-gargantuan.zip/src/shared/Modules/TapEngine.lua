--!nonstrict
--[[
	TapEngine.lua
	=============
	THE TAPPING MATH + server-side rate limiting. Works on a context produced by
	MultiplierEngine.context(), so the client can predict and the server can
	authoritatively confirm with the exact same numbers.

	Crit and overcharge are resolved HERE (not in the context) because they are
	per-tap random events. The server owns the RNG; the client only receives
	the resulting numbers for its floating-damage UI.
]]

local TapEngine = {}

type Dict = { [string]: any }

-- ===========================================================================
-- 1. Rate limiter (token bucket)
-- ===========================================================================
--[[
	Why a bucket: mobile players drum their thumbs, and exploiters will spam
	RemoteEvents. A fixed 22/s clamp on every single tap feels laggy for honest
	bursts; a bucket allows a 34-tap burst then settles to 22/s sustained.
]]

local RateLimiter = {}
RateLimiter.__index = RateLimiter

function RateLimiter.new(serverCfg: Dict)
	return setmetatable({
		capacity = serverCfg.burstAllowance,
		tokens = serverCfg.burstAllowance,
		refillPerSecond = serverCfg.maxTapsPerSecond,
		-- nil, NOT 0: os.clock() can legitimately be 0 on the first tap, and a
		-- 0 sentinel would then swallow the first refill window entirely.
		last = nil,
		rejected = 0,
		accepted = 0,
	}, RateLimiter)
end

--- Consume one tap token. `now` must be a monotonic clock (os.clock()).
function RateLimiter:consume(now: number): boolean
	if self.last == nil then
		self.last = now
	end
	local elapsed = math.max(0, now - self.last)
	self.last = now

	self.tokens = math.min(self.capacity, self.tokens + elapsed * self.refillPerSecond)

	if self.tokens >= 1 then
		self.tokens -= 1
		self.accepted += 1
		return true
	end

	self.rejected += 1
	return false
end

--- Sustained taps per second currently available (for anti-cheat telemetry).
function RateLimiter:sustainedRate(): number
	return self.refillPerSecond
end

TapEngine.RateLimiter = RateLimiter

-- ===========================================================================
-- 2. Per-tap resolution
-- ===========================================================================

--[[
	resolveTap(context, tapIndex, critRoll) -> {
	  damage          damage of a single hit
	  totalDamage     damage * hits (relic extraHits strike additional targets)
	  hits            1 + relic extraHits
	  isCrit, overcharged, tapIndex
	}

	`critRoll` is a number in [0, 1) from the server RNG. Passing it in makes
	this function 100% deterministic and unit testable.
]]
function TapEngine.resolveTap(context: Dict, tapIndex: number, critRoll: number): Dict
	local damage = context.damagePerTap
	local isCrit = critRoll < context.critChance
	if isCrit then
		damage *= context.critMultiplier
	end

	local overcharged = false
	local every = context.relics and context.relics.overchargeEvery or 0
	if every > 0 and tapIndex > 0 and tapIndex % every == 0 then
		damage *= context.relics.overchargeMultiplier or 1
		overcharged = true
	end

	local hits = 1 + (context.relics and context.relics.extraHits or 0)

	return {
		damage = damage,
		totalDamage = damage * hits,
		hits = hits,
		isCrit = isCrit,
		overcharged = overcharged,
		tapIndex = tapIndex,
	}
end

--- Coins granted for a resolved tap. Coins track damage, so pets that boost
--- damage also boost income: one mental model, no hidden second currency pump.
function TapEngine.coinsForTap(resolved: Dict, context: Dict): number
	return resolved.totalDamage * context.coinMultiplier
end

--- Gems from a duplicate pet (used by EggMath/hatch flow).
function TapEngine.duplicateGems(petPower: number, balance: Dict): number
	return math.floor(balance.Economy.gemFromDuplicateBase + petPower * balance.Economy.gemFromDuplicatePerPower)
end

-- ===========================================================================
-- 3. Projections (UI + balance tooling)
-- ===========================================================================

--- DPS if the player taps `tapsPerSecond` times (crits averaged in).
function TapEngine.projectedDamagePerSecond(context: Dict, tapsPerSecond: number?): number
	local tps = tapsPerSecond or 1
	local critExpected = 1 + context.critChance * (context.critMultiplier - 1)

	local overchargeExpected = 1
	local every = context.relics and context.relics.overchargeEvery or 0
	if every > 0 then
		overchargeExpected = 1 + ((context.relics.overchargeMultiplier or 1) - 1) / every
	end

	local hits = 1 + (context.relics and context.relics.extraHits or 0)
	return context.damagePerTap * tps * critExpected * overchargeExpected * hits
end

--- Coins/sec at a given tap rate (used for upgrade-payback UI).
function TapEngine.projectedCoinsPerSecond(context: Dict, tapsPerSecond: number?): number
	return TapEngine.projectedDamagePerSecond(context, tapsPerSecond) * context.coinMultiplier
end

--- How long until the player can afford `cost` at a given income.
function TapEngine.secondsToAfford(cost: number, coinsPerSecond: number): number
	if coinsPerSecond <= 0 then
		return math.huge
	end
	return math.max(0, cost - 0) / coinsPerSecond
end

-- ===========================================================================
-- 4. Tap upgrade cost curve
-- ===========================================================================

--- Cost of the NEXT tap upgrade level.
function TapEngine.upgradeCost(level: number, balance: Dict): number
	local cfg = balance.Tap.upgrade
	return math.floor(cfg.baseCost * (cfg.costGrowth ^ math.max(0, level)))
end

--- Damage gain from buying one tap upgrade (for the UI "+X/s" preview).
function TapEngine.upgradePreview(state: Dict, context: Dict, balance: Dict): Dict
	local level = context.tapUpgradeLevel
	local cfg = balance.Tap.upgrade
	local nextLevel = math.min(level + 1, cfg.maxLevel)

	-- Flat contribution change, including milestone steps. Relic flat damage
	-- sits INSIDE the milestone multiplier, so it must be included here or the
	-- preview under-reports at levels 25/50/75...
	local relicFlat = if context.relics then (context.relics.flatTap or 0) else 0
	local function flatAt(lv: number): number
		local milestones = math.floor(lv / cfg.milestoneEvery)
		return (balance.Tap.baseTap + lv * cfg.flatPerLevel + relicFlat) * (cfg.milestoneMultiplier ^ milestones)
	end

	local delta = flatAt(nextLevel) - flatAt(level)
	local gainPerTap = delta * (context.product or 1)

	return {
		level = nextLevel,
		cost = TapEngine.upgradeCost(level, balance),
		damageGainPerTap = gainPerTap,
		damageGainPercent = if context.damagePerTap > 0 then gainPerTap / context.damagePerTap else 0,
	}
end

return TapEngine
