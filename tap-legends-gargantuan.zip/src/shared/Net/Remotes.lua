--!nonstrict
--[[
	Remotes.lua
	Single registry for every client<->server endpoint. Both sides call the same
	accessor so a typo in a name becomes a WaitForChild timeout in Studio instead
	of a silent nil at runtime.

	Server: Remotes.ensureAll()
	Client: Remotes.event("Tap") / Remotes.fn("Hatch")
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Remotes = {}

Remotes.FolderName = "GameRemotes"

-- client -> server (or server -> client broadcast) events
Remotes.EventNames = {
	"Tap", -- client tap intent (no payload trusted)
	"TapResult", -- server -> client authoritative tap result
	"StateSync", -- profile snapshot / deltas
	"Toast", -- server -> client notifications
	"InventorySync", -- pets/equipped/folders changed
	"TradeState", -- trade session updates
	"RaidState", -- boss state broadcast
	"EventState", -- hourly event broadcast
	"ShopState", -- pity bars + entitlements
}

-- request/response endpoints (server validates every argument)
Remotes.FunctionNames = {
	"Hatch",
	"EquipPets",
	"AutoEquipBest",
	"FusePets",
	"Rebirth",
	"BuyUpgrade",
	"RerollEnchant",
	"ForgeRelic",
	"EquipRelic",
	"TradeAction",
	"GetEventState",
	"GetInventoryPage",
	"SetFolder",
}

local function folder(): Folder
	local existing = ReplicatedStorage:FindFirstChild(Remotes.FolderName)
	if existing then
		return existing :: Folder
	end
	local created = Instance.new("Folder")
	created.Name = Remotes.FolderName
	created.Parent = ReplicatedStorage
	return created
end

--- Creates every remote on the SERVER. Safe to call once at boot.
function Remotes.ensureAll(): ()
	local root = folder()
	for _, name in ipairs(Remotes.EventNames) do
		if not root:FindFirstChild(name) then
			local remote = Instance.new("RemoteEvent")
			remote.Name = name
			remote.Parent = root
		end
	end
	for _, name in ipairs(Remotes.FunctionNames) do
		if not root:FindFirstChild(name) then
			local remote = Instance.new("RemoteFunction")
			remote.Name = name
			remote.Parent = root
		end
	end
end

local function getRemote(name: string, className: string): Instance
	local root = ReplicatedStorage:FindFirstChild(Remotes.FolderName)
	if not root then
		if RunService:IsServer() then
			Remotes.ensureAll()
			root = folder()
		else
			root = ReplicatedStorage:WaitForChild(Remotes.FolderName, 30)
		end
	end
	if not root then
		error("Remotes folder missing; server must call Remotes.ensureAll()")
	end
	local remote = root:WaitForChild(name, 30)
	if not remote then
		error(string.format("Remote %q (%s) not found", name, className))
	end
	return remote
end

function Remotes.event(name: string): RemoteEvent
	return getRemote(name, "RemoteEvent") :: RemoteEvent
end

function Remotes.fn(name: string): RemoteFunction
	return getRemote(name, "RemoteFunction") :: RemoteFunction
end

return Remotes
