--!nonstrict
--[[
	TapService.lua
	==============
	Server-authoritative tapping.
	- every tap is validated by a token bucket (burst + sustained rate)
	- the server owns the RNG for crits and overcharges
	- coins = damage * coin multiplier, so income follows power automatically
	- auto-tap runs on the server at a fixed step, never client-driven

	Replication strategy: the server replies to each accepted tap with
	TapResult (immediate feedback) and pushes a throttled StateSync for the HUD.
	At 20 taps/s this is ~20 small remotes/s/player, well inside budget.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(Shared.Config.GameConfig)
local TapEngine = require(Shared.Modules.TapEngine)

local TapService = {}

local ctx
local limiters: { [number]: any } = {}
local rejections: { [number]: number } = {}
local rng = Random.new()

local AUTO_STEP = 0.25 -- seconds between auto-tap batches

local function limiterFor(player: Player)
	local limiter = limiters[player.UserId]
	if not limiter then
		limiter = TapEngine.RateLimiter.new(Config.Balance.Tap.server)
		limiters[player.UserId] = limiter
	end
	return limiter
end

local function kick(player: Player, reason: string)
	limiters[player.UserId] = nil
	rejections[player.UserId] = nil
	player:Kick(reason)
end

-- ===========================================================================
-- Manual taps
-- ===========================================================================

function TapService.handleTap(player: Player)
	local profile = ctx.getProfile(player)
	if not profile then
		return
	end

	local limiter = limiterFor(player)
	if not limiter:consume(os.clock()) then
		rejections[player.UserId] = (rejections[player.UserId] or 0) + 1
		if rejections[player.UserId] >= Config.Balance.Tap.server.maxRejectedBeforeKick then
			kick(player, "Tap rate exceeded")
		end
		return
	end

	local build = ctx.services.BuildService.get(player)
	if not build then
		return
	end

	profile.stats.taps += 1
	local resolved = TapEngine.resolveTap(build, profile.stats.taps, rng:NextNumber())
	local coins = TapEngine.coinsForTap(resolved, build)

	profile.stats.damage += resolved.totalDamage
	profile.currencies.coins += coins
	ctx.touch(player)

	-- Raid + event hooks receive the authoritative damage number.
	ctx.services.RaidService.contribute(player, resolved.totalDamage)
	ctx.services.EventService.onTap(player, resolved.totalDamage)

	ctx.remotes.event("TapResult"):FireClient(player, {
		damage = resolved.damage,
		totalDamage = resolved.totalDamage,
		coins = coins,
		isCrit = resolved.isCrit,
		overcharged = resolved.overcharged,
		hits = resolved.hits,
		tapIndex = resolved.tapIndex,
		coinsTotal = profile.currencies.coins,
	})
end

-- ===========================================================================
-- Auto-tap (server originated, so it bypasses the bucket by design)
-- ===========================================================================

local autoTapSyncAccumulator = 0

function TapService.step(dt: number)
	autoTapSyncAccumulator += dt
	-- Auto-tap income is invisible to the client unless we push, so HUD syncs
	-- every 5s for auto-tappers only (cheap, and only for pass owners).
	local shouldSync = autoTapSyncAccumulator >= 5
	if shouldSync then
		autoTapSyncAccumulator = 0
	end

	for _, player in ipairs(Players:GetPlayers()) do
		local profile = ctx.getProfile(player)
		if profile then
			local build = ctx.services.BuildService.get(player)
			if build and build.autoTapRate > 0 then
				local damage = build.autoTapRate * dt * build.damagePerTap
				if damage > 0 then
					profile.stats.damage += damage
					profile.currencies.coins += damage * build.coinMultiplier
					ctx.touch(player)
					ctx.services.RaidService.contribute(player, damage)
					ctx.services.EventService.onTap(player, damage)
					if shouldSync then
						ctx.pushState(player)
					end
				end
			end
		end
	end
end

-- ===========================================================================
-- Upgrades
-- ===========================================================================

function TapService.buyUpgrade(player: Player, upgradeId: string)
	local profile = ctx.getProfile(player)
	if not profile then
		return { ok = false, reason = "noProfile" }
	end

	if upgradeId == "tap" then
		local level = profile.tapUpgradeLevel
		if level >= Config.Balance.Tap.upgrade.maxLevel then
			return { ok = false, reason = "maxLevel" }
		end
		local cost = TapEngine.upgradeCost(level, Config.Balance)
		if profile.currencies.coins < cost then
			return { ok = false, reason = "insufficientCoins", cost = cost }
		end
		profile.currencies.coins -= cost
		profile.tapUpgradeLevel += 1
	elseif upgradeId == "crit" then
		-- Crit upgrades cost gems: a second currency sink that is not gacha.
		local cost = math.floor(25 * (1.22 ^ profile.critUpgradeLevel))
		if profile.currencies.gems < cost then
			return { ok = false, reason = "insufficientGems", cost = cost }
		end
		profile.currencies.gems -= cost
		profile.critUpgradeLevel += 1
	else
		return { ok = false, reason = "unknownUpgrade" }
	end

	ctx.touch(player)
	ctx.invalidate(player)
	ctx.pushState(player)
	return { ok = true, build = ctx.services.BuildService.snapshotForClient(player) }
end

-- ===========================================================================
-- Wiring
-- ===========================================================================

function TapService.init(context): ()
	ctx = context
	ctx.remotes.event("Tap").OnServerEvent:Connect(function(player)
		TapService.handleTap(player)
	end)

	ctx.remotes.fn("BuyUpgrade").OnServerInvoke = function(player, upgradeId)
		if type(upgradeId) ~= "string" then
			return { ok = false, reason = "badRequest" }
		end
		return TapService.buyUpgrade(player, upgradeId)
	end

	-- Fixed-step loop (0.1s) driving auto-tap batches.
	task.spawn(function()
		local accumulator = 0
		while true do
			local dt = task.wait(0.1)
			accumulator += dt
			if accumulator >= AUTO_STEP then
				local elapsed = accumulator
				accumulator = 0
				local ok, err = pcall(TapService.step, elapsed)
				if not ok then
					warn("[TapService] auto-tap step failed: " .. tostring(err))
				end
			end
		end
	end)
end

function TapService.forget(player: Player)
	limiters[player.UserId] = nil
	rejections[player.UserId] = nil
end

return TapService
