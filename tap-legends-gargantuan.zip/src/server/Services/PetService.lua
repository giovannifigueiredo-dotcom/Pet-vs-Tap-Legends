--!nonstrict
--[[
	PetService.lua
	==============
	Hatching, equipping (large teams), fusing and duplicate handling.

	Duplicates: owning a second pet with the same (id, class) converts the new
	one into gems. That keeps the inventory meaningful (no 4,000 identical
	Normals) while still feeding the gem economy that pays for enchants.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Shared = ReplicatedStorage:WaitForChild("Shared")

local Config = require(Shared.Config.GameConfig)
local EggMath = require(Shared.Modules.EggMath)
local MultiplierEngine = require(Shared.Modules.MultiplierEngine)
local TapEngine = require(Shared.Modules.TapEngine)

local PetService = {}

local ctx
local rng = Random.new()

local MAX_HATCH_BATCH = 25

local function newUid(): string
	return string.format("p_%d_%04d", os.time(), rng:NextInteger(1, 9999))
end

-- ===========================================================================
-- Instances
-- ===========================================================================

function PetService.createInstance(petId: string, className: string, variants: { string }, level: number?)
	local def = Config.Pets[petId]
	if not def then
		return nil
	end
	return {
		uid = newUid(),
		id = petId,
		class = className or "Standard",
		variants = variants or {},
		level = math.clamp(level or 1, 1, Config.Balance.Team.maxPetLevel),
		enchants = {},
		locked = false,
		favorite = false,
		acquiredAt = os.time(),
	}
end

--- Does the player already own this exact pet id+class? (duplicate rule)
local function ownsCombo(profile: any, petId: string, className: string): boolean
	for _, pet in pairs(profile.pets) do
		if pet.id == petId and pet.class == className then
			return true
		end
	end
	return false
end

--- Add a pet instance, auto-equipping it if a slot is free.
function PetService.grantPet(player: Player, profile: any, instance: any): boolean
	local duplicate = ownsCombo(profile, instance.id, instance.class)
	if duplicate then
		local power = MultiplierEngine.petPower(instance, Config)
		local gems = TapEngine.duplicateGems(power, Config.Balance)
		profile.currencies.gems += gems
		profile.stats.lastDuplicateGems = gems
		return false
	end

	profile.pets[instance.uid] = instance

	local maxSlots = MultiplierEngine.maxSlots({
		rebirths = profile.rebirths,
		relics = profile.relics.equipped,
		entitlements = profile.shop.entitlements,
	}, Config)

	if #profile.equipped < maxSlots then
		table.insert(profile.equipped, instance.uid)
	end

	return true
end

function PetService.removePet(profile: any, uid: string)
	if not profile.pets[uid] then
		return false
	end
	profile.pets[uid] = nil
	for index = #profile.equipped, 1, -1 do
		if profile.equipped[index] == uid then
			table.remove(profile.equipped, index)
		end
	end
	for _, folder in pairs(profile.folders) do
		for index = #folder.petUids, 1, -1 do
			if folder.petUids[index] == uid then
				table.remove(folder.petUids, index)
			end
		end
	end
	return true
end

-- ===========================================================================
-- Hatch
-- ===========================================================================

function PetService.hatch(player: Player, eggId: string, count: number?)
	local profile = ctx.getProfile(player)
	if not profile then
		return { ok = false, reason = "noProfile" }
	end
	if type(eggId) ~= "string" then
		return { ok = false, reason = "badRequest" }
	end

	local egg = Config.Eggs[eggId]
	if not egg then
		return { ok = false, reason = "unknownEgg" } -- exclusive eggs go through ShopService
	end

	-- Egg and zone ids differ for the Shadow Realm (zone "shadow", egg
	-- "umbral"), so resolve the zone that OWNS this egg.
	local ownerZone
	for _, zone in ipairs(Config.Zones) do
		if zone.egg == eggId then
			ownerZone = zone
			break
		end
	end
	if ownerZone and not profile.zones.unlocked[ownerZone.id] then
		return { ok = false, reason = "zoneLocked", zone = ownerZone.id }
	end

	local requested = tonumber(count)
	if not requested or requested ~= requested then -- nil or NaN from a forged remote
		requested = 1
	end
	local amount = math.clamp(math.floor(requested), 1, MAX_HATCH_BATCH)
	local cost = egg.cost * amount
	local currency = egg.currency or "coins"
	if (profile.currencies[currency] or 0) < cost then
		return { ok = false, reason = "insufficientFunds", cost = cost, currency = currency }
	end

	profile.currencies[currency] -= cost
	profile.stats.hatches += amount

	-- EggMath mutates state.pity; pass the profile's live table.
	local state = { pity = profile.eggPity }
	local results = {}
	local gemsBefore = profile.currencies.gems

	-- Lucky Pass shortens the HARD pity guarantee (never changes raw odds).
	local lucky = profile.shop.entitlements.lucky == true
	local hatchOptions = {
		applyLuck = lucky,
		luck = if lucky then Config.Balance.Shop.luckyPassPityReduction else 0,
		-- Shiny Hunter doubles only the shiny roll (200% of base odds).
		shinyMultiplier = if profile.shop.entitlements.shinyHunter then 2 else 1,
	}

	for _ = 1, amount do
		local roll = EggMath.hatch(eggId, Config, state, function()
			return rng:NextNumber()
		end, hatchOptions)
		if roll.ok then
			local instance = PetService.createInstance(roll.petId, roll.className, roll.variants)
			if instance then
				local isNew = PetService.grantPet(player, profile, instance)
				table.insert(results, {
					uid = instance.uid,
					petId = instance.id,
					name = Config.Pets[roll.petId].name,
					class = instance.class,
					variants = instance.variants,
					element = roll.element,
					family = roll.family,
					isNew = isNew,
					pityTriggered = roll.pityTriggered,
				})
			end
		end
	end

	ctx.touch(player)
	ctx.invalidate(player)
	ctx.services.ShopService.pushPity(player)
	ctx.pushInventory(player)

	return {
		ok = true,
		results = results,
		gemsGained = profile.currencies.gems - gemsBefore,
		currencies = profile.currencies,
		build = ctx.services.BuildService.snapshotForClient(player),
	}
end

-- ===========================================================================
-- Equip
-- ===========================================================================

function PetService.equip(player: Player, uids: any)
	local profile = ctx.getProfile(player)
	if not profile or type(uids) ~= "table" then
		return { ok = false, reason = "badRequest" }
	end

	local maxSlots = MultiplierEngine.maxSlots({
		rebirths = profile.rebirths,
		relics = profile.relics.equipped,
		entitlements = profile.shop.entitlements,
	}, Config)

	local seen = {}
	local clean = {}
	for _, uid in ipairs(uids) do
		if type(uid) ~= "string" or seen[uid] then
			return { ok = false, reason = "badRequest" }
		end
		if not profile.pets[uid] then
			return { ok = false, reason = "notOwned", uid = uid }
		end
		if #clean >= maxSlots then
			return { ok = false, reason = "tooManyPets", maxSlots = maxSlots }
		end
		seen[uid] = true
		table.insert(clean, uid)
	end

	profile.equipped = clean
	ctx.touch(player)
	ctx.invalidate(player)
	ctx.pushInventory(player)
	return { ok = true, equipped = clean, build = ctx.services.BuildService.snapshotForClient(player) }
end

--- Pick the strongest pets that fit, respecting synergy by preferring the
--- dominant element/family of the current best pet (simple, predictable QoL).
function PetService.autoEquipBest(player: Player)
	local profile = ctx.getProfile(player)
	if not profile then
		return { ok = false, reason = "noProfile" }
	end

	local maxSlots = MultiplierEngine.maxSlots({
		rebirths = profile.rebirths,
		relics = profile.relics.equipped,
		entitlements = profile.shop.entitlements,
	}, Config)

	local candidates = {}
	for uid, pet in pairs(profile.pets) do
		table.insert(candidates, { uid = uid, power = MultiplierEngine.petPower(pet, Config), pet = pet })
	end
	table.sort(candidates, function(a, b)
		return a.power > b.power
	end)

	local chosen = {}
	for index = 1, math.min(maxSlots, #candidates) do
		table.insert(chosen, candidates[index].uid)
	end

	return PetService.equip(player, chosen)
end

-- ===========================================================================
-- Fuse (level up)
-- ===========================================================================

local FUSE_COST = 3

function PetService.fuse(player: Player, uids: any)
	local profile = ctx.getProfile(player)
	if not profile or type(uids) ~= "table" or #uids ~= FUSE_COST then
		return { ok = false, reason = "badRequest" }
	end

	local base
	for _, uid in ipairs(uids) do
		local pet = profile.pets[uid]
		if not pet then
			return { ok = false, reason = "notOwned" }
		end
		for _, equippedUid in ipairs(profile.equipped) do
			if equippedUid == uid then
				return { ok = false, reason = "petEquipped", uid = uid }
			end
		end
		if base then
			if pet.id ~= base.id or pet.class ~= base.class then
				return { ok = false, reason = "mismatch" }
			end
		else
			base = pet
		end
	end

	if base.level >= Config.Balance.Team.maxPetLevel then
		return { ok = false, reason = "maxLevel" }
	end

	for index = 2, FUSE_COST do
		PetService.removePet(profile, uids[index])
	end
	base.level += 1

	ctx.touch(player)
	ctx.invalidate(player)
	ctx.pushInventory(player)
	return { ok = true, uid = base.uid, level = base.level }
end

-- ===========================================================================
-- Wiring
-- ===========================================================================

function PetService.init(context): ()
	ctx = context

	ctx.remotes.fn("Hatch").OnServerInvoke = function(player, eggId, count)
		return PetService.hatch(player, eggId, count)
	end

	ctx.remotes.fn("EquipPets").OnServerInvoke = function(player, uids)
		return PetService.equip(player, uids)
	end

	ctx.remotes.fn("AutoEquipBest").OnServerInvoke = function(player)
		return PetService.autoEquipBest(player)
	end

	ctx.remotes.fn("FusePets").OnServerInvoke = function(player, uids)
		return PetService.fuse(player, uids)
	end
end

return PetService
