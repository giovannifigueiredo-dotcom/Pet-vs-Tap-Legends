--!nonstrict
--[[
	DataService.lua
	===============
	Session-locked profile persistence + the ONE canonical profile schema.

	Production note: this is a correct, self-contained implementation (lock,
	stale-lock recovery, autosave, BindToClose flush, schema migration). For
	launch, swapping the store calls for ProfileStore (Sleitnick) is recommended:
	it adds cross-server lock verification, retry/backoff and a battle-tested
	shutdown path. The schema below is identical either way.

	DataStores used:
	  PlayerProfiles_v1      - one key per player: "u_<userId>"
	  Leaderboard_<board>    - OrderedDataStore: rebirths / power / bossDamage
	  TradeAudit_v1          - append-only trade log (key: "t_<unix>_<id>")
	  Receipts_v1            - ProcessReceipt idempotency (key: receiptId)
]]

local DataStoreService = game:GetService("DataStoreService")
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")

local DataService = {}

local PROFILE_STORE = "PlayerProfiles_v1"
local SCHEMA_VERSION = 1
local SESSION_STALE_SECONDS = 10 * 60
local AUTOSAVE_SECONDS = 60
local LOAD_ATTEMPTS = 5

local JOB_ID = string.format("%s:%d", tostring(game.JobId ~= "" and game.JobId or "studio"), math.random(100000, 999999))

local store = DataStoreService:GetDataStore(PROFILE_STORE)
local profiles: { [Player]: any } = {}
local dirty: { [Player]: boolean } = {}
local ctx

-- ===========================================================================
-- Schema
-- ===========================================================================
--[[
	Keep this in sync with docs/DATASTORES.md. All pet references are by uid;
	`profile.equipped` is an ORDERED array because slot order is player visible.
]]
function DataService.template(userId: number)
	return {
		schemaVersion = SCHEMA_VERSION,
		userId = userId,
		createdAt = os.time(),
		lastSeen = os.time(),

		currencies = { coins = 0, gems = 0, tokens = 0, eventTokens = 0 },
		stats = { taps = 0, damage = 0, hatches = 0, playtime = 0 },

		rebirths = 0,
		tapUpgradeLevel = 0,
		critUpgradeLevel = 0,

		pets = {}, -- [uid] = { uid, id, class, variants, level, enchants, locked, favorite, acquiredAt }
		equipped = {}, -- ordered uids
		folders = {}, -- [folderId] = { name, icon, petUids = {} }

		relics = { owned = {}, equipped = {}, enchants = {}, pity = 0, forges = 0 }, -- owned[id]=count, equipped=array of ids

		eggPity = {}, -- [eggId] = [classId] = missCount
		enchantPity = { counter = 0, totalRerolls = 0 },

		zones = { unlocked = { meadow = true }, current = "meadow" },

		boss = { totalDamage = 0, kills = 0, lastRewardAt = 0 },
		trading = { totalTrades = 0, lastTradeAt = 0, hourStart = 0, tradesThisHour = 0 },

		shop = { entitlements = {}, purchases = {} },
		events = { lastRewardAt = 0, eventProgress = {}, seasonXp = 0 },
		boosts = {}, -- { kind, multiplier, expiresAt }
		settings = { music = true, sfx = true, damageNumbers = true, autoEquip = false },
	}
end

-- Recursive default merge so old profiles gain new fields without wiping data.
local function reconcile(target: any, defaults: any)
	for key, value in pairs(defaults) do
		if target[key] == nil then
			if type(value) == "table" then
				target[key] = table.clone(value)
			else
				target[key] = value
			end
		elseif type(value) == "table" and type(target[key]) == "table" then
			-- Only merge dictionaries; arrays are data and are left untouched.
			if next(value) ~= nil and #value == 0 then
				reconcile(target[key], value)
			end
		end
	end
	return target
end

function DataService.migrate(profile: any, userId: number)
	local fresh = DataService.template(userId)
	reconcile(profile, fresh)
	profile.schemaVersion = SCHEMA_VERSION
	profile.userId = userId
	return profile
end

-- ===========================================================================
-- Load / save
-- ===========================================================================

local function readRecord(userId: number)
	local key = "u_" .. tostring(userId)
	local lastError
	for attempt = 1, LOAD_ATTEMPTS do
		local ok, result = pcall(function()
			return store:GetAsync(key)
		end)
		if ok then
			return result
		end
		lastError = result
		task.wait(attempt)
	end
	warn(string.format("[DataService] load failed for %d: %s", userId, tostring(lastError)))
	return nil
end

local function isLockedByOther(record: any): boolean
	if not record or not record.session then
		return false
	end
	local session = record.session
	if session.jobId == JOB_ID then
		return false
	end
	return (os.time() - (session.lockedAt or 0)) < SESSION_STALE_SECONDS
end

local function waitForLock(userId: number): any
	local record = readRecord(userId)
	local attempts = 0
	while isLockedByOther(record) and attempts < LOAD_ATTEMPTS do
		attempts += 1
		task.wait(2)
		record = readRecord(userId)
	end
	return record
end

function DataService.load(player: Player): any?
	local userId = player.UserId
	local record = waitForLock(userId)

	local data
	if record and record.profile then
		data = record.profile
	else
		data = DataService.template(userId)
	end

	local profile = DataService.migrate(data, userId)
	profile.lastSeen = os.time()

	profiles[player] = profile
	dirty[player] = true
	return profile
end

function DataService.get(player: Player): any?
	return profiles[player]
end

function DataService.touch(player: Player): ()
	dirty[player] = true
end

function DataService.save(player: Player, force: boolean?): boolean
	local profile = profiles[player]
	if not profile then
		return false
	end
	if not force and not dirty[player] then
		return true
	end

	profile.lastSeen = os.time()
	local key = "u_" .. tostring(player.UserId)
	local record = {
		profile = profile,
		session = { jobId = JOB_ID, lockedAt = os.time() },
	}

	local ok, err = pcall(function()
		store:UpdateAsync(key, function(old)
			if isLockedByOther(old) then
				return nil -- never clobber another live server
			end
			return record
		end)
	end)

	if ok then
		dirty[player] = false
		DataService.publishLeaderboards(player, profile)
	else
		warn(string.format("[DataService] save failed for %s: %s", player.Name, tostring(err)))
	end
	return ok
end

function DataService.release(player: Player): ()
	local profile = profiles[player]
	if not profile then
		return
	end
	DataService.save(player, true)

	local key = "u_" .. tostring(player.UserId)
	pcall(function()
		store:UpdateAsync(key, function(old)
			if old and old.session and old.session.jobId == JOB_ID then
				old.session = nil
				return old
			end
			return nil
		end)
	end)

	profiles[player] = nil
	dirty[player] = nil
end

-- ===========================================================================
-- Leaderboards (OrderedDataStore)
-- ===========================================================================

local leaderboards = {
	rebirths = DataStoreService:GetOrderedDataStore("Leaderboard_Rebirths_v1"),
	power = DataStoreService:GetOrderedDataStore("Leaderboard_Power_v1"),
	bossDamage = DataStoreService:GetOrderedDataStore("Leaderboard_BossDamage_v1"),
}

function DataService.publishLeaderboards(player: Player, profile: any): ()
	-- One write per board per save; DataStore budgets allow this at our
	-- autosave rate. Values are ints (OrderedDataStore requirement).
	local power = ctx and ctx.services.BuildService and ctx.services.BuildService.get(player)
	local values = {
		rebirths = math.floor(profile.rebirths or 0),
		power = math.floor(if power then power.damagePerTap * 100 else 0),
		bossDamage = math.floor(profile.boss and profile.boss.totalDamage or 0),
	}
	for board, value in pairs(values) do
		local ok = pcall(function()
			leaderboards[board]:SetAsync(tostring(player.UserId), value)
		end)
		if not ok then
			-- Silent: leaderboards are cosmetic, never worth failing a save.
		end
	end
end

function DataService.top(boardName: string, count: number): { any }
	local board = leaderboards[boardName]
	if not board then
		return {}
	end
	local ok, pages = pcall(function()
		return board:GetSortedAsync(false, math.clamp(count, 1, 100))
	end)
	if not ok or not pages then
		return {}
	end
	return pages:GetCurrentPage()
end

-- ===========================================================================
-- Audit + receipts
-- ===========================================================================

local auditStore = DataStoreService:GetDataStore("TradeAudit_v1")
local receiptStore = DataStoreService:GetDataStore("Receipts_v1")

function DataService.logTrade(entry: any): ()
	entry.at = os.time()
	local key = string.format("t_%d_%d", entry.at, math.random(1, 1e6))
	pcall(function()
		auditStore:SetAsync(key, entry)
	end)
end

function DataService.hasReceipt(userId: number, receiptId: string): boolean
	local ok, value = pcall(function()
		return receiptStore:GetAsync(tostring(userId) .. "_" .. receiptId)
	end)
	return ok and value == true
end

function DataService.recordReceipt(userId: number, receiptId: string): ()
	pcall(function()
		receiptStore:SetAsync(tostring(userId) .. "_" .. receiptId, true)
	end)
end

-- ===========================================================================
-- Lifecycle
-- ===========================================================================

local function onPlayerAdded(player: Player)
	local profile = DataService.load(player)
	if not profile then
		player:Kick("Your data could not be loaded. Please rejoin.")
		return
	end

	-- Session bookkeeping
	profile.stats.sessionStart = os.time()

	if ctx then
		ctx.onProfileLoaded(player, profile)
	end

	player.CharacterAdded:Connect(function(character)
		local humanoid = character:WaitForChild("Humanoid")
		humanoid.Died:Connect(function()
			-- no death penalty; taps continue after respawn
		end)
	end)
end

local function onPlayerRemoving(player: Player)
	if ctx then
		ctx.onProfileReleasing(player)
	end
	DataService.release(player)
end

function DataService.init(context): ()
	ctx = context

	Players.PlayerAdded:Connect(onPlayerAdded)
	Players.PlayerRemoving:Connect(onPlayerRemoving)

	for _, player in ipairs(Players:GetPlayers()) do
		task.spawn(onPlayerAdded, player)
	end

	-- Staggered autosave: spreads writes across the minute to stay inside
	-- DataStore request budgets even with 50 players.
	task.spawn(function()
		while true do
			task.wait(AUTOSAVE_SECONDS)
			local index = 0
			for player in pairs(profiles) do
				index += 1
				task.delay(index * 0.1, function()
					DataService.save(player)
				end)
			end
		end
	end)

	game:BindToClose(function()
		local pending = 0
		for player in pairs(profiles) do
			pending += 1
			task.spawn(function()
				DataService.save(player, true)
			end)
		end
		-- BindToClose gets 30s; give writes time to flush.
		local waited = 0
		while pending > 0 and waited < 25 do
			task.wait(0.1)
			waited += 0.1
			pending = 0
			for _ in pairs(profiles) do
				pending += 1
			end
		end
	end)
end

return DataService
