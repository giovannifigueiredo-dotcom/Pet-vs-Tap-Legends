--!nonstrict
--[[
	RelicService.lua
	================
	Relics change tap BEHAVIOUR (AoE burst, auto-tap frenzy, crit builds). They
	are forged in the Shadow Realm with tokens + gems and equipped into slots
	unlocked by rebirth milestones (1 free, 2 at R5, 3 at R12, 4 at R25).

	Duplicates: a relic is unique per player. Forging a duplicate refunds its
	forge cost in tokens (never a dead pull).
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Shared = ReplicatedStorage:WaitForChild("Shared")

local Config = require(Shared.Config.GameConfig)
local EggMath = require(Shared.Modules.EggMath)

local RelicService = {}

local ctx
local rng = Random.new()

local function pick(options: { any })
	return EggMath.weightedPick(options, function()
		return rng:NextNumber()
	end)
end

-- ===========================================================================
-- Slots
-- ===========================================================================

function RelicService.slotCount(profile: any): number
	local milestones = Config.Balance.Rebirth.relicSlotRebirths
	local slots = 0
	for _, requirement in ipairs(milestones) do
		if profile.rebirths >= requirement then
			slots += 1
		end
	end
	return slots
end

-- ===========================================================================
-- Forge
-- ===========================================================================

local function tierOptions()
	local options = {}
	for id, def in pairs(Config.RelicsModule.Tiers) do
		table.insert(options, { tier = id, weight = def.weight, order = def.order })
	end
	return options
end

local function relicsOfTier(tier: string): { string }
	local list = {}
	for id, def in pairs(Config.Relics) do
		if def.tier == tier then
			table.insert(list, id)
		end
	end
	return list
end

function RelicService.forgeCost(profile: any): any
	local forging = Config.RelicsModule.Forging
	local forges = profile.relics.forges or 0
	return {
		tokens = math.floor(forging.baseTokenCost * (forging.costGrowth ^ forges)),
		gems = math.floor(forging.baseGemCost * (forging.gemCostGrowth ^ forges)),
	}
end

function RelicService.forge(player: Player)
	local profile = ctx.getProfile(player)
	if not profile then
		return { ok = false, reason = "noProfile" }
	end

	local cost = RelicService.forgeCost(profile)
	if profile.currencies.tokens < cost.tokens or profile.currencies.gems < cost.gems then
		return { ok = false, reason = "insufficientFunds", cost = cost, currencies = profile.currencies }
	end

	profile.currencies.tokens -= cost.tokens
	profile.currencies.gems -= cost.gems
	profile.relics.forges = (profile.relics.forges or 0) + 1

	-- Pity: 25 forges without an Epic+ guarantees one.
	local forging = Config.RelicsModule.Forging
	local duePity = (profile.relics.pity or 0) + 1 >= forging.pity.epicPlus

	local tierEntry = pick(tierOptions())
	local tier = tierEntry.tier
	if duePity and tierEntry.order < 4 then
		tier = "Epic"
	end

	local candidates = relicsOfTier(tier)
	if #candidates == 0 then
		tier = "Rare"
		candidates = relicsOfTier(tier)
	end
	local relicId = candidates[rng:NextInteger(1, #candidates)]

	local duplicate = (profile.relics.owned[relicId] or 0) > 0
	local refund = 0
	if duplicate then
		refund = math.floor(cost.tokens * 0.5)
		profile.currencies.tokens += refund
	else
		profile.relics.owned[relicId] = 1
	end

	local tierOrder = Config.RelicsModule.Tiers[tier].order
	if tierOrder >= 4 then
		profile.relics.pity = 0
	else
		profile.relics.pity = (profile.relics.pity or 0) + 1
	end

	ctx.touch(player)
	ctx.invalidate(player)
	ctx.pushState(player)

	return {
		ok = true,
		relicId = relicId,
		tier = tier,
		duplicate = duplicate,
		refund = refund,
		pityTriggered = duePity,
		currencies = profile.currencies,
		cost = cost,
		slots = RelicService.slotCount(profile),
	}
end

-- ===========================================================================
-- Equip
-- ===========================================================================

function RelicService.equip(player: Player, relicId: string, slot: number?)
	local profile = ctx.getProfile(player)
	if not profile then
		return { ok = false, reason = "noProfile" }
	end
	if (profile.relics.owned[relicId] or 0) <= 0 then
		return { ok = false, reason = "notOwned" }
	end
	for _, equipped in ipairs(profile.relics.equipped) do
		if equipped == relicId then
			return { ok = false, reason = "alreadyEquipped" }
		end
	end

	local maxSlots = RelicService.slotCount(profile)
	if #profile.relics.equipped >= maxSlots then
		if not slot then
			return { ok = false, reason = "noFreeSlot", slots = maxSlots }
		end
		-- Replace the requested slot (1-based).
		if slot < 1 or slot > maxSlots then
			return { ok = false, reason = "badSlot" }
		end
		profile.relics.equipped[slot] = relicId
	else
		table.insert(profile.relics.equipped, relicId)
	end

	ctx.touch(player)
	ctx.invalidate(player)
	ctx.pushState(player)
	return { ok = true, equipped = profile.relics.equipped, build = ctx.services.BuildService.snapshotForClient(player) }
end

function RelicService.unequip(player: Player, relicId: string)
	local profile = ctx.getProfile(player)
	if not profile then
		return { ok = false, reason = "noProfile" }
	end
	for index = #profile.relics.equipped, 1, -1 do
		if profile.relics.equipped[index] == relicId then
			table.remove(profile.relics.equipped, index)
			ctx.touch(player)
			ctx.invalidate(player)
			ctx.pushState(player)
			return { ok = true, equipped = profile.relics.equipped }
		end
	end
	return { ok = false, reason = "notEquipped" }
end

function RelicService.init(context): ()
	ctx = context

	ctx.remotes.fn("ForgeRelic").OnServerInvoke = function(player)
		return RelicService.forge(player)
	end

	ctx.remotes.fn("EquipRelic").OnServerInvoke = function(player, relicId, slot)
		if type(relicId) ~= "string" then
			return { ok = false, reason = "badRequest" }
		end
		if relicId == "" then
			return { ok = false, reason = "badRequest" }
		end
		-- Toggle: equipping an equipped relic unequips it (client convenience).
		local profile = ctx.getProfile(player)
		if profile then
			for _, equipped in ipairs(profile.relics.equipped) do
				if equipped == relicId then
					return RelicService.unequip(player, relicId)
				end
			end
		end
		return RelicService.equip(player, relicId, type(slot) == "number" and slot or nil)
	end
end

return RelicService
