--!nonstrict
--[[
	BuildService.lua
	================
	Caches one MultiplierEngine context per player. Rebuilding on every tap
	would run synergy/team math 20+ times a second per player, so services call
	`BuildService.invalidate(player)` whenever something that affects power
	changes (equip, hatch, enchant, relic, rebirth, upgrade, boost, purchase).

	The context is PURE DATA: safe to serialise to the client for prediction.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Shared = ReplicatedStorage:WaitForChild("Shared")

local MultiplierEngine = require(Shared.Modules.MultiplierEngine)
local TapEngine = require(Shared.Modules.TapEngine)

local BuildService = {}

local ctx
local cache: { [number]: any } = {}

function BuildService.init(context): ()
	ctx = context
	cache = {}
end

function BuildService.invalidate(player: Player): ()
	cache[player.UserId] = nil
end

function BuildService.invalidateAll(): ()
	cache = {}
end

--- Drop expired boosts so they never inflate a build.
local function activeBoosts(profile: any): { any }
	local now = os.time()
	local active = {}
	for _, boost in ipairs(profile.boosts or {}) do
		if (boost.expiresAt or 0) > now then
			table.insert(active, boost)
		end
	end
	return active
end

--- Build the context for a player from their profile. Cached.
function BuildService.get(player: Player): any?
	local cached = cache[player.UserId]
	if cached then
		return cached
	end

	local profile = ctx.getProfile(player)
	if not profile then
		return nil
	end

	local config = ctx.config

	-- Equipped pets, with per-item enchants resolved to instance fields.
	local equippedPets = {}
	for _, uid in ipairs(profile.equipped or {}) do
		local pet = profile.pets[uid]
		if pet then
			local instance = table.clone(pet)
			instance.enchantPowerBonus = MultiplierEngine.itemPowerBonus(pet, config)
			instance.enchants = pet.enchants
			table.insert(equippedPets, instance)
		end
	end

	-- Relic enchants live beside the relic (keyed by relic id).
	local enchantSources = {}
	for _, pet in ipairs(equippedPets) do
		table.insert(enchantSources, pet)
	end
	for _, relicId in ipairs(profile.relics.equipped or {}) do
		table.insert(enchantSources, { enchants = profile.relics.enchants[relicId] or {} })
	end

	local state = {
		pets = equippedPets,
		rebirths = profile.rebirths,
		tapUpgradeLevel = profile.tapUpgradeLevel,
		critUpgradeLevel = profile.critUpgradeLevel,
		relics = profile.relics.equipped,
		boosts = activeBoosts(profile),
		entitlements = profile.shop.entitlements,
		eventSynergyMultiplier = ctx.synergySurge or 1,
		enchantTotals = MultiplierEngine.enchantTotals(enchantSources, config),
	}

	local built = MultiplierEngine.context(state, config)
	built.maxSlots = MultiplierEngine.maxSlots({
		rebirths = profile.rebirths,
		relics = profile.relics.equipped,
		entitlements = profile.shop.entitlements,
	}, config)
	built.synergyInfo = built.synergy
	built.upgradeCost = TapEngine.upgradeCost(profile.tapUpgradeLevel, config.Balance)
	built.rebirthRequirement = MultiplierEngine.rebirthRequirement(profile.rebirths, config)

	cache[player.UserId] = built
	return built
end

--- Everything the client needs for prediction + HUD, without secrets.
function BuildService.snapshotForClient(player: Player): any?
	local built = BuildService.get(player)
	if not built then
		return nil
	end
	return {
		damagePerTap = built.damagePerTap,
		flatTap = built.flatTap,
		product = built.product,
		multipliers = built.multipliers,
		critChance = built.critChance,
		critMultiplier = built.critMultiplier,
		coinsPerTap = built.coinsPerTap,
		coinMultiplier = built.coinMultiplier,
		autoTapRate = built.autoTapRate,
		teamPower = built.team.raw,
		effectiveTeamPower = built.team.effective,
		synergy = {
			multiplier = built.synergy.multiplier,
			element = built.synergy.dominantElement,
			family = built.synergy.dominantFamily,
			elementMultiplier = built.synergy.element.multiplier,
			familyMultiplier = built.synergy.family.multiplier,
		},
		maxSlots = built.maxSlots,
	}
end

return BuildService
