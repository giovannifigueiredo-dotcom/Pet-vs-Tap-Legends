--!nonstrict
--[[
	TradeService.lua
	================
	Player-to-player trading with Tokens as the high-tier currency.

	Safety model (this is where simulator economies die):
	1. ESCROW - offers reference owned uids; nothing moves until both confirm.
	2. DOUBLE CONFIRM - changing an offer clears both confirmations.
	3. VALUE BAND - if the two sides differ by more than tradeValueBand, the
	   first confirm only triggers a warning; a second confirm is required.
	4. TOKEN TAX - 5% of traded Tokens is burned (sink, fights inflation).
	5. REVALIDATION - balances/ownership are re-checked at execute time, so a
	   pet enchanted/traded away mid-session cannot duplicate.
	6. AUDIT - every completed trade is written to TradeAudit_v1.
	7. RATE LIMITS - cooldown + hourly cap per player.

	Tokens are only earnable in game (rebirths, raids, events), never bought
	with Robux, which is the main anti-RMT dam.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(Shared.Config.GameConfig)
local MultiplierEngine = require(Shared.Modules.MultiplierEngine)

local TradeService = {}

local ctx
local sessions: { [number]: any } = {} -- [userId] = session
local invites: { [number]: number } = {} -- [inviteeUserId] = inviterUserId

local MAX_TRADE_PETS = 50
local SESSION_TIMEOUT = 120

local function emptyOffer()
	return { pets = {}, coins = 0, gems = 0, tokens = 0 }
end

local function otherUser(session: any, userId: number): number
	return if session.a == userId then session.b else session.a
end

local function profileOf(userId: number)
	local player = Players:GetPlayerByUserId(userId)
	if not player then
		return nil, nil
	end
	return ctx.getProfile(player), player
end

-- ===========================================================================
-- Valuation (for the anti-scam warning only; players still decide)
-- ===========================================================================

local VALUE = { coin = 1, gem = 10, token = 500 }

local function offerValue(userId: number, offer: any): number
	local profile = profileOf(userId)
	local value = offer.coins * VALUE.coin + offer.gems * VALUE.gem + offer.tokens * VALUE.token
	for _, uid in ipairs(offer.pets) do
		local pet = profile and profile.pets[uid]
		if pet then
			value += MultiplierEngine.petPower(pet, Config) * 2
		end
	end
	return value
end

-- ===========================================================================
-- Snapshots
-- ===========================================================================

function TradeService.snapshot(session: any, viewerId: number): any
	local myOffer = session.offers[viewerId]
	local theirId = otherUser(session, viewerId)
	local theirOffer = session.offers[theirId]
	local theirProfile, theirPlayer = profileOf(theirId)

	local function decorate(offer: any, ownerProfile: any): any
		local pets = {}
		for _, uid in ipairs(offer.pets) do
			local pet = ownerProfile and ownerProfile.pets[uid]
			if pet then
				local def = Config.Pets[pet.id]
				table.insert(pets, {
					uid = uid,
					id = pet.id,
					name = if def then def.name else pet.id,
					class = pet.class,
					variants = pet.variants,
					level = pet.level,
					enchants = pet.enchants,
					power = MultiplierEngine.petPower(pet, Config),
				})
			end
		end
		return { pets = pets, coins = offer.coins, gems = offer.gems, tokens = offer.tokens }
	end

	local myProfile = profileOf(viewerId)

	return {
		phase = session.phase,
		otherUserId = theirId,
		otherName = theirPlayer and theirPlayer.Name or "",
		myOffer = decorate(myOffer, myProfile),
		theirOffer = decorate(theirOffer, theirProfile),
		myValue = offerValue(viewerId, myOffer),
		theirValue = offerValue(theirId, theirOffer),
		myConfirmed = session.confirmed[viewerId] == true,
		theirConfirmed = session.confirmed[theirId] == true,
		valueWarning = session.valueWarning,
	}
end

local function broadcast(session: any)
	for _, userId in ipairs({ session.a, session.b }) do
		local _, player = profileOf(userId)
		if player then
			ctx.remotes.event("TradeState"):FireClient(player, TradeService.snapshot(session, userId))
		end
	end
end

-- ===========================================================================
-- Session lifecycle
-- ===========================================================================

local function startSession(userA: number, userB: number)
	local session = {
		a = userA,
		b = userB,
		offers = { [userA] = emptyOffer(), [userB] = emptyOffer() },
		confirmed = {},
		phase = "open",
		startedAt = os.time(),
		lastActionAt = os.time(),
		valueWarning = false,
	}
	sessions[userA] = session
	sessions[userB] = session
	return session
end

function TradeService.close(session: any, reason: string?)
	sessions[session.a] = nil
	sessions[session.b] = nil
	invites[session.a] = nil
	invites[session.b] = nil
	for _, userId in ipairs({ session.a, session.b }) do
		local _, player = profileOf(userId)
		if player then
			ctx.remotes.event("TradeState"):FireClient(player, { phase = "closed", reason = reason })
		end
	end
end

function TradeService.cancelFor(player: Player)
	local session = sessions[player.UserId]
	if session then
		TradeService.close(session, "leave")
	end
	invites[player.UserId] = nil
	for userId, inviter in pairs(invites) do
		if inviter == player.UserId then
			invites[userId] = nil
		end
	end
end

-- ===========================================================================
-- Actions
-- ===========================================================================

local function validateOfferPets(profile: any, petUids: any): (boolean, string?, any)
	if type(petUids) ~= "table" then
		return false, "badRequest"
	end
	if #petUids > MAX_TRADE_PETS then
		return false, "tooManyPets"
	end

	local seen = {}
	for _, uid in ipairs(petUids) do
		if type(uid) ~= "string" or seen[uid] then
			return false, "badRequest"
		end
		seen[uid] = true
		local pet = profile.pets[uid]
		if not pet then
			return false, "notOwned"
		end
		if pet.locked then
			return false, "petLocked"
		end
		for _, equippedUid in ipairs(profile.equipped) do
			if equippedUid == uid then
				return false, "petEquipped"
			end
		end
	end
	return true
end

function TradeService.setOffer(player: Player, payload: any)
	local session = sessions[player.UserId]
	if not session or session.phase ~= "open" then
		return { ok = false, reason = "noSession" }
	end
	local profile = ctx.getProfile(player)
	if not profile or type(payload) ~= "table" then
		return { ok = false, reason = "badRequest" }
	end

	local pets = payload.pets or {}
	local ok, reason = validateOfferPets(profile, pets)
	if not ok then
		return { ok = false, reason = reason }
	end

	local coins = math.clamp(math.floor(tonumber(payload.coins) or 0), 0, profile.currencies.coins)
	local gems = math.clamp(math.floor(tonumber(payload.gems) or 0), 0, profile.currencies.gems)
	local tokens = math.clamp(math.floor(tonumber(payload.tokens) or 0), 0, profile.currencies.tokens)

	session.offers[player.UserId] = { pets = pets, coins = coins, gems = gems, tokens = tokens }
	-- Any offer change invalidates BOTH confirmations: the classic scam vector.
	session.confirmed = {}
	session.valueWarning = false
	session.lastActionAt = os.time()

	broadcast(session)
	return { ok = true }
end

function TradeService.confirm(player: Player)
	local session = sessions[player.UserId]
	if not session or session.phase ~= "open" then
		return { ok = false, reason = "noSession" }
	end

	local mine = offerValue(player.UserId, session.offers[player.UserId])
	local theirs = offerValue(otherUser(session, player.UserId), session.offers[otherUser(session, player.UserId)])

	-- Value band warning: first confirm is blocked, second confirm proceeds.
	local band = Config.Balance.Economy.tradeValueBand
	local bigger = math.max(mine, theirs)
	if bigger > 0 and math.abs(mine - theirs) / bigger > band and not session.valueWarning then
		session.valueWarning = true
		broadcast(session)
		ctx.remotes.event("Toast"):FireClient(player, {
			title = "Unbalanced trade",
			body = string.format("Your side: %d | Their side: %d. Confirm again to accept.", mine, theirs),
			kind = "warning",
		})
		return { ok = false, reason = "valueWarning", mine = mine, theirs = theirs }
	end

	session.confirmed[player.UserId] = true
	session.lastActionAt = os.time()

	if session.confirmed[session.a] and session.confirmed[session.b] then
		local result = TradeService.execute(session)
		return result
	end

	broadcast(session)
	return { ok = true, waiting = true }
end

-- ===========================================================================
-- Execute (atomic swap)
-- ===========================================================================

local function transferPets(fromProfile: any, toProfile: any, petUids: { string }): { any }
	local moved = {}
	for _, uid in ipairs(petUids) do
		local pet = fromProfile.pets[uid]
		if pet then
			fromProfile.pets[uid] = nil
			for index = #fromProfile.equipped, 1, -1 do
				if fromProfile.equipped[index] == uid then
					table.remove(fromProfile.equipped, index)
				end
			end
			for _, folder in pairs(fromProfile.folders) do
				for index = #folder.petUids, 1, -1 do
					if folder.petUids[index] == uid then
						table.remove(folder.petUids, index)
					end
				end
			end
			-- New uid on arrival: uids are per-owner and must stay unique.
			local newUid = string.format("t_%d_%d", os.time(), math.random(1, 1e6))
			local copy = table.clone(pet)
			copy.uid = newUid
			copy.acquiredAt = os.time()
			toProfile.pets[newUid] = copy
			table.insert(moved, newUid)
		end
	end
	return moved
end

function TradeService.execute(session: any)
	local profileA, playerA = profileOf(session.a)
	local profileB, playerB = profileOf(session.b)
	if not profileA or not profileB or not playerA or not playerB then
		TradeService.close(session, "playerLeft")
		return { ok = false, reason = "playerLeft" }
	end

	-- RATE LIMITS
	local now = os.time()
	for _, profile in ipairs({ profileA, profileB }) do
		local trading = profile.trading
		if now - trading.lastTradeAt < Config.Balance.Economy.tradeCooldownSeconds then
			TradeService.close(session, "cooldown")
			return { ok = false, reason = "cooldown" }
		end
		if now - (trading.hourStart or 0) > 3600 then
			trading.hourStart = now
			trading.tradesThisHour = 0
		end
		if (trading.tradesThisHour or 0) >= Config.Balance.Economy.maxTradesPerHour then
			TradeService.close(session, "hourlyLimit")
			return { ok = false, reason = "hourlyLimit" }
		end
	end

	local offerA = session.offers[session.a]
	local offerB = session.offers[session.b]

	-- REVALIDATE (ownership + balances can change mid-session)
	local okA, reasonA = validateOfferPets(profileA, offerA.pets)
	if not okA then
		TradeService.close(session, reasonA)
		return { ok = false, reason = reasonA }
	end
	local okB, reasonB = validateOfferPets(profileB, offerB.pets)
	if not okB then
		TradeService.close(session, reasonB)
		return { ok = false, reason = reasonB }
	end
	if profileA.currencies.coins < offerA.coins
		or profileA.currencies.gems < offerA.gems
		or profileA.currencies.tokens < offerA.tokens
		or profileB.currencies.coins < offerB.coins
		or profileB.currencies.gems < offerB.gems
		or profileB.currencies.tokens < offerB.tokens
	then
		TradeService.close(session, "insufficientFunds")
		return { ok = false, reason = "insufficientFunds" }
	end

	-- Pause phase so neither side can mutate the offer mid-swap.
	session.phase = "executing"

	transferPets(profileA, profileB, offerA.pets)
	transferPets(profileB, profileA, offerB.pets)

	local function moveCurrency(from: any, to: any, offer: any): number
		from.coins -= offer.coins
		from.gems -= offer.gems
		from.tokens -= offer.tokens

		to.coins += offer.coins
		to.gems += offer.gems
		to.tokens += offer.tokens

		-- Token tax is burned, not transferred.
		local tax = math.floor(offer.tokens * Config.Balance.Economy.tradeTaxPercent)
		if tax > 0 then
			to.tokens -= tax
		end
		return tax
	end

	local taxB = moveCurrency(profileB, profileA, offerB)
	local taxA = moveCurrency(profileA, profileB, offerA)

	for _, profile in ipairs({ profileA, profileB }) do
		profile.trading.totalTrades += 1
		profile.trading.lastTradeAt = now
		profile.trading.tradesThisHour = (profile.trading.tradesThisHour or 0) + 1
	end

	ctx.services.DataService.logTrade({
		type = "trade",
		a = session.a,
		b = session.b,
		offerA = { pets = offerA.pets, coins = offerA.coins, gems = offerA.gems, tokens = offerA.tokens },
		offerB = { pets = offerB.pets, coins = offerB.coins, gems = offerB.gems, tokens = offerB.tokens },
		taxBurned = taxA + taxB,
	})

	for _, player in ipairs({ playerA, playerB }) do
		ctx.touch(player)
		ctx.invalidate(player)
		ctx.services.DataService.save(player, true)
		ctx.pushState(player)
		ctx.pushInventory(player)
	end

	TradeService.close(session, "completed")

	for _, player in ipairs({ playerA, playerB }) do
		ctx.remotes.event("Toast"):FireClient(player, { title = "Trade complete", body = "Items and currency swapped.", kind = "success" })
	end

	return { ok = true, completed = true }
end

-- ===========================================================================
-- Invites + dispatch
-- ===========================================================================

function TradeService.invite(player: Player, targetUserId: number)
	if type(targetUserId) ~= "number" or targetUserId == player.UserId then
		return { ok = false, reason = "badTarget" }
	end
	if sessions[player.UserId] then
		return { ok = false, reason = "alreadyTrading" }
	end

	local target = Players:GetPlayerByUserId(targetUserId)
	if not target then
		return { ok = false, reason = "notInServer" }
	end
	if sessions[targetUserId] then
		return { ok = false, reason = "targetBusy" }
	end

	invites[targetUserId] = player.UserId
	ctx.remotes.event("TradeState"):FireClient(target, {
		phase = "invite",
		fromUserId = player.UserId,
		fromName = player.Name,
	})

	return { ok = true, invited = targetUserId }
end

function TradeService.accept(player: Player)
	local inviterId = invites[player.UserId]
	if not inviterId then
		return { ok = false, reason = "noInvite" }
	end
	local inviter = Players:GetPlayerByUserId(inviterId)
	if not inviter then
		invites[player.UserId] = nil
		return { ok = false, reason = "notInServer" }
	end
	if sessions[player.UserId] or sessions[inviterId] then
		return { ok = false, reason = "alreadyTrading" }
	end

	invites[player.UserId] = nil
	local session = startSession(inviterId, player.UserId)
	broadcast(session)
	return { ok = true }
end

function TradeService.handleAction(player: Player, action: string, payload: any)
	if action == "invite" then
		return TradeService.invite(player, tonumber(payload))
	elseif action == "accept" then
		return TradeService.accept(player)
	elseif action == "setOffer" then
		return TradeService.setOffer(player, payload)
	elseif action == "confirm" then
		return TradeService.confirm(player)
	elseif action == "cancel" then
		local session = sessions[player.UserId]
		if session then
			TradeService.close(session, "cancelled")
		end
		return { ok = true }
	end
	return { ok = false, reason = "unknownAction" }
end

-- ===========================================================================
-- Wiring
-- ===========================================================================

function TradeService.step(dt: number)
	local now = os.time()
	for _, session in pairs(sessions) do
		if session.phase == "open" and now - session.lastActionAt > SESSION_TIMEOUT then
			TradeService.close(session, "timeout")
		end
	end
	-- Expire stale invites after 60s.
	for userId, _ in pairs(invites) do
		if not sessions[userId] and not Players:GetPlayerByUserId(userId) then
			invites[userId] = nil
		end
	end
end

function TradeService.init(context): ()
	ctx = context

	ctx.remotes.fn("TradeAction").OnServerInvoke = function(player, action, payload)
		if type(action) ~= "string" then
			return { ok = false, reason = "badRequest" }
		end
		return TradeService.handleAction(player, action, payload)
	end

	Players.PlayerRemoving:Connect(function(player)
		local session = sessions[player.UserId]
		if session then
			TradeService.close(session, "playerLeft")
		end
	end)
end

return TradeService
