--!nonstrict
--[[
	EventService.lua
	================
	Hourly server events on a fixed rotation:
	  :00 LuckyBlock   - smash lucky blocks, coin/gem burst
	  :00 CoinArcade   - pets are launched at targets, coin heavy
	  :00 MeteorShower - falling meteors, gem heavy
	  :00 SynergySurge - all Synergy multipliers doubled for the window

	Every event is driven by the SAME authoritative damage number that taps and
	raids use, so there is no separate exploit surface: "shooting pets" is the
	server converting damage into event progress. Rewards are distributed at the
	end by damage share, with a participation floor.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(Shared.Config.GameConfig)
local NumberFormatter = require(Shared.Modules.NumberFormatter)

local EventService = {}

local ctx
local current: any? = nil -- { name, phase, startsAt, endsAt, damage = {[userId]=n}, totalDamage }
local nextEventAt = 0
local rotationIndex = 0

local PHASE_IDLE = "idle"
local PHASE_WARNING = "warning"
local PHASE_ACTIVE = "active"

local function round(value: number): number
	return math.floor(value + 0.5)
end

local function broadcast()
	ctx.remotes.event("EventState"):FireAllClients(EventService.getState())
end

function EventService.getState()
	if not current then
		return { phase = PHASE_IDLE, nextEventAt = nextEventAt }
	end
	return {
		name = current.name,
		phase = current.phase,
		startsAt = current.startsAt,
		endsAt = current.endsAt,
		remaining = math.max(0, current.endsAt - os.time()),
		totalDamage = current.totalDamage,
		participants = current.participants,
		nextEventAt = nextEventAt,
	}
end

local function pickEvent(): string
	local rotation = Config.Balance.Events.rotation
	rotationIndex = (rotationIndex % #rotation) + 1
	return rotation[rotationIndex]
end

function EventService.startEvent(name: string)
	local cfg = Config.Balance.Events
	local now = os.time()
	current = {
		name = name,
		phase = PHASE_ACTIVE,
		startsAt = now,
		endsAt = now + cfg.durationSeconds,
		damage = {},
		totalDamage = 0,
		participants = 0,
	}

	if name == "SynergySurge" then
		ctx.synergySurge = cfg.synergySurgeMultiplier
		ctx.services.BuildService.invalidateAll()
		for _, player in ipairs(Players:GetPlayers()) do
			ctx.pushState(player)
		end
	end

	broadcast()
	ctx.remotes.event("Toast"):FireAllClients({
		title = name .. " STARTED",
		body = string.format("%s! %s left.", EventService.blurb(name), NumberFormatter.duration(cfg.durationSeconds)),
		kind = "event",
	})
end

function EventService.blurb(name: string): string
	if name == "LuckyBlock" then
		return "Break lucky blocks by tapping"
	elseif name == "CoinArcade" then
		return "Launch your pets at the target wall"
	elseif name == "MeteorShower" then
		return "Shatter meteors for gems"
	elseif name == "SynergySurge" then
		return "Synergy multipliers are DOUBLED"
	end
	return "Tap for loot"
end

--- Called by TapService for every authoritative damage event.
function EventService.onTap(player: Player, damage: number)
	if not current or current.phase ~= PHASE_ACTIVE or damage <= 0 then
		return
	end
	if current.damage[player.UserId] == nil then
		current.participants += 1
	end
	current.damage[player.UserId] = (current.damage[player.UserId] or 0) + damage
	current.totalDamage += damage
end

function EventService.finish()
	if not current then
		return
	end

	local name = current.name
	local cfg = Config.Balance.Events
	local rewards = cfg.rewards[name] or { coins = 1, gems = 1, tokens = 0 }
	local endedAt = current.endsAt
	local totalDamage = current.totalDamage

	for userId, damage in pairs(current.damage) do
		local player = Players:GetPlayerByUserId(userId)
		local profile = player and ctx.getProfile(player)
		if profile then
			-- Base reward + a small share-based bonus so contribution matters
			-- without punishing players who joined late.
			local share = if totalDamage > 0 then damage / totalDamage else 0
			local coins = math.floor(damage * 0.5 * (rewards.coins or 1))
			local gems = math.floor((rewards.gems or 0) * (1 + share))
			local eventTokens = math.max(1, round((rewards.tokens or 0) * (1 + share)))

			profile.currencies.coins += coins
			profile.currencies.gems += gems
			profile.currencies.eventTokens += eventTokens
			profile.events.lastRewardAt = os.time()

			ctx.touch(player)
			ctx.services.DataService.save(player, true)
			ctx.pushState(player)
			ctx.remotes.event("Toast"):FireClient(player, {
				title = name .. " COMPLETE",
				body = string.format("+%s coins, +%d gems, +%d event tokens", NumberFormatter.short(coins), gems, eventTokens),
				kind = "event",
			})
		end
	end

	if name == "SynergySurge" then
		ctx.synergySurge = 1
		ctx.services.BuildService.invalidateAll()
	end

	current = nil
	nextEventAt = endedAt + cfg.intervalSeconds
	broadcast()
end

function EventService.step(dt: number)
	local cfg = Config.Balance.Events
	local now = os.time()

	if not current then
		if nextEventAt == 0 then
			nextEventAt = now + 60
		end
		if now >= nextEventAt then
			EventService.startEvent(pickEvent())
		end
		return
	end

	-- 3 minute warning before the next event (server-wide toast once).
	if current.phase == PHASE_ACTIVE and now >= current.endsAt then
		EventService.finish()
		return
	end

	local remaining = current.endsAt - now
	if current.phase == PHASE_ACTIVE and remaining <= cfg.warningLeadSeconds and not current.warned then
		current.warned = true
		broadcast()
	end
end

function EventService.init(context): ()
	ctx = context
	nextEventAt = os.time() + 60

	ctx.remotes.fn("GetEventState").OnServerInvoke = function()
		return EventService.getState()
	end

	-- Warn players a few seconds before an event starts.
	task.spawn(function()
		while true do
			task.wait(5)
			if current == nil and nextEventAt - os.time() == 30 then
				ctx.remotes.event("Toast"):FireAllClients({
					title = "EVENT SOON",
					body = "A server event starts in 30 seconds.",
					kind = "event",
				})
			end
		end
	end)
end

return EventService
