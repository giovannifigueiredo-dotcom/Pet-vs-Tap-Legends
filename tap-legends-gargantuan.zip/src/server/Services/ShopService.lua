--!nonstrict
--[[
	ShopService.lua
	===============
	Monetization with receipts done properly:
	- ProcessReceipt is idempotent (per-receipt record + profile purchase log).
	- Grants are SERVER side only; the client never receives a "grant" request
	  it can spoof.
	- The pity bar payload is pushed with the shop state so the exclusive egg
	  bar is always honest and server-derived.

	Robux NEVER buys Tokens. Tokens are the player-to-player trading currency
	and are only earned in game, which is our main anti-RMT control.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(Shared.Config.GameConfig)
local EggMath = require(Shared.Modules.EggMath)
local PityEngine = require(Shared.Modules.PityEngine)

local ShopService = {}

local ctx
local rng = Random.new()

-- ===========================================================================
-- Pity payloads (the visual bars)
-- ===========================================================================

--- Bar data for one exclusive egg, derived from the live profile counters.
function ShopService.pityFor(profile: any, eggId: string): any
	local egg = Config.ExclusiveEggs[eggId]
	if not egg then
		return nil
	end

	local odds = EggMath.displayOdds(egg)
	local chanceByClass = {}
	for _, row in ipairs(odds) do
		chanceByClass[row.class] = row.chance
	end

	local pityState = profile.eggPity[eggId] or {}
	local bars = {}
	for classId, hardPity in pairs(egg.pity or {}) do
		if hardPity and hardPity > 0 then
			local counter = pityState[classId] or 0
			table.insert(bars, {
				class = classId,
				counter = counter,
				hardPity = hardPity,
				remaining = PityEngine.remaining(counter, hardPity),
				progress = PityEngine.progress(counter, hardPity),
				baseChance = chanceByClass[classId] or 0,
				guaranteedNext = counter + 1 >= hardPity,
			})
		end
	end
	table.sort(bars, function(a, b)
		return a.hardPity < b.hardPity
	end)

	return { eggId = eggId, name = egg.displayName, cost = egg.cost, bars = bars, odds = odds }
end

function ShopService.shopSnapshot(profile: any): any
	return {
		products = Config.Products.shopOrder(),
		entitlements = profile.shop.entitlements,
		pity = {
			magic = ShopService.pityFor(profile, "magic"),
			superdrop = ShopService.pityFor(profile, "superdrop"),
		},
		eventTokens = profile.currencies.eventTokens,
	}
end

function ShopService.pushPity(player: Player)
	local profile = ctx.getProfile(player)
	if profile then
		ctx.remotes.event("ShopState"):FireClient(player, ShopService.shopSnapshot(profile))
	end
end

-- ===========================================================================
-- Grants
-- ===========================================================================

--- Shared hatch path for paid eggs (so pity/variants behave identically).
function ShopService.hatchPaidEgg(player: Player, profile: any, eggId: string, amount: number): any
	local exclusive = Config.ExclusiveEggs[eggId]
	if not exclusive then
		return { ok = false, reason = "unknownEgg" }
	end

	local state = { pity = profile.eggPity }
	local results = {}
	local lucky = profile.shop.entitlements.lucky == true
	local hatchOptions = {
		minVariant = if eggId == "magic" then Config.Balance.Shop.magicEggVariantFloor else nil,
		applyLuck = lucky,
		luck = if lucky then Config.Balance.Shop.luckyPassPityReduction else 0,
		shinyMultiplier = if profile.shop.entitlements.shinyHunter then 2 else 1,
	}
	for _ = 1, amount do
		local roll = EggMath.hatch(eggId, { Eggs = Config.ExclusiveEggs, Pets = Config.Pets }, state, function()
			return rng:NextNumber()
		end, hatchOptions)
		if roll.ok then
			local pet = ctx.services.PetService.createInstance(roll.petId, roll.className, roll.variants)
			if pet then
				ctx.services.PetService.grantPet(player, profile, pet)
				table.insert(results, {
					uid = pet.uid,
					petId = pet.id,
					class = pet.class,
					variants = pet.variants,
					pityTriggered = roll.pityTriggered,
				})
			end
		end
	end

	ctx.touch(player)
	ctx.invalidate(player)
	ctx.pushInventory(player)
	ShopService.pushPity(player)
	return { ok = true, results = results }
end

function ShopService.grantDevProduct(player: Player, product: any)
	local profile = ctx.getProfile(player)
	if not profile then
		return false
	end

	if product.kind == "hatchBundle" then
		local result = ShopService.hatchPaidEgg(player, profile, product.eggId, product.amount or 1)
		ctx.remotes.event("Toast"):FireClient(player, {
			title = product.name,
			body = string.format("Hatched %d exclusive pets.", #(result.results or {})),
			kind = "purchase",
		})
	elseif product.kind == "eventTokens" then
		profile.currencies.eventTokens += product.amount
		ctx.touch(player)
	elseif product.kind == "boost" then
		local boost = product.boost
		if boost then
			table.insert(profile.boosts, {
				kind = boost.kind,
				multiplier = boost.multiplier,
				expiresAt = os.time() + boost.duration,
			})
			ctx.touch(player)
		end
	else
		return false
	end

	ctx.invalidate(player)
	ctx.pushState(player)
	return true
end

function ShopService.grantGamepass(player: Player, profile: any, passId: string)
	profile.shop.entitlements[passId] = true

	if passId == "teamSlots10" then
		profile.shop.entitlements.extraSlots = (profile.shop.entitlements.extraSlots or 0) + 10
	elseif passId == "teamSlots25" then
		profile.shop.entitlements.extraSlots = (profile.shop.entitlements.extraSlots or 0) + 25
	end

	ctx.touch(player)
	ctx.invalidate(player)
	ctx.pushState(player)
	return true
end

-- ===========================================================================
-- Receipts
-- ===========================================================================

function ShopService.processReceipt(receiptInfo: any): Enum.ProductPurchaseDecision
	local player = Players:GetPlayerByUserId(receiptInfo.PlayerId)
	if not player then
		return Enum.ProductPurchaseDecision.NotProcessedYet
	end

	local profile = ctx.getProfile(player)
	if not profile then
		return Enum.ProductPurchaseDecision.NotProcessedYet
	end

	local receiptId = receiptInfo.PurchaseId
	if profile.shop.purchases[receiptId] or ctx.services.DataService.hasReceipt(player.UserId, receiptId) then
		return Enum.ProductPurchaseDecision.PurchaseGranted
	end

	local product = Config.Products.fromProductId(receiptInfo.ProductId)
	if not product then
		warn("[ShopService] unknown product id: " .. tostring(receiptInfo.ProductId))
		return Enum.ProductPurchaseDecision.NotProcessedYet
	end

	local ok = ShopService.grantDevProduct(player, product)
	if not ok then
		return Enum.ProductPurchaseDecision.NotProcessedYet
	end

	profile.shop.purchases[receiptId] = { productId = receiptInfo.ProductId, at = os.time() }
	ctx.services.DataService.recordReceipt(player.UserId, receiptId)
	-- Persist immediately so a crash right after a purchase cannot lose it.
	ctx.services.DataService.save(player, true)

	return Enum.ProductPurchaseDecision.PurchaseGranted
end

-- ===========================================================================
-- Wiring
-- ===========================================================================

local function syncGamepasses(player: Player)
	local profile = ctx.getProfile(player)
	if not profile then
		return
	end
	for passId, def in pairs(Config.Products.Gamepasses) do
		if def.productId ~= 0 then
			local ok, owns = pcall(function()
				return MarketplaceService:UserOwnsGamePassAsync(player.UserId, def.productId)
			end)
			if ok and owns then
				ShopService.grantGamepass(player, profile, passId)
			end
		end
	end
end

function ShopService.init(context): ()
	ctx = context

	MarketplaceService.ProcessReceipt = ShopService.processReceipt

	-- Refresh gamepass entitlements shortly after join (purchases made outside
	-- the game must apply on rejoin).
	Players.PlayerAdded:Connect(function(player)
		task.delay(5, function()
			if player.Parent then
				syncGamepasses(player)
			end
		end)
	end)
end

function ShopService.onProfileLoaded(player: Player)
	ShopService.pushPity(player)
end

return ShopService
