--!nonstrict
--[[
	EnchantService.lua (Shadow Realm)
	=================================
	The reroll loop. Design contract:

	- Every reroll is a real gem sink with a visible price that grows with use.
	- Locking a modifier costs 3x per locked slot, so a "perfect 4th stat" hunt
	  is expensive by design and never free.
	- Pity: 40 rerolls without a tier IV+ guarantees a tier IV+ on the next
	  roll. EnchantService uses PityEngine.barData directly because enchants DO
	  use the soft-pity ramp (unlike eggs, which only have a hard counter).

	Slots: Standard pet 1, Huge 2, Titanic 3, Gargantuan 4, relic 2.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Shared = ReplicatedStorage:WaitForChild("Shared")

local Config = require(Shared.Config.GameConfig)
local EggMath = require(Shared.Modules.EggMath)
local PityEngine = require(Shared.Modules.PityEngine)

local EnchantService = {}

local ctx
local rng = Random.new()

local function weightedPick(options: { any })
	return EggMath.weightedPick(options, function()
		return rng:NextNumber()
	end)
end

-- ===========================================================================
-- Slot rules
-- ===========================================================================

function EnchantService.slotsFor(targetKind: string, target: any): number
	if targetKind == "relic" then
		return 2
	end
	local class = Config.Classes[target.class or "Standard"] or Config.Classes.Standard
	return class.enchantSlots or 1
end

-- ===========================================================================
-- Rolling
-- ===========================================================================

local function rollStat()
	local options = {}
	for id, def in pairs(Config.Enchants.Definitions) do
		table.insert(options, { id = id, weight = def.weight })
	end
	return weightedPick(options).id
end

local function rollTier(forceMinimum: number?): number
	local options = {}
	for index, weight in ipairs(Config.Enchants.TierWeights) do
		table.insert(options, { tier = index, weight = weight })
	end
	local tier = weightedPick(options).tier
	if forceMinimum then
		tier = math.max(tier, forceMinimum)
	end
	return tier
end

function EnchantService.rollModifier(forceMinimumTier: number?): any
	return { id = rollStat(), tier = rollTier(forceMinimumTier) }
end

-- ===========================================================================
-- Cost + pity
-- ===========================================================================

function EnchantService.cost(profile: any, lockedCount: number): number
	local forging = Config.Enchants.Forging
	local base = forging.baseGemCost * (forging.costGrowth ^ (profile.enchantPity.totalRerolls or 0))
	return math.floor(base * (forging.lockCostMultiplier ^ lockedCount))
end

function EnchantService.pityBar(profile: any): any
	local forging = Config.Enchants.Forging
	return PityEngine.barData(profile.enchantPity.counter or 0, forging.hard, 0, 0.75)
end

-- ===========================================================================
-- Reroll
-- ===========================================================================

--[[
	reroll(player, targetKind, targetId, lockedSlots)
	  targetKind : "pet" | "relic"
	  targetId   : pet uid, or relic id
	  lockedSlots: array of 1-based slot indices to keep
]]
function EnchantService.reroll(player: Player, targetKind: string, targetId: string, lockedSlots: any)
	local profile = ctx.getProfile(player)
	if not profile then
		return { ok = false, reason = "noProfile" }
	end
	if targetKind ~= "pet" and targetKind ~= "relic" then
		return { ok = false, reason = "badTarget" }
	end

	local target
	if targetKind == "pet" then
		target = profile.pets[targetId]
		if not target then
			return { ok = false, reason = "notOwned" }
		end
	else
		if (profile.relics.owned[targetId] or 0) <= 0 then
			return { ok = false, reason = "notOwned" }
		end
		target = { enchants = profile.relics.enchants[targetId] or {} }
	end

	local slots = EnchantService.slotsFor(targetKind, target)
	local locked = {}
	if type(lockedSlots) == "table" then
		for _, index in ipairs(lockedSlots) do
			if type(index) ~= "number" or index < 1 or index > slots then
				return { ok = false, reason = "badLock" }
			end
			locked[index] = true
		end
	end

	local lockedCount = 0
	for _ in pairs(locked) do
		lockedCount += 1
	end
	-- You cannot lock an empty slot: it would be paying for nothing.
	local existing = target.enchants or {}
	for index in pairs(locked) do
		if not existing[index] then
			return { ok = false, reason = "lockEmptySlot", slot = index }
		end
	end

	local cost = EnchantService.cost(profile, lockedCount)
	if profile.currencies.gems < cost then
		return { ok = false, reason = "insufficientGems", cost = cost, gems = profile.currencies.gems }
	end

	profile.currencies.gems -= cost
	profile.enchantPity.totalRerolls = (profile.enchantPity.totalRerolls or 0) + 1

	-- Pity: force a tier IV+ when due.
	local forging = Config.Enchants.Forging
	local duePity = (profile.enchantPity.counter or 0) + 1 >= forging.hard
	local forceMinimum = if duePity then forging.epicPlusTier else nil

	local result = {}
	local bestTier = 0
	for slot = 1, slots do
		if locked[slot] and existing[slot] then
			result[slot] = existing[slot]
			bestTier = math.max(bestTier, existing[slot].tier)
		else
			local modifier = EnchantService.rollModifier(forceMinimum)
			result[slot] = modifier
			bestTier = math.max(bestTier, modifier.tier)
		end
	end

	-- Pity only resets when a reroll actually produced a high tier.
	if bestTier >= forging.epicPlusTier then
		profile.enchantPity.counter = 0
	else
		profile.enchantPity.counter = (profile.enchantPity.counter or 0) + 1
	end

	if targetKind == "pet" then
		target.enchants = result
		-- Keep the resolved power bonus in sync for the build cache.
		local bonus = 0
		for _, enchant in ipairs(result) do
			local def = Config.Enchants.Definitions[enchant.id]
			if def and def.stat == "power" then
				bonus += def.values[enchant.tier] or 0
			end
		end
		target.enchantPowerBonus = bonus
	else
		profile.relics.enchants[targetId] = result
	end

	ctx.touch(player)
	ctx.invalidate(player)
	ctx.pushState(player)
	ctx.pushInventory(player)

	return {
		ok = true,
		targetKind = targetKind,
		targetId = targetId,
		enchants = result,
		cost = cost,
		gems = profile.currencies.gems,
		pityTriggered = duePity,
		pity = EnchantService.pityBar(profile),
	}
end

function EnchantService.init(context): ()
	ctx = context

	ctx.remotes.fn("RerollEnchant").OnServerInvoke = function(player, targetKind, targetId, lockedSlots)
		if type(targetKind) ~= "string" or type(targetId) ~= "string" then
			return { ok = false, reason = "badRequest" }
		end
		return EnchantService.reroll(player, targetKind, targetId, lockedSlots)
	end
end

return EnchantService
