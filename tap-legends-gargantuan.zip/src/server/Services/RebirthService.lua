--!nonstrict
--[[
	RebirthService.lua
	==================
	Rebirth is the core prestige loop: spend coins, reset tap upgrades, keep
	EVERYTHING else (pets, relics, enchants, pity counters, zones), gain a
	permanent multiplier and tradeable Tokens.

	Design decisions that matter:
	- Pets are never reset. Losing a Gargantuan to a rebirth would be a refund
	  request, not a mechanic.
	- Tokens are earned here (and in raids/events) and are the only tradeable
	  currency. They are never sold for Robux, which is our main anti-RMT dam.
	- Unlocks are milestone gated so rebirths always feel like a door opening.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Shared = ReplicatedStorage:WaitForChild("Shared")

local Config = require(Shared.Config.GameConfig)
local MultiplierEngine = require(Shared.Modules.MultiplierEngine)

local RebirthService = {}

local ctx

function RebirthService.info(player: Player)
	local profile = ctx.getProfile(player)
	if not profile then
		return nil
	end
	local requirement = MultiplierEngine.rebirthRequirement(profile.rebirths, Config)
	return {
		rebirths = profile.rebirths,
		requirement = requirement,
		canRebirth = profile.currencies.coins >= requirement,
		progress = if requirement > 0 then math.clamp(profile.currencies.coins / requirement, 0, 1) else 1,
		currentMultiplier = MultiplierEngine.rebirthMultiplier(profile.rebirths, Config),
		nextMultiplier = MultiplierEngine.rebirthMultiplier(profile.rebirths + 1, Config),
		tokenReward = MultiplierEngine.rebirthTokenReward(profile.rebirths, Config),
		maxRebirths = Config.Balance.Rebirth.maxRebirths,
	}
end

--- Zones unlocked purely by rebirth count (coin-gated ones are bought).
local function grantMilestoneZones(profile: any)
	for _, zone in ipairs(Config.Zones) do
		if zone.unlockRebirths > 0 and profile.rebirths >= zone.unlockRebirths then
			profile.zones.unlocked[zone.id] = true
		end
	end
end

function RebirthService.rebirth(player: Player)
	local profile = ctx.getProfile(player)
	if not profile then
		return { ok = false, reason = "noProfile" }
	end
	if profile.rebirths >= Config.Balance.Rebirth.maxRebirths then
		return { ok = false, reason = "maxRebirths" }
	end

	local requirement = MultiplierEngine.rebirthRequirement(profile.rebirths, Config)
	if profile.currencies.coins < requirement then
		return { ok = false, reason = "insufficientCoins", requirement = requirement }
	end

	-- Reset the tap economy, keep the collection.
	profile.rebirths += 1
	profile.currencies.coins = 0
	profile.tapUpgradeLevel = 0

	local tokens = MultiplierEngine.rebirthTokenReward(profile.rebirths - 1, Config)
	profile.currencies.tokens += tokens
	grantMilestoneZones(profile)

	ctx.touch(player)
	ctx.invalidate(player)
	ctx.pushState(player)
	ctx.pushInventory(player)

	ctx.remotes.event("Toast"):FireClient(player, {
		title = string.format("REBIRTH %d", profile.rebirths),
		body = string.format("+%d Tokens. Multiplier is now x%.2f.", tokens, MultiplierEngine.rebirthMultiplier(profile.rebirths, Config)),
		kind = "rebirth",
	})

	return {
		ok = true,
		rebirths = profile.rebirths,
		tokens = tokens,
		currencies = profile.currencies,
		build = ctx.services.BuildService.snapshotForClient(player),
		info = RebirthService.info(player),
	}
end

--- Buy a zone with coins (rebirth-gated zones check the rebirth count).
function RebirthService.unlockZone(player: Player, zoneId: string)
	local profile = ctx.getProfile(player)
	if not profile then
		return { ok = false, reason = "noProfile" }
	end
	if profile.zones.unlocked[zoneId] then
		return { ok = true, alreadyUnlocked = true }
	end

	local zone = Config.ZonesModule.get(zoneId)
	if not zone then
		return { ok = false, reason = "unknownZone" }
	end
	if profile.rebirths < zone.unlockRebirths then
		return { ok = false, reason = "rebirthLocked", required = zone.unlockRebirths }
	end
	if profile.currencies.coins < zone.unlockCoins then
		return { ok = false, reason = "insufficientCoins", cost = zone.unlockCoins }
	end

	profile.currencies.coins -= zone.unlockCoins
	profile.zones.unlocked[zoneId] = true
	profile.zones.current = zoneId

	ctx.touch(player)
	ctx.pushState(player)
	return { ok = true, zone = zoneId, coins = profile.currencies.coins }
end

function RebirthService.init(context): ()
	ctx = context

	ctx.remotes.fn("Rebirth").OnServerInvoke = function(player)
		return RebirthService.rebirth(player)
	end
end

return RebirthService
