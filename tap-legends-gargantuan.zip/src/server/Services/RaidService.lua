--!nonstrict
--[[
	RaidService.lua
	===============
	Server-wide boss raid every 4 hours.

	HP formula (Balance.Raid):  hp = baseHealth + powerHealthRatio * sum(damagePerTap)
	so the boss scales with the ACTUAL server power instead of a fixed number.
	The fight is tuned to land at 55-70% of theoretical max output over 5 minutes:
	a full server wins comfortably, a half-idle server has to try.

	Rewards are contribution based (damage share), with an exclusive egg chance
	per tier and a participation floor so leeches get nothing.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(Shared.Config.GameConfig)
local NumberFormatter = require(Shared.Modules.NumberFormatter)

local RaidService = {}

local ctx
local boss: any? = nil
local nextRaidAt = 0

local PHASE_IDLE = "idle"
local PHASE_WINDUP = "windup"
local PHASE_ACTIVE = "active"
local PHASE_RESULT = "result"

-- ===========================================================================
-- State
-- ===========================================================================

local function broadcast(payload: any)
	ctx.remotes.event("RaidState"):FireAllClients(payload)
end

local function publicBossState()
	if not boss then
		return { phase = PHASE_IDLE, nextRaidAt = nextRaidAt }
	end
	return {
		phase = boss.phase,
		bossId = boss.bossId,
		name = boss.name,
		hp = math.max(0, boss.hp),
		maxHp = boss.maxHp,
		progress = if boss.maxHp > 0 then math.clamp(1 - boss.hp / boss.maxHp, 0, 1) else 0,
		startsAt = boss.startsAt,
		endsAt = boss.endsAt,
		contributors = boss.contributors,
		topDamage = boss.topDamage,
		lastResult = boss.lastResult,
		nextRaidAt = nextRaidAt,
	}
end

function RaidService.getState()
	return publicBossState()
end

-- ===========================================================================
-- Spawn
-- ===========================================================================

local function serverPowerSum(): number
	local total = 0
	for _, player in ipairs(Players:GetPlayers()) do
		local build = ctx.services.BuildService.get(player)
		if build then
			total += build.damagePerTap
		end
	end
	return total
end

function RaidService.startBoss()
	local cfg = Config.Balance.Raid
	local players = Players:GetPlayers()
	if #players < cfg.minPlayers then
		nextRaidAt = os.time() + cfg.intervalSeconds
		broadcast(publicBossState())
		return
	end

	local zone = Config.Zones[#Config.Zones] -- endgame boss flavour
	local maxHp = math.floor(cfg.baseHealth + cfg.powerHealthRatio * serverPowerSum())

	boss = {
		bossId = "raid_" .. os.time(),
		name = zone.boss,
		phase = PHASE_WINDUP,
		hp = maxHp,
		maxHp = maxHp,
		startsAt = os.time() + cfg.windupSeconds,
		endsAt = os.time() + cfg.windupSeconds + cfg.durationSeconds,
		damage = {}, -- [userId] = damage
		contributors = 0,
		topDamage = 0,
		lastResult = nil,
	}

	broadcast(publicBossState())
	ctx.remotes.event("Toast"):FireAllClients({
		title = "RAID INCOMING",
		body = string.format("%s is forming. Pool your taps in %s!", boss.name, NumberFormatter.duration(cfg.windupSeconds)),
		kind = "raid",
	})
end

-- ===========================================================================
-- Contribution
-- ===========================================================================

function RaidService.contribute(player: Player, damage: number)
	if not boss or boss.phase ~= PHASE_ACTIVE then
		return
	end
	if damage <= 0 then
		return
	end

	local userId = player.UserId
	boss.damage[userId] = (boss.damage[userId] or 0) + damage
	boss.hp -= damage
	boss.topDamage = math.max(boss.topDamage, boss.damage[userId])

	local profile = ctx.getProfile(player)
	if profile then
		profile.boss.totalDamage = (profile.boss.totalDamage or 0) + damage
	end

	if boss.hp <= 0 then
		RaidService.finish(true)
	end
end

-- ===========================================================================
-- Rewards
-- ===========================================================================

local function rewardTier(share: number): number
	local tiers = Config.Balance.Raid.contributionRewardTiers
	local tier = 0
	for index, threshold in ipairs(tiers) do
		if share >= threshold then
			tier = index - 1
		end
	end
	return tier
end

function RaidService.finish(defeated: boolean)
	if not boss then
		return
	end
	boss.phase = PHASE_RESULT

	local cfg = Config.Balance.Raid
	local totalDamage = 0
	for _, damage in pairs(boss.damage) do
		totalDamage += damage
	end

	local rewards = {}
	for userId, damage in pairs(boss.damage) do
		local player = Players:GetPlayerByUserId(userId)
		local profile = player and ctx.getProfile(player)
		if profile and totalDamage > 0 then
			local share = damage / totalDamage
			if share >= cfg.participationMinimumDamageShare then
				local tier = rewardTier(share)
				local coins = math.floor(damage * 0.75)
				local gems = 5 + tier * 15
				local tokens = math.max(1, math.floor((damage / 1e6) * cfg.tokenRewardPerMillion))
				if defeated and tier > 0 then
					tokens += tier
				end

				profile.currencies.coins += coins
				profile.currencies.gems += gems
				profile.currencies.tokens += tokens
				profile.boss.kills += if defeated then 1 else 0
				profile.boss.lastRewardAt = os.time()

				-- Exclusive egg drop by tier (defeated bosses only).
				local eggRolled = false
				if defeated then
					local chance = cfg.exclusiveEggChancePerTier[tier + 1] or 0
					if math.random() < chance then
						local result = ctx.services.ShopService.hatchPaidEgg(player, profile, "superdrop", 1)
						eggRolled = result.ok
					end
				end

				table.insert(rewards, {
					userId = userId,
					name = player.Name,
					damage = damage,
					share = share,
					tier = tier,
					coins = coins,
					gems = gems,
					tokens = tokens,
					exclusiveEgg = eggRolled,
				})

				ctx.touch(player)
				ctx.invalidate(player)
				ctx.services.DataService.save(player, true)
				ctx.pushState(player)
				ctx.remotes.event("Toast"):FireClient(player, {
					title = if defeated then "RAID DEFEATED" else "RAID EXPIRED",
					body = string.format("Share %.1f%%, +%s coins, +%d gems, +%d Tokens%s", share * 100, NumberFormatter.short(coins), gems, tokens, if eggRolled then ", EXCLUSIVE EGG!" else ""),
					kind = "raid",
				})
			end
		end
	end

	boss.lastResult = {
		defeated = defeated,
		totalDamage = totalDamage,
		rewards = rewards,
	}

	nextRaidAt = os.time() + cfg.intervalSeconds
	broadcast(publicBossState())

	-- Clean up after the result screen has been seen.
	local finished = boss
	boss = nil
	task.delay(15, function()
		if boss == nil then
			broadcast({ phase = PHASE_IDLE, nextRaidAt = nextRaidAt, lastResult = finished.lastResult })
		end
	end)
end

-- ===========================================================================
-- Loop
-- ===========================================================================

function RaidService.step(dt: number)
	local now = os.time()

	if not boss then
		if nextRaidAt == 0 then
			nextRaidAt = now + 120 -- first raid two minutes after server start
		end
		if now >= nextRaidAt then
			RaidService.startBoss()
		end
		return
	end

	if boss.phase == PHASE_WINDUP and now >= boss.startsAt then
		boss.phase = PHASE_ACTIVE
		broadcast(publicBossState())
	elseif boss.phase == PHASE_ACTIVE and now >= boss.endsAt then
		RaidService.finish(false)
	end
end

function RaidService.init(context): ()
	ctx = context
	nextRaidAt = os.time() + 120

	-- Slow state broadcast: 1/s is plenty for a health bar.
	task.spawn(function()
		while true do
			task.wait(1)
			if boss then
				broadcast(publicBossState())
			end
		end
	end)
end

return RaidService
