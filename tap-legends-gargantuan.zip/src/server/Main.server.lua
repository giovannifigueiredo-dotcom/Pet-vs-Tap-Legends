--!nonstrict
--[[
	Main.server.lua
	===============
	Boot order matters:
	  1. create remotes (clients may join at any moment)
	  2. build the shared context (every service gets the same ctx)
	  3. init stateless/simple services
	  4. define the push helpers used by onProfileLoaded
	  5. DataService.init LAST - its PlayerAdded handlers immediately push state

	Services never require each other at module scope; they talk through
	`ctx.services` so init order cannot create load cycles.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Shared = ReplicatedStorage:WaitForChild("Shared")
local Config = require(Shared.Config.GameConfig)
local Remotes = require(Shared.Net.Remotes)
local MultiplierEngine = require(Shared.Modules.MultiplierEngine)
local InventoryQuery = require(Shared.Modules.InventoryQuery)
local PityEngine = require(Shared.Modules.PityEngine)
local NumberFormatter = require(Shared.Modules.NumberFormatter)

local Services = {
	DataService = require(script.Parent.Services.DataService),
	BuildService = require(script.Parent.Services.BuildService),
	TapService = require(script.Parent.Services.TapService),
	PetService = require(script.Parent.Services.PetService),
	RebirthService = require(script.Parent.Services.RebirthService),
	EnchantService = require(script.Parent.Services.EnchantService),
	RelicService = require(script.Parent.Services.RelicService),
	ShopService = require(script.Parent.Services.ShopService),
	TradeService = require(script.Parent.Services.TradeService),
	RaidService = require(script.Parent.Services.RaidService),
	EventService = require(script.Parent.Services.EventService),
}

-- ===========================================================================
-- Context
-- ===========================================================================

local statePushQueued: { [Player]: boolean } = {}

local ctx: any = {
	config = Config,
	services = Services,
	remotes = Remotes,
	synergySurge = 1,
	getProfile = function(player)
		return Services.DataService.get(player)
	end,
	touch = function(player)
		Services.DataService.touch(player)
	end,
	invalidate = function(player)
		Services.BuildService.invalidate(player)
	end,
	pushState = function(player) end,
	pushInventory = function(player) end,
	onProfileLoaded = function(player, profile) end,
	onProfileReleasing = function(player) end,
}

-- ===========================================================================
-- State payloads
-- ===========================================================================

local function compactPet(pet: any)
	local def = Config.Pets[pet.id]
	return {
		uid = pet.uid,
		id = pet.id,
		name = if def then def.name else pet.id,
		element = if def then def.element else "Nature",
		family = if def then def.family else "Beast",
		["class"] = pet.class,
		variants = pet.variants,
		level = pet.level,
		enchants = pet.enchants,
		locked = pet.locked,
		favorite = pet.favorite,
		acquiredAt = pet.acquiredAt,
		power = MultiplierEngine.petPower(pet, Config),
	}
end

function ctx.pushState(player: Player)
	-- Coalesce: several services can fire in the same frame (e.g. a trade).
	if statePushQueued[player] then
		return
	end
	statePushQueued[player] = true

	task.defer(function()
		statePushQueued[player] = nil
		local profile = Services.DataService.get(player)
		if not profile or not player.Parent then
			return
		end

		local build = Services.BuildService.get(player)
		local rebirthInfo = Services.RebirthService.info(player)

		Remotes.event("StateSync"):FireClient(player, {
			currencies = profile.currencies,
			stats = { taps = profile.stats.taps, damage = profile.stats.damage, hatches = profile.stats.hatches },
			rebirths = profile.rebirths,
			tapUpgradeLevel = profile.tapUpgradeLevel,
			critUpgradeLevel = profile.critUpgradeLevel,
			tapUpgradeCost = if build then build.upgradeCost else 0,
			rebirthInfo = rebirthInfo,
			build = if build then Services.BuildService.snapshotForClient(player) else nil,
			relics = { owned = profile.relics.owned, equipped = profile.relics.equipped, slots = Services.RelicService.slotCount(profile) },
			zones = profile.zones,
			boss = profile.boss,
			settings = profile.settings,
			enchants = { pity = Services.EnchantService.pityBar(profile) },
			shop = { entitlements = profile.shop.entitlements },
			equipped = profile.equipped,
			folderCount = (function()
				local count = 0
				for _ in pairs(profile.folders) do
					count += 1
				end
				return count
			end)(),
		})
	end)
end

function ctx.pushInventory(player: Player)
	task.defer(function()
		local profile = Services.DataService.get(player)
		if not profile or not player.Parent then
			return
		end

		local pets = {}
		local total = 0
		for _, pet in pairs(profile.pets) do
			total += 1
			table.insert(pets, compactPet(pet))
		end

		Remotes.event("InventorySync"):FireClient(player, {
			total = total,
			pets = pets,
			equipped = profile.equipped,
			folders = profile.folders,
			eggPity = profile.eggPity,
			maxSlots = (function()
				local build = Services.BuildService.get(player)
				return if build then build.maxSlots else Config.Balance.Team.baseSlots
			end)(),
		})
	end)
end

-- ===========================================================================
-- Inventory paging (for collections past a few thousand pets)
-- ===========================================================================

local function equippedTeam(player: Player, profile: any)
	local team = {}
	for _, uid in ipairs(profile.equipped) do
		local pet = profile.pets[uid]
		if pet then
			local instance = table.clone(pet)
			instance.enchantPowerBonus = MultiplierEngine.itemPowerBonus(pet, Config)
			table.insert(team, instance)
		end
	end
	return team
end

local SORT_WHITELIST = {
	power = true, synergy = true, element = true, tapMultiplier = true,
	["class"] = true, level = true, newest = true, name = true,
}

--- The client supplies these; sanitize before they reach shared code.
local function sanitizeFilters(raw: any): any
	if type(raw) ~= "table" then
		return nil
	end
	local function text(value: any, maxLength: number): string?
		if type(value) ~= "string" then
			return nil
		end
		return string.sub(value, 1, maxLength)
	end
	return {
		search = text(raw.search, 32),
		element = text(raw.element, 16),
		family = text(raw.family, 16),
		["class"] = text(raw["class"], 16),
		variant = text(raw.variant, 16),
		lockedOnly = raw.lockedOnly == true,
		excludeEquipped = raw.excludeEquipped == true,
		minPower = math.max(0, tonumber(raw.minPower) or 0),
	}
end

Remotes.fn("GetInventoryPage").OnServerInvoke = function(player, options)
	local profile = Services.DataService.get(player)
	if not profile or type(options) ~= "table" then
		return { rows = {}, total = 0, page = 1, pageCount = 1 }
	end

	local list = {}
	for _, pet in pairs(profile.pets) do
		table.insert(list, pet)
	end

	local sort = if SORT_WHITELIST[options.sort] then options.sort else "power"
	local page = math.clamp(math.floor(tonumber(options.page) or 1), 1, 100000)
	local pageSize = math.clamp(math.floor(tonumber(options.pageSize) or Config.Balance.UI.inventoryPageSize), 1, 200)

	local result = InventoryQuery.query(list, Config.Pets, {
		filters = sanitizeFilters(options.filters),
		sort = sort,
		ascending = options.ascending == true,
		page = page,
		pageSize = pageSize,
		team = equippedTeam(player, profile),
		engine = MultiplierEngine,
		config = Config,
	})

	local rows = {}
	for _, row in ipairs(result.rows) do
		local pet = row.pet
		local def = row.def
		table.insert(rows, {
			uid = pet.uid,
			id = pet.id,
			name = if def then def.name else pet.id,
			element = if def then def.element else "Nature",
			family = if def then def.family else "Beast",
			["class"] = pet.class,
			variants = pet.variants,
			level = pet.level,
			enchants = pet.enchants,
			locked = pet.locked,
			favorite = pet.favorite,
			power = row.power,
			synergyDelta = row.synergyDelta,
			tapMultiplierIfAdded = row.tapMultiplierIfAdded,
		})
	end

	return {
		rows = rows,
		total = result.total,
		page = result.page,
		pageCount = result.pageCount,
	}
end

-- ===========================================================================
-- Folders
-- ===========================================================================

Remotes.fn("SetFolder").OnServerInvoke = function(player, action, payload)
	local profile = Services.DataService.get(player)
	if not profile or type(action) ~= "string" or type(payload) ~= "table" then
		return { ok = false, reason = "badRequest" }
	end

	if action == "create" then
		local id, err = InventoryQuery.createFolder(profile.folders, tostring(payload.name or ""), Config.Balance.UI.maxFolders)
		if not id then
			return { ok = false, reason = err }
		end
		ctx.touch(player)
		ctx.pushInventory(player)
		return { ok = true, folderId = id }
	elseif action == "assign" then
		if type(payload.petUid) ~= "string" or not profile.pets[payload.petUid] then
			return { ok = false, reason = "notOwned" }
		end
		if payload.folderId == nil then
			InventoryQuery.removeFromFolders(profile.folders, payload.petUid)
		elseif not InventoryQuery.assignToFolder(profile.folders, tostring(payload.folderId), payload.petUid) then
			return { ok = false, reason = "unknownFolder" }
		end
		ctx.touch(player)
		ctx.pushInventory(player)
		return { ok = true }
	elseif action == "rename" then
		local folder = profile.folders[tostring(payload.folderId)]
		if not folder then
			return { ok = false, reason = "unknownFolder" }
		end
		local name = tostring(payload.name or "")
		if name == "" or #name > 24 then
			return { ok = false, reason = "badName" }
		end
		folder.name = name
		ctx.touch(player)
		ctx.pushInventory(player)
		return { ok = true }
	elseif action == "delete" then
		profile.folders[tostring(payload.folderId)] = nil
		ctx.touch(player)
		ctx.pushInventory(player)
		return { ok = true }
	end

	return { ok = false, reason = "unknownAction" }
end

-- ===========================================================================
-- Lifecycle hooks
-- ===========================================================================

ctx.onProfileLoaded = function(player, profile)
	Services.BuildService.invalidate(player)

	ctx.pushState(player)
	ctx.pushInventory(player)
	Services.ShopService.onProfileLoaded(player)
	Remotes.event("RaidState"):FireClient(player, Services.RaidService.getState())
	Remotes.event("EventState"):FireClient(player, Services.EventService.getState())

	Remotes.event("Toast"):FireClient(player, {
		title = "Welcome back",
		body = string.format("%d rebirths | %s pets | %s Tokens", profile.rebirths, NumberFormatter.full((function()
			local count = 0
			for _ in pairs(profile.pets) do
				count += 1
			end
			return count
		end)()), NumberFormatter.short(profile.currencies.tokens)),
		kind = "info",
	})
end

ctx.onProfileReleasing = function(player)
	Services.TradeService.cancelFor(player)
	Services.TapService.forget(player)
end

-- ===========================================================================
-- Boot
-- ===========================================================================

Remotes.ensureAll()

Services.BuildService.init(ctx)
Services.TapService.init(ctx)
Services.PetService.init(ctx)
Services.RebirthService.init(ctx)
Services.EnchantService.init(ctx)
Services.RelicService.init(ctx)
Services.ShopService.init(ctx)
Services.TradeService.init(ctx)
Services.RaidService.init(ctx)
Services.EventService.init(ctx)

-- DataService last: from here on players can be loaded and pushed.
Services.DataService.init(ctx)

-- Live-ops tick. 0.25s is enough for raids/events/trade timeouts; taps and
-- auto-taps have their own fixed step inside TapService.
task.spawn(function()
	local accumulator = 0
	while true do
		local dt = task.wait(0.25)
		accumulator += dt
		if accumulator >= 0.25 then
			accumulator = 0
			local ok, err = pcall(function()
				Services.RaidService.step(dt)
				Services.EventService.step(dt)
				Services.TradeService.step(dt)
			end)
			if not ok then
				warn("[Main] tick failed: " .. tostring(err))
			end
		end
	end
end)

print(string.format("[BOOT] TapPetTycoon server ready (config v%d, %d pets, %d eggs)", Config.Balance.Version, (function()
	local count = 0
	for _ in pairs(Config.Pets) do
		count += 1
	end
	return count
end)(), (function()
	local count = 0
	for _ in pairs(Config.Eggs) do
		count += 1
	end
	return count
end)()))
