# DataStores & Persistence

Companion to [GDD.md](GDD.md) §11. Implementation: `src/server/Services/DataService.lua`.
Schema version: **1**.

---

## 1. Store inventory

| Store | Type | Key format | Value | Write frequency | Approx. size |
|-------|------|------------|-------|-----------------|--------------|
| `PlayerProfiles_v1` | DataStore | `u_<userId>` | `{ profile, session }` | 1/min autosave (staggered), on leave, on trade/purchase | 40 KB – 900 KB |
| `Leaderboard_Rebirths_v1` | OrderedDataStore | `<userId>` | integer | per save | tiny |
| `Leaderboard_Power_v1` | OrderedDataStore | `<userId>` | `floor(damagePerTap × 100)` | per save | tiny |
| `Leaderboard_BossDamage_v1` | OrderedDataStore | `<userId>` | integer | per save | tiny |
| `TradeAudit_v1` | DataStore | `t_<unix>_<random>` | trade record | per completed trade | ~0.5 KB |
| `Receipts_v1` | DataStore | `<userId>_<receiptId>` | `true` | per purchase | tiny |

**Limits respected**
- 4 MB per key (hard Roblox limit). A 20,000-pet profile with 4 enchants each is ~3.1 MB; we page the
  client payload and keep the stored shape compact. **Soft limit warning at 3 MB**, and the design cap is
  10,000 inbox pets plus 250 equipped.
- 260 KB/s per-key throughput is irrelevant at our payload sizes, but the 60-request/60s per-server
  budget is why autosaves are **staggered 0.1 s apart**.
- OrderedDataStore values must be integers; power is multiplied by 100 before writing.

---

## 2. Profile schema

```lua
{
  schemaVersion = 1,
  userId = 1234567,
  createdAt = 1760000000,
  lastSeen  = 1760003600,

  currencies = { coins = 0, gems = 0, tokens = 0, eventTokens = 0 },
  stats      = { taps = 0, damage = 0, hatches = 0, playtime = 0 },

  rebirths = 0,
  tapUpgradeLevel = 0,
  critUpgradeLevel = 0,

  -- PETS: dictionary keyed by uid (string). Every pet reference elsewhere is a uid.
  pets = {
    ["p_1760000000_0042"] = {
      uid = "p_1760000000_0042",
      id = "cinderdrake",          -- key into Config.Pets
      class = "Huge",              -- Standard | Huge | Titanic | Gargantuan
      variants = { "gold", "rainbow" },
      level = 17,
      enchants = { { id = "power", tier = 4 }, { id = "tap", tier = 2 } },
      locked = false,              -- locked = cannot be traded
      favorite = true,
      acquiredAt = 1760000000,
    },
  },

  -- EQUIPPED: ORDERED array of uids (slot order is visible to the player).
  equipped = { "p_1760000000_0042" },

  folders = {
    ["f_1760000123_5512"] = { name = "Dragons", icon = "folder", petUids = { "p_..." } },
  },

  relics = {
    owned = { ember_gauntlet = 1 },       -- id -> count
    equipped = { "ember_gauntlet" },      -- ordered ids
    enchants = { ember_gauntlet = { { id = "tap", tier = 3 } } },
    pity = 0,                             -- forges without Epic+
    forges = 12,
  },

  -- PITY per egg per class: the exact counters the pity bars render.
  eggPity = { magic = { Huge = 7, Titanic = 61, Gargantuan = 480 } },
  enchantPity = { counter = 4, totalRerolls = 39 },

  zones = { unlocked = { meadow = true, coral = true }, current = "coral" },

  boss = { totalDamage = 0, kills = 0, lastRewardAt = 0 },
  trading = { totalTrades = 0, lastTradeAt = 0, hourStart = 0, tradesThisHour = 0 },

  shop = {
    entitlements = { vip = true, autoTap = true, extraSlots = 10 },
    purchases = { ["receipt-guid"] = { productId = 123, at = 1760000000 } },
  },

  events = { lastRewardAt = 0, eventProgress = {}, seasonXp = 0 },
  boosts = { { kind = "coin", multiplier = 2, expiresAt = 1760000900 } },
  settings = { music = true, sfx = true, damageNumbers = true, autoEquip = false },

  -- injected at save time, never trusted from the client:
  session = { jobId = "job:12345", lockedAt = 1760003600 },
}
```

### Field notes

| Field | Rule |
|-------|------|
| `pets[uid]` | uid is immutable for the owner; on trade the receiving side gets a **new** uid to avoid cross-profile collisions |
| `equipped` | ordered, max `MultiplierEngine.maxSlots` (8 base, up to 250) |
| `folders` | max 30 (`Balance.UI.maxFolders`), one folder per pet, `petUids` must all exist |
| `eggPity` | only classes with a configured pity counter exist; preserved on rebirth |
| `shop.purchases` | rolling log of the last 200 receipts (older ones live in `Receipts_v1`) |
| `boosts` | expired entries are pruned at build time, not deleted immediately (cheap) |

---

## 3. Session locking

The record stores `session = { jobId, lockedAt }`.

1. On join: read `u_<userId>`.
2. If `session.jobId ~= our jobId` **and** `now − lockedAt < 600 s`, the profile is locked by another
   server: wait 2 s and retry (5 attempts). After that, load anyway with a warning — this is the
   documented tradeoff of a homegrown lock.
3. On any save, the `UpdateAsync` callback returns `nil` if another live session owns the key, which
   prevents a stale server from clobbering live data.
4. On leave: save, then clear `session` **only if we still own it**.

> **Production recommendation:** swap steps 1–4 for [ProfileStore](https://github.com/MadStudioRoblox/ProfileStore)
> or Suphi's DataStore. The schema, autosave cadence and reconcile-with-defaults migration are identical;
> only the lock/save transport changes. This is a contained `DataService` swap.

---

## 4. Migration strategy

`DataService.migrate(profile, userId)` recursively merges the current `template()` into the loaded
profile:

- missing scalar/table fields are added from defaults,
- **arrays are never merged** (they are data),
- `schemaVersion` is stamped.

For destructive migrations (renaming a pet id, changing a stat), add a numbered step:

```lua
if profile.schemaVersion < 2 then
  -- example: rename legacy pet ids
  for _, pet in pairs(profile.pets) do
    if pet.id == "old_cat" then pet.id = "reefcat" end
  end
  profile.schemaVersion = 2
end
```

Rules: migrations run **before** the profile is handed to services, must be idempotent, and must never
delete pets or purchases.

---

## 5. Leaderboards

OrderedDataStores are cosmetic. `DataService.publishLeaderboards` writes three boards per save inside
`pcall` and **never fails a save** if a leaderboard write is throttled.

Reads use `GetSortedAsync(false, count)` with `count ≤ 100`, isolated in `pcall`.

---

## 6. Trade audit & receipts

**`TradeAudit_v1`** — one immutable key per completed trade:
```lua
{
  type = "trade", at = 1760000000,
  a = 1234, b = 5678,
  offerA = { pets = {"uid..."}, coins = 0, gems = 12, tokens = 40 },
  offerB = { pets = {}, coins = 250000, gems = 0, tokens = 0 },
  taxBurned = 2,
}
```
Retention: keep 90 days via a scheduled cleanup job (not implemented in this slice). Query by player by
scanning keys is expensive; for support, store the trade id in a per-player ring buffer in the profile
(`trading.recentTradeIds`, milestone 2).

**`Receipts_v1`** — `ProcessReceipt` idempotency:
1. If `profile.shop.purchases[receiptId]` → `PurchaseGranted`.
2. Else if `Receipts_v1[userId .. "_" .. receiptId]` → `PurchaseGranted`.
3. Grant server-side, record both, `save(force)` immediately, then return `PurchaseGranted`.

Unknown product ids return `NotProcessedYet` and log a warning: never silently consume Robux.

---

## 7. Recovery & deletion

- **Restore**: DataStore version history (30 days) in the Creator Dashboard, or replay `TradeAudit_v1`
  for trade disputes.
- **GDPR/right-to-be-forgotten**: remove `u_<userId>`, both leaderboard entries, and any
  `t_*` audit keys referencing the id. This requires a dashboard export or an admin tool (milestone 2).
- **Corruption**: if `migrate` throws, kick with a data-error message and do **not** overwrite the key.

---

## 8. Write budget summary (60 players, steady state)

| Source | Writes/min |
|--------|-----------:|
| Autosave (60 s, staggered) | ~60 |
| Trades (rare) | ~1–3 |
| Purchases (rare) | ~0–2 |
| Leave saves | ~5–10 |

Ordered leaderboard writes add 3 per save (~180/min), which is why they are wrapped in `pcall` and skipped
on throttling. Batched DataStore (`DataStoreService:GetGlobalDataStore`) is not used for profiles because
per-player keys unlock the 4 MB ceiling and version history.
