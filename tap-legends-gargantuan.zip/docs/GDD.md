# TAP LEGENDS: GARGANTUAN
### Game Design Document v1.0 — Roblox simulator (Pet Simulator 99 × Tap Simulator Reborn)

**Status:** vertical-slice architecture implemented (`src/`), design locked for milestone 2
**Owner:** Design + Client + Backend
**Last updated:** 2026-11-10

> The three UI reference images from the brief (`moment-w_SC2UY9ZyI-63-equipping-best-pets.webp`,
> `images (77).jpeg`, `Pet-Sim-99---In-Game-Exclusive-Shop.webp`) were not present in this workspace, so
> the UI specification below is derived from the written description of each reference (right-side stat
> panel with Power/Gems/Weight/Level; grid inventory with side-scrolling categories; rounded exclusive
> shop with green Robux buttons). The improvements you asked for are specified explicitly in §11.

---

## 1. Vision

**One sentence:** a tap-driven pet collector where your *team composition* — not just your best pet —
decides your power, and where every hour has something to do and every four hours has something to
fight together.

**Pillars**

1. **Tap first, think second.** The moment-to-moment loop is one thumb, instant feedback, zero friction.
2. **Teams, not trophies.** Synergy makes 8 identical-element pets beat 8 stronger mismatched ones.
   Collection breadth and team building both matter.
3. **Honest gacha.** Every egg shows real odds and a pity bar that is actually enforced server-side.
4. **The server is the boss.** Raids and hourly events turn solo tapping into a shared clock.

**Audience:** 9–14 primary (Roblox simulator core), 14–17 secondary (traders/collectors).
**Platforms:** mobile-first (portrait + landscape), PC, console-safe inputs. Target 30 FPS on a 2019
mid-range Android with 12 players in a raid.
**Session shape:** 6–12 minute sessions, 2–4 sessions/day; hourly events and 4-hourly raids supply the
appointment mechanics.

**What we are deliberately not doing:** no PvP combat, no permadeath, no pet hunger/decay, no
"rebirth wipes your pets". Collections are sacred.

---

## 2. Core loops

### 2.1 Moment-to-moment (0–30s)
```
tap → damage number → coins → buy tap upgrade / hatch egg → bigger number → tap
```
Server-validated: the client says "I tapped", never "I dealt 4.2M damage".

### 2.2 Session loop (5–15 min)
```
Claim boosts → tap toward next world → hatch eggs (pity bars in view)
→ auto-equip stronger pets → check Synergy → enchant what's weak
→ raid/event if the clock says so → rebirth when the bar fills
```

### 2.3 Daily loop
```
Daily VIP/token bonus → 3–5 hourly events → 2–3 raids → trade duplicates with friends
→ push one rebirth tier → log off with pets auto-tapping
```

### 2.4 Weekly / long-term loop
```
New zone → new element/family to collect → rebuild synergy team → re-enchant
→ Titanic/Gargantuan chase → Rebirth milestones → season pass cosmetics
```

### 2.5 The prestige valve (Rebirth)
Coins inflate; pets do not reset. Rebirth converts **coins** into **permanent multipliers + Tokens** and
resets only the tap-upgrade economy. This is the classic simulator pressure valve: the world gets more
expensive, the player gets multiplicatively stronger, and the collection they paid for is never taken away.

---

## 3. Progression systems

### 3.1 Zones (islands)

| # | Zone | Unlock (coins) | Rebirths | Egg | Boss | Identity |
|---|------|---------------:|---------:|-----|------|----------|
| 1 | Sunny Meadow | 0 | 0 | Meadow | Meadow Mole | onboarding, Nature/Beast |
| 2 | Coral Bay | 25,000 | 0 | Coral | Tidebreaker | Water, first pet slots |
| 3 | Emberpeak | 250,000 | 0 | Ember | Caldera King | Fire/Dragon synergy intro |
| 4 | Neon City | 2,500,000 | 1 | Neon | Mainframe Prime | Tech, auto-tap relics |
| 5 | Frost Hollow | 25,000,000 | 2 | Frost | Aurora Wyrm | Light/Angel, first Titanic pity |
| 6 | Void Garden | 250,000,000 | 4 | Void | Null Bloom | Shadow economy |
| 7 | **Shadow Realm** | 0 | 3 | Umbral | The Curator | **ENCHANTING HUB** |
| 8 | Cosmic Spire | 1,000,000,000 | 10 | Cosmic | Stellar Devourer | Cosmic, Gargantuan chase |
| 9 | Gargantuan's Rest | 50,000,000,000 | 25 | Titan | Gargantuan | endgame raid boss |

Coin cost grows ~×12 per zone while pet power grows ~×3.2: the gap is closed by **rebirth multipliers**,
which is the intended pressure to prestige rather than grind a wall.

### 3.2 Egg odds and pity

Class weights are per-hatch; variants (gold/rainbow/shiny) roll **independently and stack**. Pity is a
hard per-class guarantee tracked per egg and preserved across rebirths.

| Egg | Cost | Huge | Titanic | Gargantuan | Huge pity | Titanic pity | Garg pity |
|-----|-----:|-----:|--------:|-----------:|----------:|-------------:|----------:|
| Meadow | 100 coins | 0.28% | 0.02% | — | 200 | — | — |
| Coral | 5,000 | 0.45% | 0.05% | — | 300 | — | — |
| Ember | 60,000 | 0.70% | 0.09% | — | 400 | 4,000 | — |
| Neon | 750,000 | 1.00% | 0.18% | — | 500 | 5,000 | — |
| Frost | 9,000,000 | 1.40% | 0.28% | 0.005% | 650 | 6,500 | 25,000 |
| Void | 120,000,000 | 2.00% | 0.39% | 0.010% | 800 | 8,000 | 30,000 |
| Umbral | 250 gems | 2.60% | 0.55% | 0.015% | 1,000 | 10,000 | 15,000 |
| Cosmic | 1.5B | 3.30% | 0.82% | 0.025% | 1,200 | 12,500 | 8,000 |
| Titan | 400 gems | 5.50% | 1.35% | 0.080% | 1,500 | 15,000 | 3,000 |
| **Magic (R$)** | 99 R$ | 8.00% | 1.90% | 0.10% | **25** | **150** | **2,000** |
| **Super Drop (R$)** | 49 R$ | 5.50% | 0.50% | 0.01% | **40** | **400** | — |

Design intent: early Huge odds are generous (0.28% with a 200-hatch guarantee) because Huge is a **6×**
pet, not an account-ending one. The chase is Gargantuan (150× power + ×2.25 team aura, best-only),
which is pity-only at 1/1,250–1/50,000 depending on zone.

**Variant odds** (Meadow → Titan): gold 10%→18%, rainbow 2%→5%, shiny 0.4%→1.2%, all independent.
A "Rainbow Shiny Huge" is a legitimate jackpot: variant bonuses stack (gold +0.5, rainbow +1.5, shiny +3.0
→ ×6 personal power on the same pet).

### 3.3 Classes and variants (the "rarity" ladder)

Class is a **rolled property** (like PS99's Huge variants), not a separate pet. One dex entry can produce
a Normal Sproutling and a Rainbow Shiny Huge Sproutling.

| Class | Personal power | Team aura (non-stacking) | Enchant slots | Hit rate |
|-------|---------------:|-------------------------:|--------------:|----------|
| Normal (Standard) | ×1 | — | 1 | common |
| **Huge** | ×6 | +20% tap damage | 2 | 1/100 – 1/25,000 |
| **Titanic** | ×30 | +50% tap damage | 3 | 1/1,000 – 1/100,000 |
| **Gargantuan** | ×150 | **+125% tap damage** | 4 | pity chase (1/1,250 – 1/50,000) |

Auras do **not** stack: only the best class aura on the team applies. Equipping 100 Huges is therefore
a power play, not a degenerate one.

### 3.4 Pet multiplier math (implemented in `MultiplierEngine.lua`)

```
petPower(pet)   = basePower
                × class.powerMultiplier                 (1 / 6 / 30 / 150)
                × (1 + Σ variantBonus)                  (gold .5, rainbow 1.5, shiny 3.0; capped at +9)
                × (1 + 0.04 × (level − 1))              (L50 = ×2.96)
                × (1 + item "Might" enchants)           (up to +60%)
                × (1 + relic/curse petPower)            (Cursed Band −25%)

teamPower       = Σ petPower(each equipped pet)
effectivePower  = teamPower                                    if ≤ 20,000
                = 20,000 × (teamPower / 20,000)^0.88            if > 20,000   (soft cap)

PetMultiplier   = 1 + effectivePower / 100
```

The soft cap is what lets us ship 250-pet teams without the economy exploding: at 10× the cap, gains are
`10^0.88 ≈ 7.6×` instead of 10×. It is disclosed in the UI ("Soft cap reached — diminishing returns").

**Worked example (mid-game):** 30 Cinder Drakes (base 45), all Fire/Dragon, level 1, Standard.
- teamPower = 30 × 45 = **1,350** → PetMultiplier = 1 + 13.5 = **×14.5**
- Synergy = ×4.5 (see §3.5)
- Rebirths 5 → ×3.25
- Tap upgrade 60 → flat = (1 + 60) × 1.5² = **137.25**
- **Damage/tap = 137.25 × 14.5 × 4.5 × 3.25 ≈ 29,100**

### 3.5 Synergy (new system)

Synergy is **share-based**, so it works for an 8-slot starter team and a 250-slot endgame team.

- The **dominant element** counts in full; every other qualifying element counts at **25%**.
- The **dominant family** (Dragon, Cat, Tech, ...) counts in full; others at 25%.
- Combined synergy is capped at **×8**.

| Element share | Min pets | Element multiplier | Family share | Min pets | Family multiplier |
|--------------:|---------:|-------------------:|-------------:|---------:|------------------:|
| 25% | 2 | ×1.10 | 25% | 2 | ×1.08 |
| 50% | 3 | ×1.25 | 50% | 3 | ×1.20 |
| 75% | 4 | ×1.55 | 75% | 4 | ×1.45 |
| 90% | 6 | ×2.00 | 90% | 6 | ×1.80 |
| 100% | 8 | **×3.00** | 100% | 8 | **×2.50** |

**Mono-team (8/8 Nature Beast):** 1 + (3.00−1) + (2.50−1) = **×4.5**
**Rainbow team (2 each of 4 elements, mixed families):** 1 + 0.175 + 0.24 = **×1.415**

That is a **3.2× gap** for the same collection power — the system creates a real team-building decision
without requiring a spreadsheet. The inventory can sort by "Synergy" (marginal gain if added), which is
computed per (element, family) pair, not per pet (0.4 ms for 20k pets instead of ~90 ms).

### 3.6 Rebirth

```
requirement(n)  = 1,000,000 × 3.2^n
multiplier(n)   = 1 + 0.35n + 0.02n²
tokenReward     = floor(5 × (n+1)^1.35)
```

| Rebirths | Coins required | Permanent multiplier | Tokens earned | Unlocks |
|---------:|---------------:|---------------------:|--------------:|---------|
| 1 | 1.0 M | ×1.37 | 5 | Neon City prep |
| 2 | 3.2 M | ×1.78 | 13 | Frost Hollow |
| 3 | 10.2 M | ×2.23 | 22 | **Shadow Realm** |
| 5 | 335 M | ×3.25 | 44 | +2 pet slots, relic slot 2 |
| 10 | 112 B | ×6.50 | 111 | Cosmic Spire +2 slots |
| 20 | 1.15 × 10^15 | ×16.0 | 285 | +8 slots cumulative |
| 30 | 1.3 × 10^19 | ×29.5 | 492 | — |
| 50 | — | ×68.5 | 984 | — |
| 100 | — | ×236 | 2,553 | cap |

Rebirth **never** removes pets, relics, enchants, pity counters or zone unlocks. It resets coins and the
tap-upgrade level only.

### 3.7 Relics (tap behaviour, not just numbers)

Equipped in 1–4 slots (free / R5 / R12 / R25). Every relic changes *how* you tap.

| Relic | Tier | Effect | Source |
|-------|------|--------|--------|
| Ember Gauntlet | Rare | +35% tap damage, every **10th** tap ×3 | raid / forge |
| Ring of Greed | Uncommon | +25% coins | zone drop |
| Tidal Aegis | Rare | +2 team slots | forge |
| Chrono Fang | Epic | auto-taps 3/s | raid |
| Prism Heart | Epic | +8% crit, +50% crit damage | event |
| Void Sigil | Legendary | taps strike 2 extra raid targets | raid rank 3+ |
| Worldroot Totem | Legendary | +10% synergy, +5% team power | forge |
| Echo Loop | Rare | each tap echoes once, +1 auto-tap/s | zone drop |
| Cursed Band | Mythic | **×2.5 tap damage, pets −25% power** | forge |
| Gargantuan Heart | Mythic | +75% tap damage, +50 flat | Gargantuan boss, top damage |

Forge cost starts at 3 Tokens + 150 gems, growing ×1.2 / ×1.1 per forge. Pity: 25 forges without an
Epic+ guarantees an Epic+.

### 3.8 Enchanting (Shadow Realm)

Enchant slots: Normal 1, Huge 2, Titanic 3, Gargantuan 4, relic 2.

| Stat | I | II | III | IV | V |
|------|---|---|-----|----|---|
| Might (pet power) | +5% | +10% | +20% | +35% | +60% |
| Force (tap) | +4% | +8% | +15% | +25% | +45% |
| Fortune (coins) | +5% | +10% | +18% | +30% | +50% |
| Crystal (gems) | +4% | +8% | +15% | +25% | +40% |
| Luck (odds/pity) | +3% | +6% | +12% | +20% | +35% |
| Harmony (synergy) | +2% | +5% | +9% | +15% | +25% |
| Edge (crit chance) | +1% | +2% | +4% | +7% | +11% |

Tier weights: 55 / 28 / 12 / 4.4 / 0.6. Reroll cost starts at 250 gems, ×1.18 per reroll on the item;
locking a modifier costs ×3 per locked slot. Pity: 40 rerolls without tier IV+ guarantees tier IV+.

### 3.9 Fusion (levels)

3 identical pets (same `id` + class, unequipped) → one pet levels up. Level 50 cap, +4% power per level.
Fusion is the "junk sink": duplicate Normals become meaningful instead of inventory noise.

---

## 4. Currencies & economy

| Currency | Earned from | Spent on | Tradeable | Robux? |
|----------|-------------|----------|:---------:|:------:|
| **Coins** | taps, events, raids | tap upgrades, eggs, zones | yes (trades) | no |
| **Gems** | duplicates, events, raids, Shadow Realm | enchants, crit upgrades, relic forging, Umbral/Titan eggs | yes | no |
| **Tokens** | **rebirths, raids, events only** | relic forging; **primary trade currency** | **yes** | **never** |
| Event Tokens | hourly events | season shop | no | pouch only |
| Robux | — | Super Drops, Magic Eggs, passes, boosts | — | — |

**Inflation controls**
1. Rebirth resets coins (the biggest sink in the game).
2. Egg costs scale ×12/zone vs ×3.2 power/zone.
3. Tap upgrades grow ×1.17/level with a hard level cap of 400.
4. Fusion consumes 3 pets for +1 level.
5. Trade tax: **5% of traded Tokens is burned**, not transferred.
6. Boosts of the same type add (capped 3 stacks) instead of multiplying.

**Target ratios (design health):** a mid-game player's coin income should buy ~1 egg per 90s of active
tapping; a rebirth should take 20–45 min at the intended zone; 1 Token ≈ 4–6 minutes of active play.

---

## 5. Trading

Tokens are the high-tier trading currency. Trading is **server-authoritative with escrow**.

**Rules**
- Invite → accept → each side offers up to 50 pets + coins/gems/tokens → both confirm → atomic swap.
- Pets must be **unequipped and unlocked**. Locked pets can never enter a trade.
- Any offer change clears **both** confirmations (the classic scam vector).
- **Value band:** if the two sides differ by >35%, the first confirm only warns; a second confirm is required.
- 20s cooldown, 30 trades/hour/player.
- Every completed trade is written to `TradeAudit_v1` with both offers.

**Anti-RMT**: Tokens cannot be bought with Robux. Selling Tokens for real money therefore requires a
player to first earn them in-game, converting RMT into ordinary account farming — which our other
controls (no guest access, trade audit, funnel bans) can detect.

---

## 6. Server-wide boss raids (every 4 hours)

```
HP = 2,500 + 300 × Σ(damagePerTap of all players in server)
```
HP is measured against a 5-minute window at ~10 taps/s, so the fight lands at 55–70% of theoretical
maximum output: a full server wins comfortably, a half-idle server has to try.

| Phase | Duration | Behaviour |
|-------|----------|-----------|
| Idle | until schedule | countdown broadcast |
| Windup | 60s | boss name/HP shown, players pool |
| Active | 300s | all tap/auto-tap damage is applied to the boss |
| Result | 15s | contribution rewards, exclusive egg rolls |

**Contribution tiers** (share of total damage): 2% / 10% / 25% / 50%.
Rewards: coins = 75% of damage dealt, gems 5 + 15×tier, Tokens = damage/1M × 0.25 + tier (on kill),
exclusive egg chance 0% / 15% / 45% / 100% by tier. Participation floor: 0.5% share or no rewards.

**Worked example:** 8 players, average 1,200 damage/tap → Σ = 9,600 → HP = 2,500 + 2.88M = 2.88M.
A player tapping 10/s for 300s deals ~3.6M if they never miss; realistic output ~2M, so the server kills it
with ~70% participation. One idle player cannot solo it; one strong player can carry a small server.

---

## 7. Hourly events (minigames)

Rotation every hour at :00, 12-minute window, 3-minute warning:

| Event | Fantasy | Mechanic (server-derived) | Rewards |
|-------|---------|---------------------------|---------|
| **Lucky Block** | smash blocks | taps deal damage to a block swarm; each break rolls coins/gems | coins ×2.5, gems 4 |
| **Coin Arcade** | **shoot pets at targets** | each tap launches your equipped pets at a target wall; damage = hit score | coins ×2, gems 2 |
| **Meteor Shower** | shatter meteors | taps split meteors; gem-heavy | coins ×1.5, gems 6 |
| **Synergy Surge** | team power spike | **all Synergy multipliers ×2** for the window (rebuilds cached contexts) | coins, gems 3, tokens 2 |

All four consume the same authoritative damage stream as raids and taps, so there is no extra exploit
surface. Rewards are distributed at event end by damage share plus a base participation reward.

---

## 8. Monetization

**Principle:** sell *speed, breadth and cosmetics*, never exclusive raw power. Pity and caps keep paying
players on the same curve.

| Product | Type | R$ | Contents |
|---------|------|----|----------|
| VIP | pass | 399 | +25% coins, +1 slot, +1 auto-tap/s, tag, daily Tokens |
| Auto-Tap | pass | 299 | server-side tapping while active |
| +10 Team Slots | pass | 349 | +10 permanent slots |
| +25 Team Slots | pass | 699 | +25 permanent slots |
| Lucky Pass | pass | 249 | −15% pity requirement |
| Shiny Hunter | pass | 499 | 2× Shiny odds |
| Magic Egg | product | 99 | 1 hatch, ≥ Rainbow floor, Huge pity 25 |
| Magic Egg ×5 | product | 399 | 5 hatches |
| Super Drop ×10 | product | 49 | 10 hatches, Titanic pity 400 |
| Event Token Pouch | product | 79 | 250 event tokens |
| 2× Coins 15m | product | 59 | server boost, adds (never multiplies) with other coin boosts |

**Trust features**
- Exclusive eggs show **live pity bars** sourced from server counters (§11.5).
- Every purchase is receipt-idempotent (`ProcessReceipt` + `Receipts_v1`), granted server-side only,
  and saved immediately.
- Product ids live in `Config/Products.lua`. Ids of `0` are surfaced in the UI as "not configured yet"
  rather than silently failing.
- Design guardrail (not yet enforced in code): `maxPaidPowerShare = 0.35` — a single purchase should not
  exceed 35% of the buyer's total power. Tune paid egg pools against this before enabling ids.

---

## 9. UI / UX specification

### 9.1 Screen map

```
┌──────────────────────────────────────────────────────────────┐
│ Currencies        TAP POWER (big)          [Raid banner]     │
│ Coins/Gems/        Pets ×.. Synergy ×..    [Event banner]    │
│ Tokens/Event       Rebirth ×..                               │
│                                                              │
│ [Inventory]                                          ┌─────┐ │
│ [Shop]                                               │ PET │ │
│ [Rebirth]                                            │ 3D  │ │
│                                                      │stats│ │
│                    ┌─────────┐                       │     │ │
│                    │   TAP   │                       └─────┘ │
│                    └─────────┘                               │
└──────────────────────────────────────────────────────────────┘
```

### 9.2 Pet detail panel (reference: right-side stats panel)

**Keep:** the clear right-side stat stack — Power, Gems bonus, Weight, Level progress.
**Improve:**
1. **Live 3D render** in a `ViewportFrame` instead of a static image. The model orbits slowly; it is built
   procedurally from the pet's element colour today, swappable for real art per dex entry later.
2. **Quick Compare tooltip** on hover (desktop) / long-press (mobile) over an unequipped pet:
   `+12.4K power (+38%) vs Tide Pup` and `Synergy +0.35× with this team`, computed with the same engine
   the server uses (`PetDetailPanel:compare`). The comparison target is the weakest equipped pet, so the
   number answers the actual question: "who does this replace?"
3. Class + variant pills use the rarity colours; enchants are listed by name and tier.

### 9.3 Massive inventory (reference: grid + side categories)

**Keep:** dense grid, side-scrolling category nav (Pets / Eggs / Enchants / Potions / Relics).
**Improve:**
1. **Custom folders** (up to 30), each with a count; a pet belongs to exactly one folder so trade/equip
   validation stays unambiguous.
2. **Advanced filters and sorts** — Search, Element, Rarity, plus sorts: **Power, Synergy, Element,
   Tap Multiplier, Rarity, Level, Newest, Name**. Synergy and Tap Multiplier sorts are powered by
   `InventoryQuery` + `MultiplierEngine.petContribution`, and are computed per element/family group so
   20k-pet inventories sort in well under a frame.
3. **Select mode** with an explicit slot counter ("12 / 30 slots") and EQUIP SELECTED.
4. **Server-side paging** endpoint (`GetInventoryPage`) for collections beyond the page size; the server
   and client share one ordering module, so they cannot disagree.

### 9.4 Exclusive shop (reference: rounded panels, green Robux buttons)

**Keep:** vibrant rounded cards, clear premium currency, green Robux buttons.
**Improve:** a **real Pity Timer bar** on every exclusive egg:
- one bar per tracked class (Huge / Titanic / Gargantuan),
- `counter / hardPity` fill, numeric progress, and a gold **"GUARANTEED NEXT HATCH"** state,
- odds row showing `Huge 1 in 13 | Titanic 1 in 53`,
- bars are fed by `ShopState` from the server; they cannot drift from the hatch roll.

### 9.5 Trade window (milestone 2 UI, server complete)

Two-column layout, both offers mirrored, per-item power, value band warning banner, "Both must confirm"
state, 30s timeout. Server endpoints (`TradeAction`) are implemented and audited; the client panel is the
remaining work.

### 9.6 Motion & feel

- Tap: 3-frame scale punch on the button, damage number rises and fades (pooled, 90 max).
- Crits: gold + larger + 1.25× horizontal jitter; overcharge: orange + shake.
- Hatch: egg wobble → burst → card flip reveals class colour; class rarity adds screen-edge glow.
- Rebirth: full-screen white flash + particle ring + multiplier count-up.
- Haptics on mobile via `HapticService` (respecting the OS reduce-motion setting).

### 9.7 Accessibility & mobile

- Minimum tap target 44 px; tap button 190 px (scaled 0.72–1.15 by viewport).
- Colour is never the only signal: class shown as text pill + colour, crits add size, pity shows numbers.
- All text is Gotham with ≥11 px at reference resolution; damage numbers are numerals only.
- Settings scaffold: music, SFX, damage numbers, auto-equip.
- Portrait: panels stack, inventory becomes full-screen overlay (already a modal).

### 9.8 Performance budgets

| Budget | Target |
|--------|--------|
| Frame time, 12 players + raid | ≤ 22 ms @ 30 FPS mid Android |
| Remotes per player per second | ≤ 25 (taps ~22 + state pushes coalesced) |
| Inventory sort, 20k pets | ≤ 8 ms (group-cached synergy) |
| Damage number labels alive | ≤ 90 pooled |
| Initial state payload | ≤ 180 KB (full collection; paged endpoint beyond 2k pets) |
| DataStore writes per player | 1/min autosave + on change (staggered) |

---

## 10. Technical architecture

### 10.1 Module map

```
ReplicatedStorage/Shared
  Config/  Balance, Rarities, Elements, Pets, Eggs, Relics, Enchants, Zones, Products, GameConfig
  Modules/ MultiplierEngine, TapEngine, PityEngine, EggMath, InventoryQuery, NumberFormatter
  Net/     Remotes
ServerScriptService/Server
  Main.server.lua                  boot, ctx, state pushes, inventory paging, folders
  Services/ DataService            profiles, session lock, autosave, leaderboards, audit
            BuildService           cached MultiplierEngine context per player
            TapService             tap validation, coins, auto-tap, upgrades
            PetService             hatch, equip, auto-equip, fuse, duplicates
            RebirthService         rebirth, zone unlocks
            EnchantService         Shadow Realm rerolls + pity
            RelicService           forging + equip slots
            ShopService            receipts, entitlements, pity payloads
            TradeService           escrow trading + audit + tax
            RaidService            4-hourly boss, contribution rewards
            EventService           hourly rotation, synergies, rewards
StarterPlayerScripts/Client
  TapController.client.lua         HUD, input, feedback, panel wiring
  UI/ Theme, PetDetailPanel, InventoryScreen, ShopPanel
```

**Layering rule:** services never `require` each other at module scope; they talk through `ctx.services`.
The engine modules are pure (no Roblox APIs) so they are unit-testable and can run on both sides.

### 10.2 Remote surface

| Remote | Kind | Direction | Validation |
|--------|------|-----------|------------|
| `Tap` | event | C→S | token bucket, profile exists, cooldown; no payload trusted |
| `TapResult` | event | S→C | server-computed damage/coins |
| `StateSync` | event | S→C | coalesced per frame |
| `InventorySync` | event | S→C | on structural change |
| `Toast` / `TradeState` / `RaidState` / `EventState` / `ShopState` | events | S→C | display only |
| `Hatch(eggId, count)` | fn | C→S | egg exists, zone unlocked, funds, count 1–25 |
| `EquipPets(uids)` | fn | C→S | ownership, duplicates, slot cap |
| `AutoEquipBest` / `FusePets` / `BuyUpgrade` | fn | C→S | ownership, caps, currency |
| `Rebirth` | fn | C→S | requirement, max rebirths |
| `RerollEnchant` | fn | C→S | ownership, slot rules, lock cost, gems |
| `ForgeRelic` / `EquipRelic` | fn | C→S | ownership, slots, currencies |
| `TradeAction(action, payload)` | fn | C→S | escrow state machine, revalidation at execute |
| `GetInventoryPage(options)` | fn | C→S | clamped page size, server-side sort |
| `SetFolder(action, payload)` | fn | C→S | cap 30, name length, ownership |
| `GetEventState()` | fn | C→S | read-only |

### 10.3 Server authority checklist

- [x] Damage, crit, overcharge and coin values computed on the server only.
- [x] Tap rate limited with a burst bucket; repeat offenders kicked; rejections counted.
- [x] Ownership/currency revalidated inside every transaction (equip, hatch, trade, forge).
- [x] Trade changes invalidate both confirmations; execute revalidates both sides.
- [x] Receipts idempotent and saved immediately after a purchase grant.
- [x] Pity counters server-owned; the client only renders them.
- [x] Auto-tap is server-originated and cannot be triggered by clients.
- [ ] Milestone 2: structured telemetry for rejected taps, hatch rates vs. published odds, trade velocity.

### 10.4 Replication strategy

- Taps reply immediately (`TapResult`, ~20/s) for feel.
- Structural changes (`StateSync`, `InventorySync`) are coalesced with `task.defer` so a trade or rebirth
  cannot cause three full payloads in one frame.
- Raid state broadcasts 1/s; event state on transitions only.
- Inventory page endpoint exists for accounts above ~2,000 pets; the full sync is the vertical-slice path.

---

## 11. Required DataStores (summary)

Full schema, sizes, limits and migration plan: **[docs/DATASTORES.md](DATASTORES.md)**.

| Store | Type | Key | Contents | Writes |
|-------|------|-----|----------|--------|
| `PlayerProfiles_v1` | DataStore | `u_<userId>` | the whole player profile + session lock | 1/min autosave, on major action, on leave |
| `Leaderboard_Rebirths_v1` | OrderedDataStore | `<userId>` | rebirth count | per save |
| `Leaderboard_Power_v1` | OrderedDataStore | `<userId>` | damage/tap × 100 | per save |
| `Leaderboard_BossDamage_v1` | OrderedDataStore | `<userId>` | lifetime boss damage | per save |
| `TradeAudit_v1` | DataStore | `t_<unix>_<rand>` | immutable trade log | per completed trade |
| `Receipts_v1` | DataStore | `<userId>_<receiptId>` | purchase idempotency | per purchase |

Profile sections: currencies, stats, rebirth/tap/crit levels, pets (uid map), equipped (ordered uid array),
folders, relics (owned/equipped/enchants/pity), `eggPity` per egg/class, `enchantPity`, zones, boss,
trading counters, shop entitlements/purchases, events, boosts, settings.

---

## 12. LiveOps & KPIs

**Calendar:** hourly events (always), 4-hourly raids (always), weekend ×2 coins boosts, monthly season
(cosmetic track + 2 pets), seasonal event reskins of Lucky Block.

| KPI | Target | Notes |
|-----|--------|-------|
| D1 retention | 38% | first Huge within ~10 min is the hook |
| D7 | 18% | zone 4 + first rebirth |
| Average session | 9 min | events stretch it |
| Rebirth conversion (D1) | 55% | rebirth at ~1M coins |
| Payer conversion | 2.5% | Magic Egg pity 25 is the entry offer |
| ARPPU | R$ 240 / month | passes + egg bundles |
| Trade participation (D7) | 25% | Tokens must feel earned |
| Raid participation (DAU) | 45% | 4-hour cadence |
| Support tickets / 1k DAU | < 4 | receipts + audit protect this |

---

## 13. Risks & mitigations

| Risk | Impact | Mitigation |
|------|--------|------------|
| Exponential inflation | economy collapse | rebirth coin reset, ×12 zone costs, boost add-cap, token tax |
| Synergy makes old pets useless | collection regret | share-based tiers, secondary groups count 25%, fusion |
| Paid eggs perceived as pay-to-win | review bombing | pity bars, published odds, no Tokens for Robux, power-share cap |
| Trade scams/dupes | trust loss | escrow, double confirm, revalidation, audit log |
| Raid boss trivialised or impossible | dead feature | HP scales from live server power; participation floor |
| Data loss on shutdown | catastrophic | session lock, autosave, BindToClose flush, receipt persistence |
| Exploit via tap spam | economy break | token bucket, server RNG, kick threshold, telemetry next |
| Mobile frame drops in raids | churn | pooled numbers, 1 Hz raid broadcast, 22 remotes/s cap |

---

## 14. Roadmap

**M1 (this slice, implemented):** shared math + tests, config, profile/persistence, tapping, hatching,
team equip, rebirth, enchants, relics, trading, raids, events, shop receipts, HUD/inventory/detail/shop UI.

**M2:** real pet models (replace procedural viewport), trade window UI, season pass, server-side paging
default, accessibility settings, telemetry, mobile haptics, egg opening animation pass, merge UX
(select-all duplicates by rarity), relic loadout UI.

**M3:** guilds/co-op raids, pet index (collection book with completion rewards), auction house for Tokens,
UGC cosmetic relics, creator code shop, localization (ES/PT/FR/DE), A/B pricing tests.

---

## 15. Appendix — tuning knobs (all in `Config/Balance.lua`)

| Knob | Default | Effect |
|------|---------|--------|
| `Tap.baseTap` | 1 | floor damage |
| `Tap.upgrade.costGrowth` | 1.17 | upgrade curve steepness |
| `Tap.upgrade.milestoneEvery` | 25 | step multiplier cadence (×1.5 each) |
| `Tap.server.maxTapsPerSecond` | 22 | sustained tap cap |
| `Tap.server.burstAllowance` | 34 | burst tolerance |
| `Tap.crit.damageMultiplier` | 5 | crit payoff |
| `Team.petPowerScale` | 100 | how fast team power becomes a multiplier |
| `Team.softCapStart` | 20,000 | diminishing-returns threshold |
| `Team.softCapExponent` | 0.88 | severity of the cap |
| `Synergy.maxMultiplier` | 8 | hard synergy cap |
| `Rebirth.requirementGrowth` | 3.2 | prestige cadence |
| `Rebirth.linear/quadratic` | 0.35 / 0.02 | multiplier curve |
| `Economy.tradeTaxPercent` | 5% | token sink |
| `Raid.powerHealthRatio` | 300 | boss difficulty scaling |
| `Raid.durationSeconds` | 300 | fight length |
| `Events.intervalSeconds` | 3,600 | event cadence |

**QA test plan for the math (implemented in `tests/`):** pet power across classes/variants/levels, soft
cap, mono vs mixed synergy, marginal synergy, rebirth curve, enchant aggregation, relic stacking and
overcharge rules, boost add-cap, full context product, context crit clamps, auto-tap, tap crits,
overcharge, extra hits, rate limiter burst/refill, upgrade cost curve, pity ramp/hard guarantee/luck
reduction, egg class pity, variant stacking, hatch validation, inventory filters/sorts/paging/folders,
number formatting. Run: `luau tests/run_tests.luau` (58 cases).
