# Tap Legends: Gargantuan

A Roblox simulator that merges the **tapping loop, rebirths and trading** of Tap Simulator Reborn with
the **massive pet teams, rarity ladder and spectacle events** of Pet Simulator 99 — plus three new systems:
**Synergy teams**, **server-wide boss raids**, and **behaviour-changing relics**.

This repository is the design + architecture slice: a complete GDD, a full datastore specification, and
production-shaped Luau for the server, client UI and — most importantly — the **tapping and pet multiplier
math**, which is pure, deterministic and unit tested against the real config.

---

## Start here

| Document | What it covers |
|----------|----------------|
| [docs/GDD.md](docs/GDD.md) | Vision, loops, zones, eggs, rarity, synergy math, rebirth table, relics, enchants, economy, trading, raids, events, monetization, UI/UX spec, architecture, KPIs, roadmap |
| [docs/DATASTORES.md](docs/DATASTORES.md) | Every DataStore, the profile schema, session locking, migration, audit, receipts, budgets |
| [src/shared/Modules/MultiplierEngine.lua](src/shared/Modules/MultiplierEngine.lua) | **Pet multiplier math**: pet power, soft cap, synergy, rebirth, enchants, relics, full context |
| [src/shared/Modules/TapEngine.lua](src/shared/Modules/TapEngine.lua) | **Tapping math**: crits, overcharge, extra hits, coins, DPS projections, burst rate limiter |

---

## Repository layout

```
src/
  shared/                      ReplicatedStorage.Shared
    Config/                    Balance, Rarities, Elements, Pets, Eggs, Relics,
                               Enchants, Zones, Products, GameConfig
    Modules/                   MultiplierEngine, TapEngine, PityEngine, EggMath,
                               InventoryQuery, NumberFormatter   (pure Luau)
    Net/Remotes.lua            single remote registry
  server/                      ServerScriptService.Server
    Main.server.lua            boot + context + state pushes + paging + folders
    Services/                  Data, Build, Tap, Pet, Rebirth, Enchant, Relic,
                               Shop, Trade, Raid, Event
  client/                      StarterPlayerScripts.Client
    TapController.client.lua   HUD, tap input, banners, toasts
    UI/                        Theme, PetDetailPanel (3D + quick compare),
                               InventoryScreen (folders/filters), ShopPanel (pity bars)
tests/                         Luau spec suite (pure modules, real config)
docs/                          GDD + data architecture
```

---

## Running the math tests

The engine modules use **no Roblox APIs**, so they run in the standalone Luau CLI.

```bash
# macOS / Linux (binary from github.com/luau-lang/luau/releases)
luau tests/run_tests.luau
```

58 cases covering pet power, soft caps, mono/mixed synergy, rebirth curves, enchant aggregation, relic
stacking and overcharge rules, boost caps, crit/overcharge resolution, rate-limiter burst/refill, pity
ramps and guarantees, egg rolls and variant stacks, inventory filters/sorts/paging/folders, and formatting.

## Running in Roblox

1. Install [Rojo](https://rojo.space) (`aftman install` or `cargo install rojo`).
2. `rojo serve` in this repository root and connect from the Roblox Studio Rojo plugin
   (mapping in `default.project.json`).
3. Press **Play**. The server boots, creates remotes, loads profiles and spawns the HUD.

No asset ids are required: the pet detail viewport builds a procedural 3D pet from the element colour, so
the UI renders before any art exists. Replace `PetDetailPanel:renderPet` with real models per dex entry.

### Before publishing monetization
`src/shared/Config/Products.lua` ships with `productId = 0` placeholders. Create the passes/products in the
Roblox Creator Dashboard, paste the ids in, then test `ProcessReceipt` in a real server (Studio does not
complete purchases).

---

## What is implemented in this slice

- **Server-authoritative tapping** with token-bucket rate limiting, server RNG for crits/overcharge,
  auto-tap, coins tied to damage.
- **Pet team math** with class/variant/level/enchant multipliers, a soft cap for 250-pet teams, and
  share-based element + family synergy.
- **Hatching** with weighted pools, independent variant rolls, per-class pity, duplicate → gems,
  auto-equip, fusion.
- **Rebirth** with coin reset (pets kept), permanent multiplier, Tokens, zone/milestone unlocks.
- **Shadow Realm enchanting** with slot rules, lock cost, escalating reroll price and pity.
- **Relic forging/equipping** with rebirth-gated slots and behaviour effects (overcharge, extra hits,
  auto-tap, synergy, curses).
- **Trading** with escrow, double confirm, value-band warning, 5% token burn, revalidation, rate limits
  and an audit store.
- **Raids** every 4h scaled to live server power, contribution tiers, exclusive egg drops.
- **Hourly events** on a rotation, including Synergy Surge doubling synergy for the window.
- **Monetization** with idempotent receipts, entitlement sync, and server-derived pity payloads.
- **Persistence** with session locking, autosave, `BindToClose` flush, schema reconciliation, leaderboards.
- **UI** for HUD, pet detail (3D viewport, Power/Gems/Weight/Level, Quick Compare), inventory (grid,
  categories, folders, 8 sort modes, filters, multi-select), and the exclusive shop with live pity bars.

## Deliberately not in this slice

- Trade window UI (server endpoints are complete; `TradeAction` is ready).
- Real pet models/animations and hatch ceremony polish.
- Season pass, auction house, guilds, pet index.
- Server-side paging as the default inventory path (endpoint exists; full sync is used).
- Telemetry dashboards and the `maxPaidPowerShare` enforcement guardrail.
